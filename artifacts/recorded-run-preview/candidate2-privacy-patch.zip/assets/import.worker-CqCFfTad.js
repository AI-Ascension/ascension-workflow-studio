(function(){var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t,n)=>()=>{if(n)throw n[0];try{return e&&(t=e(e=0)),t}catch(e){throw n=[e],e}},s=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),c=(e,n)=>{let r={};for(var i in e)t(r,i,{get:e[i],enumerable:!0});return n||t(r,Symbol.toStringTag,{value:`Module`}),r},l=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},u=(n,r,o)=>(o=n==null?{}:e(i(n)),l(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n)),d=e=>a.call(e,`module.exports`)?e[`module.exports`]:l(t({},`__esModule`,{value:!0}),e),f=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.regexpCode=e.getEsmExportName=e.getProperty=e.safeStringify=e.stringify=e.strConcat=e.addCodeArg=e.str=e._=e.nil=e._Code=e.Name=e.IDENTIFIER=e._CodeOrName=void 0;var t=class{};e._CodeOrName=t,e.IDENTIFIER=/^[a-z$_][a-z$_0-9]*$/i;var n=class extends t{constructor(t){if(super(),!e.IDENTIFIER.test(t))throw Error(`CodeGen: name must be a valid identifier`);this.str=t}toString(){return this.str}emptyStr(){return!1}get names(){return{[this.str]:1}}};e.Name=n;var r=class extends t{constructor(e){super(),this._items=typeof e==`string`?[e]:e}toString(){return this.str}emptyStr(){if(this._items.length>1)return!1;let e=this._items[0];return e===``||e===`""`}get str(){return this._str??=this._items.reduce((e,t)=>`${e}${t}`,``)}get names(){return this._names??=this._items.reduce((e,t)=>(t instanceof n&&(e[t.str]=(e[t.str]||0)+1),e),{})}};e._Code=r,e.nil=new r(``);function i(e,...t){let n=[e[0]],i=0;for(;i<t.length;)s(n,t[i]),n.push(e[++i]);return new r(n)}e._=i;let a=new r(`+`);function o(e,...t){let n=[p(e[0])],i=0;for(;i<t.length;)n.push(a),s(n,t[i]),n.push(a,p(e[++i]));return c(n),new r(n)}e.str=o;function s(e,t){t instanceof r?e.push(...t._items):t instanceof n?e.push(t):e.push(d(t))}e.addCodeArg=s;function c(e){let t=1;for(;t<e.length-1;){if(e[t]===a){let n=l(e[t-1],e[t+1]);if(n!==void 0){e.splice(t-1,3,n);continue}e[t++]=`+`}t++}}function l(e,t){if(t===`""`)return e;if(e===`""`)return t;if(typeof e==`string`)return t instanceof n||e[e.length-1]!==`"`?void 0:typeof t==`string`?t[0]===`"`?e.slice(0,-1)+t.slice(1):void 0:`${e.slice(0,-1)}${t}"`;if(typeof t==`string`&&t[0]===`"`&&!(e instanceof n))return`"${e}${t.slice(1)}`}function u(e,t){return t.emptyStr()?e:e.emptyStr()?t:o`${e}${t}`}e.strConcat=u;function d(e){return typeof e==`number`||typeof e==`boolean`||e===null?e:p(Array.isArray(e)?e.join(`,`):e)}function f(e){return new r(p(e))}e.stringify=f;function p(e){return JSON.stringify(e).replace(/\u2028/g,`\\u2028`).replace(/\u2029/g,`\\u2029`)}e.safeStringify=p;function m(t){return typeof t==`string`&&e.IDENTIFIER.test(t)?new r(`.${t}`):i`[${t}]`}e.getProperty=m;function h(t){if(typeof t==`string`&&e.IDENTIFIER.test(t))return new r(`${t}`);throw Error(`CodeGen: invalid export name: ${t}, use explicit $id name mapping`)}e.getEsmExportName=h;function g(e){return new r(e.toString())}e.regexpCode=g})),p=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.ValueScope=e.ValueScopeName=e.Scope=e.varKinds=e.UsedValueState=void 0;let t=f();var n=class extends Error{constructor(e){super(`CodeGen: "code" for ${e} not defined`),this.value=e.value}},r;(function(e){e[e.Started=0]=`Started`,e[e.Completed=1]=`Completed`})(r||(e.UsedValueState=r={})),e.varKinds={const:new t.Name(`const`),let:new t.Name(`let`),var:new t.Name(`var`)};var i=class{constructor({prefixes:e,parent:t}={}){this._names={},this._prefixes=e,this._parent=t}toName(e){return e instanceof t.Name?e:this.name(e)}name(e){return new t.Name(this._newName(e))}_newName(e){let t=this._names[e]||this._nameGroup(e);return`${e}${t.index++}`}_nameGroup(e){if((this._parent?._prefixes)?.has(e)||this._prefixes&&!this._prefixes.has(e))throw Error(`CodeGen: prefix "${e}" is not allowed in this scope`);return this._names[e]={prefix:e,index:0}}};e.Scope=i;var a=class extends t.Name{constructor(e,t){super(t),this.prefix=e}setValue(e,{property:n,itemIndex:r}){this.value=e,this.scopePath=(0,t._)`.${new t.Name(n)}[${r}]`}};e.ValueScopeName=a;let o=(0,t._)`\n`;e.ValueScope=class extends i{constructor(e){super(e),this._values={},this._scope=e.scope,this.opts={...e,_n:e.lines?o:t.nil}}get(){return this._scope}name(e){return new a(e,this._newName(e))}value(e,t){if(t.ref===void 0)throw Error(`CodeGen: ref must be passed in value`);let n=this.toName(e),{prefix:r}=n,i=t.key??t.ref,a=this._values[r];if(a){let e=a.get(i);if(e)return e}else a=this._values[r]=new Map;a.set(i,n);let o=this._scope[r]||(this._scope[r]=[]),s=o.length;return o[s]=t.ref,n.setValue(t,{property:r,itemIndex:s}),n}getValue(e,t){let n=this._values[e];if(n)return n.get(t)}scopeRefs(e,n=this._values){return this._reduceValues(n,n=>{if(n.scopePath===void 0)throw Error(`CodeGen: name "${n}" has no value`);return(0,t._)`${e}${n.scopePath}`})}scopeCode(e=this._values,t,n){return this._reduceValues(e,e=>{if(e.value===void 0)throw Error(`CodeGen: name "${e}" has no value`);return e.value.code},t,n)}_reduceValues(i,a,o={},s){let c=t.nil;for(let l in i){let u=i[l];if(!u)continue;let d=o[l]=o[l]||new Map;u.forEach(i=>{if(d.has(i))return;d.set(i,r.Started);let o=a(i);if(o){let n=this.opts.es5?e.varKinds.var:e.varKinds.const;c=(0,t._)`${c}${n} ${i} = ${o};${this.opts._n}`}else if(o=s?.(i))c=(0,t._)`${c}${o}${this.opts._n}`;else throw new n(i);d.set(i,r.Completed)})}return c}}})),m=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.or=e.and=e.not=e.CodeGen=e.operators=e.varKinds=e.ValueScopeName=e.ValueScope=e.Scope=e.Name=e.regexpCode=e.stringify=e.getProperty=e.nil=e.strConcat=e.str=e._=void 0;let t=f(),n=p();var r=f();Object.defineProperty(e,"_",{enumerable:!0,get:function(){return r._}}),Object.defineProperty(e,"str",{enumerable:!0,get:function(){return r.str}}),Object.defineProperty(e,"strConcat",{enumerable:!0,get:function(){return r.strConcat}}),Object.defineProperty(e,"nil",{enumerable:!0,get:function(){return r.nil}}),Object.defineProperty(e,"getProperty",{enumerable:!0,get:function(){return r.getProperty}}),Object.defineProperty(e,"stringify",{enumerable:!0,get:function(){return r.stringify}}),Object.defineProperty(e,"regexpCode",{enumerable:!0,get:function(){return r.regexpCode}}),Object.defineProperty(e,"Name",{enumerable:!0,get:function(){return r.Name}});var i=p();Object.defineProperty(e,"Scope",{enumerable:!0,get:function(){return i.Scope}}),Object.defineProperty(e,"ValueScope",{enumerable:!0,get:function(){return i.ValueScope}}),Object.defineProperty(e,"ValueScopeName",{enumerable:!0,get:function(){return i.ValueScopeName}}),Object.defineProperty(e,"varKinds",{enumerable:!0,get:function(){return i.varKinds}}),e.operators={GT:new t._Code(`>`),GTE:new t._Code(`>=`),LT:new t._Code(`<`),LTE:new t._Code(`<=`),EQ:new t._Code(`===`),NEQ:new t._Code(`!==`),NOT:new t._Code(`!`),OR:new t._Code(`||`),AND:new t._Code(`&&`),ADD:new t._Code(`+`)};var a=class{optimizeNodes(){return this}optimizeNames(e,t){return this}},o=class extends a{constructor(e,t,n){super(),this.varKind=e,this.name=t,this.rhs=n}render({es5:e,_n:t}){let r=e?n.varKinds.var:this.varKind,i=this.rhs===void 0?``:` = ${this.rhs}`;return`${r} ${this.name}${i};`+t}optimizeNames(e,t){if(e[this.name.str])return this.rhs&&=O(this.rhs,e,t),this}get names(){return this.rhs instanceof t._CodeOrName?this.rhs.names:{}}},s=class extends a{constructor(e,t,n){super(),this.lhs=e,this.rhs=t,this.sideEffects=n}render({_n:e}){return`${this.lhs} = ${this.rhs};`+e}optimizeNames(e,n){if(!(this.lhs instanceof t.Name&&!e[this.lhs.str]&&!this.sideEffects))return this.rhs=O(this.rhs,e,n),this}get names(){return D(this.lhs instanceof t.Name?{}:{...this.lhs.names},this.rhs)}},c=class extends s{constructor(e,t,n,r){super(e,n,r),this.op=t}render({_n:e}){return`${this.lhs} ${this.op}= ${this.rhs};`+e}},l=class extends a{constructor(e){super(),this.label=e,this.names={}}render({_n:e}){return`${this.label}:`+e}},u=class extends a{constructor(e){super(),this.label=e,this.names={}}render({_n:e}){return`break${this.label?` ${this.label}`:``};`+e}},d=class extends a{constructor(e){super(),this.error=e}render({_n:e}){return`throw ${this.error};`+e}get names(){return this.error.names}},m=class extends a{constructor(e){super(),this.code=e}render({_n:e}){return`${this.code};`+e}optimizeNodes(){return`${this.code}`?this:void 0}optimizeNames(e,t){return this.code=O(this.code,e,t),this}get names(){return this.code instanceof t._CodeOrName?this.code.names:{}}},h=class extends a{constructor(e=[]){super(),this.nodes=e}render(e){return this.nodes.reduce((t,n)=>t+n.render(e),``)}optimizeNodes(){let{nodes:e}=this,t=e.length;for(;t--;){let n=e[t].optimizeNodes();Array.isArray(n)?e.splice(t,1,...n):n?e[t]=n:e.splice(t,1)}return e.length>0?this:void 0}optimizeNames(e,t){let{nodes:n}=this,r=n.length;for(;r--;){let i=n[r];i.optimizeNames(e,t)||(k(e,i.names),n.splice(r,1))}return n.length>0?this:void 0}get names(){return this.nodes.reduce((e,t)=>E(e,t.names),{})}},g=class extends h{render(e){return`{`+e._n+super.render(e)+`}`+e._n}},_=class extends h{},v=class extends g{};v.kind=`else`;var y=class e extends g{constructor(e,t){super(t),this.condition=e}render(e){let t=`if(${this.condition})`+super.render(e);return this.else&&(t+=`else `+this.else.render(e)),t}optimizeNodes(){super.optimizeNodes();let t=this.condition;if(t===!0)return this.nodes;let n=this.else;if(n){let e=n.optimizeNodes();n=this.else=Array.isArray(e)?new v(e):e}if(n)return t===!1?n instanceof e?n:n.nodes:this.nodes.length?this:new e(A(t),n instanceof e?[n]:n.nodes);if(t!==!1&&this.nodes.length)return this}optimizeNames(e,t){if(this.else=this.else?.optimizeNames(e,t),super.optimizeNames(e,t)||this.else)return this.condition=O(this.condition,e,t),this}get names(){let e=super.names;return D(e,this.condition),this.else&&E(e,this.else.names),e}};y.kind=`if`;var b=class extends g{};b.kind=`for`;var x=class extends b{constructor(e){super(),this.iteration=e}render(e){return`for(${this.iteration})`+super.render(e)}optimizeNames(e,t){if(super.optimizeNames(e,t))return this.iteration=O(this.iteration,e,t),this}get names(){return E(super.names,this.iteration.names)}},S=class extends b{constructor(e,t,n,r){super(),this.varKind=e,this.name=t,this.from=n,this.to=r}render(e){let t=e.es5?n.varKinds.var:this.varKind,{name:r,from:i,to:a}=this;return`for(${t} ${r}=${i}; ${r}<${a}; ${r}++)`+super.render(e)}get names(){return D(D(super.names,this.from),this.to)}},C=class extends b{constructor(e,t,n,r){super(),this.loop=e,this.varKind=t,this.name=n,this.iterable=r}render(e){return`for(${this.varKind} ${this.name} ${this.loop} ${this.iterable})`+super.render(e)}optimizeNames(e,t){if(super.optimizeNames(e,t))return this.iterable=O(this.iterable,e,t),this}get names(){return E(super.names,this.iterable.names)}},w=class extends g{constructor(e,t,n){super(),this.name=e,this.args=t,this.async=n}render(e){return`${this.async?`async `:``}function ${this.name}(${this.args})`+super.render(e)}};w.kind=`func`;var ee=class extends h{render(e){return`return `+super.render(e)}};ee.kind=`return`;var te=class extends g{render(e){let t=`try`+super.render(e);return this.catch&&(t+=this.catch.render(e)),this.finally&&(t+=this.finally.render(e)),t}optimizeNodes(){var e,t;return super.optimizeNodes(),(e=this.catch)==null||e.optimizeNodes(),(t=this.finally)==null||t.optimizeNodes(),this}optimizeNames(e,t){var n,r;return super.optimizeNames(e,t),(n=this.catch)==null||n.optimizeNames(e,t),(r=this.finally)==null||r.optimizeNames(e,t),this}get names(){let e=super.names;return this.catch&&E(e,this.catch.names),this.finally&&E(e,this.finally.names),e}},ne=class extends g{constructor(e){super(),this.error=e}render(e){return`catch(${this.error})`+super.render(e)}};ne.kind=`catch`;var T=class extends g{render(e){return`finally`+super.render(e)}};T.kind=`finally`,e.CodeGen=class{constructor(e,t={}){this._values={},this._blockStarts=[],this._constants={},this.opts={...t,_n:t.lines?`
`:``},this._extScope=e,this._scope=new n.Scope({parent:e}),this._nodes=[new _]}toString(){return this._root.render(this.opts)}name(e){return this._scope.name(e)}scopeName(e){return this._extScope.name(e)}scopeValue(e,t){let n=this._extScope.value(e,t);return(this._values[n.prefix]||(this._values[n.prefix]=new Set)).add(n),n}getScopeValue(e,t){return this._extScope.getValue(e,t)}scopeRefs(e){return this._extScope.scopeRefs(e,this._values)}scopeCode(){return this._extScope.scopeCode(this._values)}_def(e,t,n,r){let i=this._scope.toName(t);return n!==void 0&&r&&(this._constants[i.str]=n),this._leafNode(new o(e,i,n)),i}const(e,t,r){return this._def(n.varKinds.const,e,t,r)}let(e,t,r){return this._def(n.varKinds.let,e,t,r)}var(e,t,r){return this._def(n.varKinds.var,e,t,r)}assign(e,t,n){return this._leafNode(new s(e,t,n))}add(t,n){return this._leafNode(new c(t,e.operators.ADD,n))}code(e){return typeof e==`function`?e():e!==t.nil&&this._leafNode(new m(e)),this}object(...e){let n=[`{`];for(let[r,i]of e)n.length>1&&n.push(`,`),n.push(r),(r!==i||this.opts.es5)&&(n.push(`:`),(0,t.addCodeArg)(n,i));return n.push(`}`),new t._Code(n)}if(e,t,n){if(this._blockNode(new y(e)),t&&n)this.code(t).else().code(n).endIf();else if(t)this.code(t).endIf();else if(n)throw Error(`CodeGen: "else" body without "then" body`);return this}elseIf(e){return this._elseNode(new y(e))}else(){return this._elseNode(new v)}endIf(){return this._endBlockNode(y,v)}_for(e,t){return this._blockNode(e),t&&this.code(t).endFor(),this}for(e,t){return this._for(new x(e),t)}forRange(e,t,r,i,a=this.opts.es5?n.varKinds.var:n.varKinds.let){let o=this._scope.toName(e);return this._for(new S(a,o,t,r),()=>i(o))}forOf(e,r,i,a=n.varKinds.const){let o=this._scope.toName(e);if(this.opts.es5){let e=r instanceof t.Name?r:this.var(`_arr`,r);return this.forRange(`_i`,0,(0,t._)`${e}.length`,n=>{this.var(o,(0,t._)`${e}[${n}]`),i(o)})}return this._for(new C(`of`,a,o,r),()=>i(o))}forIn(e,r,i,a=this.opts.es5?n.varKinds.var:n.varKinds.const){if(this.opts.ownProperties)return this.forOf(e,(0,t._)`Object.keys(${r})`,i);let o=this._scope.toName(e);return this._for(new C(`in`,a,o,r),()=>i(o))}endFor(){return this._endBlockNode(b)}label(e){return this._leafNode(new l(e))}break(e){return this._leafNode(new u(e))}return(e){let t=new ee;if(this._blockNode(t),this.code(e),t.nodes.length!==1)throw Error(`CodeGen: "return" should have one node`);return this._endBlockNode(ee)}try(e,t,n){if(!t&&!n)throw Error(`CodeGen: "try" without "catch" and "finally"`);let r=new te;if(this._blockNode(r),this.code(e),t){let e=this.name(`e`);this._currNode=r.catch=new ne(e),t(e)}return n&&(this._currNode=r.finally=new T,this.code(n)),this._endBlockNode(ne,T)}throw(e){return this._leafNode(new d(e))}block(e,t){return this._blockStarts.push(this._nodes.length),e&&this.code(e).endBlock(t),this}endBlock(e){let t=this._blockStarts.pop();if(t===void 0)throw Error(`CodeGen: not in self-balancing block`);let n=this._nodes.length-t;if(n<0||e!==void 0&&n!==e)throw Error(`CodeGen: wrong number of nodes: ${n} vs ${e} expected`);return this._nodes.length=t,this}func(e,n=t.nil,r,i){return this._blockNode(new w(e,n,r)),i&&this.code(i).endFunc(),this}endFunc(){return this._endBlockNode(w)}optimize(e=1){for(;e-->0;)this._root.optimizeNodes(),this._root.optimizeNames(this._root.names,this._constants)}_leafNode(e){return this._currNode.nodes.push(e),this}_blockNode(e){this._currNode.nodes.push(e),this._nodes.push(e)}_endBlockNode(e,t){let n=this._currNode;if(n instanceof e||t&&n instanceof t)return this._nodes.pop(),this;throw Error(`CodeGen: not in block "${t?`${e.kind}/${t.kind}`:e.kind}"`)}_elseNode(e){let t=this._currNode;if(!(t instanceof y))throw Error(`CodeGen: "else" without "if"`);return this._currNode=t.else=e,this}get _root(){return this._nodes[0]}get _currNode(){let e=this._nodes;return e[e.length-1]}set _currNode(e){let t=this._nodes;t[t.length-1]=e}};function E(e,t){for(let n in t)e[n]=(e[n]||0)+(t[n]||0);return e}function D(e,n){return n instanceof t._CodeOrName?E(e,n.names):e}function O(e,n,r){return e instanceof t.Name?i(e):a(e)?new t._Code(e._items.reduce((e,n)=>(n instanceof t.Name&&(n=i(n)),n instanceof t._Code?e.push(...n._items):e.push(n),e),[])):e;function i(e){let t=r[e.str];return t===void 0||n[e.str]!==1?e:(delete n[e.str],t)}function a(e){return e instanceof t._Code&&e._items.some(e=>e instanceof t.Name&&n[e.str]===1&&r[e.str]!==void 0)}}function k(e,t){for(let n in t)e[n]=(e[n]||0)-(t[n]||0)}function A(e){return typeof e==`boolean`||typeof e==`number`||e===null?!e:(0,t._)`!${oe(e)}`}e.not=A;let re=ae(e.operators.AND);function j(...e){return e.reduce(re)}e.and=j;let ie=ae(e.operators.OR);function M(...e){return e.reduce(ie)}e.or=M;function ae(e){return(n,r)=>n===t.nil?r:r===t.nil?n:(0,t._)`${oe(n)} ${e} ${oe(r)}`}function oe(e){return e instanceof t.Name?e:(0,t._)`(${e})`}})),h=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.checkStrictMode=e.getErrorPath=e.Type=e.useFunc=e.setEvaluated=e.evaluatedPropsToName=e.mergeEvaluated=e.eachItem=e.unescapeJsonPointer=e.escapeJsonPointer=e.escapeFragment=e.unescapeFragment=e.schemaRefOrVal=e.schemaHasRulesButRef=e.schemaHasRules=e.checkUnknownRules=e.alwaysValidSchema=e.toHash=void 0;let t=m(),n=f();function r(e){let t={};for(let n of e)t[n]=!0;return t}e.toHash=r;function i(e,t){return typeof t==`boolean`?t:Object.keys(t).length===0||(a(e,t),!o(t,e.self.RULES.all))}e.alwaysValidSchema=i;function a(e,t=e.schema){let{opts:n,self:r}=e;if(!n.strictSchema||typeof t==`boolean`)return;let i=r.RULES.keywords;for(let n in t)i[n]||C(e,`unknown keyword: "${n}"`)}e.checkUnknownRules=a;function o(e,t){if(typeof e==`boolean`)return!e;for(let n in e)if(t[n])return!0;return!1}e.schemaHasRules=o;function s(e,t){if(typeof e==`boolean`)return!e;for(let n in e)if(n!==`$ref`&&t.all[n])return!0;return!1}e.schemaHasRulesButRef=s;function c({topSchemaRef:e,schemaPath:n},r,i,a){if(!a){if(typeof r==`number`||typeof r==`boolean`)return r;if(typeof r==`string`)return(0,t._)`${r}`}return(0,t._)`${e}${n}${(0,t.getProperty)(i)}`}e.schemaRefOrVal=c;function l(e){return p(decodeURIComponent(e))}e.unescapeFragment=l;function u(e){return encodeURIComponent(d(e))}e.escapeFragment=u;function d(e){return typeof e==`number`?`${e}`:e.replace(/~/g,`~0`).replace(/\//g,`~1`)}e.escapeJsonPointer=d;function p(e){return e.replace(/~1/g,`/`).replace(/~0/g,`~`)}e.unescapeJsonPointer=p;function h(e,t){if(Array.isArray(e))for(let n of e)t(n);else t(e)}e.eachItem=h;function g({mergeNames:e,mergeToName:n,mergeValues:r,resultToName:i}){return(a,o,s,c)=>{let l=s===void 0?o:s instanceof t.Name?(o instanceof t.Name?e(a,o,s):n(a,o,s),s):o instanceof t.Name?(n(a,s,o),o):r(o,s);return c===t.Name&&!(l instanceof t.Name)?i(a,l):l}}e.mergeEvaluated={props:g({mergeNames:(e,n,r)=>e.if((0,t._)`${r} !== true && ${n} !== undefined`,()=>{e.if((0,t._)`${n} === true`,()=>e.assign(r,!0),()=>e.assign(r,(0,t._)`${r} || {}`).code((0,t._)`Object.assign(${r}, ${n})`))}),mergeToName:(e,n,r)=>e.if((0,t._)`${r} !== true`,()=>{n===!0?e.assign(r,!0):(e.assign(r,(0,t._)`${r} || {}`),v(e,r,n))}),mergeValues:(e,t)=>e===!0||{...e,...t},resultToName:_}),items:g({mergeNames:(e,n,r)=>e.if((0,t._)`${r} !== true && ${n} !== undefined`,()=>e.assign(r,(0,t._)`${n} === true ? true : ${r} > ${n} ? ${r} : ${n}`)),mergeToName:(e,n,r)=>e.if((0,t._)`${r} !== true`,()=>e.assign(r,n===!0||(0,t._)`${r} > ${n} ? ${r} : ${n}`)),mergeValues:(e,t)=>e===!0||Math.max(e,t),resultToName:(e,t)=>e.var(`items`,t)})};function _(e,n){if(n===!0)return e.var(`props`,!0);let r=e.var(`props`,(0,t._)`{}`);return n!==void 0&&v(e,r,n),r}e.evaluatedPropsToName=_;function v(e,n,r){Object.keys(r).forEach(r=>e.assign((0,t._)`${n}${(0,t.getProperty)(r)}`,!0))}e.setEvaluated=v;let y={};function b(e,t){return e.scopeValue(`func`,{ref:t,code:y[t.code]||(y[t.code]=new n._Code(t.code))})}e.useFunc=b;var x;(function(e){e[e.Num=0]=`Num`,e[e.Str=1]=`Str`})(x||(e.Type=x={}));function S(e,n,r){if(e instanceof t.Name){let i=n===x.Num;return r?i?(0,t._)`"[" + ${e} + "]"`:(0,t._)`"['" + ${e} + "']"`:i?(0,t._)`"/" + ${e}`:(0,t._)`"/" + ${e}.replace(/~/g, "~0").replace(/\\//g, "~1")`}return r?(0,t.getProperty)(e).toString():`/`+d(e)}e.getErrorPath=S;function C(e,t,n=e.opts.strictSchema){if(n){if(t=`strict mode: ${t}`,n===!0)throw Error(t);e.self.logger.warn(t)}}e.checkStrictMode=C})),g=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m();e.default={data:new t.Name(`data`),valCxt:new t.Name(`valCxt`),instancePath:new t.Name(`instancePath`),parentData:new t.Name(`parentData`),parentDataProperty:new t.Name(`parentDataProperty`),rootData:new t.Name(`rootData`),dynamicAnchors:new t.Name(`dynamicAnchors`),vErrors:new t.Name(`vErrors`),errors:new t.Name(`errors`),this:new t.Name(`this`),self:new t.Name(`self`),scope:new t.Name(`scope`),json:new t.Name(`json`),jsonPos:new t.Name(`jsonPos`),jsonLen:new t.Name(`jsonLen`),jsonPart:new t.Name(`jsonPart`)}})),_=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.extendErrors=e.resetErrorsCount=e.reportExtraError=e.reportError=e.keyword$DataError=e.keywordError=void 0;let t=m(),n=h(),r=g();e.keywordError={message:({keyword:e})=>(0,t.str)`must pass "${e}" keyword validation`},e.keyword$DataError={message:({keyword:e,schemaType:n})=>n?(0,t.str)`"${e}" keyword must be ${n} ($data)`:(0,t.str)`"${e}" keyword is invalid ($data)`};function i(n,r=e.keywordError,i,a){let{it:o}=n,{gen:s,compositeRule:u,allErrors:f}=o,p=d(n,r,i);a??(u||f)?c(s,p):l(o,(0,t._)`[${p}]`)}e.reportError=i;function a(t,n=e.keywordError,i){let{it:a}=t,{gen:o,compositeRule:s,allErrors:u}=a;c(o,d(t,n,i)),s||u||l(a,r.default.vErrors)}e.reportExtraError=a;function o(e,n){e.assign(r.default.errors,n),e.if((0,t._)`${r.default.vErrors} !== null`,()=>e.if(n,()=>e.assign((0,t._)`${r.default.vErrors}.length`,n),()=>e.assign(r.default.vErrors,null)))}e.resetErrorsCount=o;function s({gen:e,keyword:n,schemaValue:i,data:a,errsCount:o,it:s}){if(o===void 0)throw Error(`ajv implementation error`);let c=e.name(`err`);e.forRange(`i`,o,r.default.errors,o=>{e.const(c,(0,t._)`${r.default.vErrors}[${o}]`),e.if((0,t._)`${c}.instancePath === undefined`,()=>e.assign((0,t._)`${c}.instancePath`,(0,t.strConcat)(r.default.instancePath,s.errorPath))),e.assign((0,t._)`${c}.schemaPath`,(0,t.str)`${s.errSchemaPath}/${n}`),s.opts.verbose&&(e.assign((0,t._)`${c}.schema`,i),e.assign((0,t._)`${c}.data`,a))})}e.extendErrors=s;function c(e,n){let i=e.const(`err`,n);e.if((0,t._)`${r.default.vErrors} === null`,()=>e.assign(r.default.vErrors,(0,t._)`[${i}]`),(0,t._)`${r.default.vErrors}.push(${i})`),e.code((0,t._)`${r.default.errors}++`)}function l(e,n){let{gen:r,validateName:i,schemaEnv:a}=e;a.$async?r.throw((0,t._)`new ${e.ValidationError}(${n})`):(r.assign((0,t._)`${i}.errors`,n),r.return(!1))}let u={keyword:new t.Name(`keyword`),schemaPath:new t.Name(`schemaPath`),params:new t.Name(`params`),propertyName:new t.Name(`propertyName`),message:new t.Name(`message`),schema:new t.Name(`schema`),parentSchema:new t.Name(`parentSchema`)};function d(e,n,r){let{createErrors:i}=e.it;return i===!1?(0,t._)`{}`:f(e,n,r)}function f(e,t,n={}){let{gen:r,it:i}=e,a=[p(i,n),_(e,n)];return v(e,t,a),r.object(...a)}function p({errorPath:e},{instancePath:i}){let a=i?(0,t.str)`${e}${(0,n.getErrorPath)(i,n.Type.Str)}`:e;return[r.default.instancePath,(0,t.strConcat)(r.default.instancePath,a)]}function _({keyword:e,it:{errSchemaPath:r}},{schemaPath:i,parentSchema:a}){let o=a?r:(0,t.str)`${r}/${e}`;return i&&(o=(0,t.str)`${o}${(0,n.getErrorPath)(i,n.Type.Str)}`),[u.schemaPath,o]}function v(e,{params:n,message:i},a){let{keyword:o,data:s,schemaValue:c,it:l}=e,{opts:d,propertyName:f,topSchemaRef:p,schemaPath:m}=l;a.push([u.keyword,o],[u.params,typeof n==`function`?n(e):n||(0,t._)`{}`]),d.messages&&a.push([u.message,typeof i==`function`?i(e):i]),d.verbose&&a.push([u.schema,c],[u.parentSchema,(0,t._)`${p}${m}`],[r.default.data,s]),f&&a.push([u.propertyName,f])}})),v=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.boolOrEmptySchema=e.topBoolOrEmptySchema=void 0;let t=_(),n=m(),r=g(),i={message:`boolean schema is false`};function a(e){let{gen:t,schema:i,validateName:a}=e;i===!1?s(e,!1):typeof i==`object`&&i.$async===!0?t.return(r.default.data):(t.assign((0,n._)`${a}.errors`,null),t.return(!0))}e.topBoolOrEmptySchema=a;function o(e,t){let{gen:n,schema:r}=e;r===!1?(n.var(t,!1),s(e)):n.var(t,!0)}e.boolOrEmptySchema=o;function s(e,n){let{gen:r,data:a}=e,o={gen:r,keyword:`false schema`,data:a,schema:!1,schemaCode:!1,schemaValue:!1,params:{},it:e};(0,t.reportError)(o,i,void 0,n)}})),y=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.getRules=e.isJSONType=void 0;let t=new Set([`string`,`number`,`integer`,`boolean`,`null`,`object`,`array`]);function n(e){return typeof e==`string`&&t.has(e)}e.isJSONType=n;function r(){let e={number:{type:`number`,rules:[]},string:{type:`string`,rules:[]},array:{type:`array`,rules:[]},object:{type:`object`,rules:[]}};return{types:{...e,integer:!0,boolean:!0,null:!0},rules:[{rules:[]},e.number,e.string,e.array,e.object],post:{rules:[]},all:{},keywords:{}}}e.getRules=r})),b=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.shouldUseRule=e.shouldUseGroup=e.schemaHasRulesForType=void 0;function t({schema:e,self:t},r){let i=t.RULES.types[r];return i&&i!==!0&&n(e,i)}e.schemaHasRulesForType=t;function n(e,t){return t.rules.some(t=>r(e,t))}e.shouldUseGroup=n;function r(e,t){return e[t.keyword]!==void 0||t.definition.implements?.some(t=>e[t]!==void 0)}e.shouldUseRule=r})),x=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.reportTypeError=e.checkDataTypes=e.checkDataType=e.coerceAndCheckDataType=e.getJSONTypes=e.getSchemaTypes=e.DataType=void 0;let t=y(),n=b(),r=_(),i=m(),a=h();var o;(function(e){e[e.Correct=0]=`Correct`,e[e.Wrong=1]=`Wrong`})(o||(e.DataType=o={}));function s(e){let t=c(e.type);if(t.includes(`null`)){if(e.nullable===!1)throw Error(`type: null contradicts nullable: false`)}else{if(!t.length&&e.nullable!==void 0)throw Error(`"nullable" cannot be used without "type"`);e.nullable===!0&&t.push(`null`)}return t}e.getSchemaTypes=s;function c(e){let n=Array.isArray(e)?e:e?[e]:[];if(n.every(t.isJSONType))return n;throw Error(`type must be JSONType or JSONType[]: `+n.join(`,`))}e.getJSONTypes=c;function l(e,t){let{gen:r,data:i,opts:a}=e,s=d(t,a.coerceTypes),c=t.length>0&&!(s.length===0&&t.length===1&&(0,n.schemaHasRulesForType)(e,t[0]));if(c){let n=v(t,i,a.strictNumbers,o.Wrong);r.if(n,()=>{s.length?f(e,t,s):S(e)})}return c}e.coerceAndCheckDataType=l;let u=new Set([`string`,`number`,`integer`,`boolean`,`null`]);function d(e,t){return t?e.filter(e=>u.has(e)||t===`array`&&e===`array`):[]}function f(e,t,n){let{gen:r,data:a,opts:o}=e,s=r.let(`dataType`,(0,i._)`typeof ${a}`),c=r.let(`coerced`,(0,i._)`undefined`);o.coerceTypes===`array`&&r.if((0,i._)`${s} == 'object' && Array.isArray(${a}) && ${a}.length == 1`,()=>r.assign(a,(0,i._)`${a}[0]`).assign(s,(0,i._)`typeof ${a}`).if(v(t,a,o.strictNumbers),()=>r.assign(c,a))),r.if((0,i._)`${c} !== undefined`);for(let e of n)(u.has(e)||e===`array`&&o.coerceTypes===`array`)&&l(e);r.else(),S(e),r.endIf(),r.if((0,i._)`${c} !== undefined`,()=>{r.assign(a,c),p(e,c)});function l(e){switch(e){case`string`:r.elseIf((0,i._)`${s} == "number" || ${s} == "boolean"`).assign(c,(0,i._)`"" + ${a}`).elseIf((0,i._)`${a} === null`).assign(c,(0,i._)`""`);return;case`number`:r.elseIf((0,i._)`${s} == "boolean" || ${a} === null
              || (${s} == "string" && ${a} && ${a} == +${a})`).assign(c,(0,i._)`+${a}`);return;case`integer`:r.elseIf((0,i._)`${s} === "boolean" || ${a} === null
              || (${s} === "string" && ${a} && ${a} == +${a} && !(${a} % 1))`).assign(c,(0,i._)`+${a}`);return;case`boolean`:r.elseIf((0,i._)`${a} === "false" || ${a} === 0 || ${a} === null`).assign(c,!1).elseIf((0,i._)`${a} === "true" || ${a} === 1`).assign(c,!0);return;case`null`:r.elseIf((0,i._)`${a} === "" || ${a} === 0 || ${a} === false`),r.assign(c,null);return;case`array`:r.elseIf((0,i._)`${s} === "string" || ${s} === "number"
              || ${s} === "boolean" || ${a} === null`).assign(c,(0,i._)`[${a}]`)}}}function p({gen:e,parentData:t,parentDataProperty:n},r){e.if((0,i._)`${t} !== undefined`,()=>e.assign((0,i._)`${t}[${n}]`,r))}function g(e,t,n,r=o.Correct){let a=r===o.Correct?i.operators.EQ:i.operators.NEQ,s;switch(e){case`null`:return(0,i._)`${t} ${a} null`;case`array`:s=(0,i._)`Array.isArray(${t})`;break;case`object`:s=(0,i._)`${t} && typeof ${t} == "object" && !Array.isArray(${t})`;break;case`integer`:s=c((0,i._)`!(${t} % 1) && !isNaN(${t})`);break;case`number`:s=c();break;default:return(0,i._)`typeof ${t} ${a} ${e}`}return r===o.Correct?s:(0,i.not)(s);function c(e=i.nil){return(0,i.and)((0,i._)`typeof ${t} == "number"`,e,n?(0,i._)`isFinite(${t})`:i.nil)}}e.checkDataType=g;function v(e,t,n,r){if(e.length===1)return g(e[0],t,n,r);let o,s=(0,a.toHash)(e);if(s.array&&s.object){let e=(0,i._)`typeof ${t} != "object"`;o=s.null?e:(0,i._)`!${t} || ${e}`,delete s.null,delete s.array,delete s.object}else o=i.nil;s.number&&delete s.integer;for(let e in s)o=(0,i.and)(o,g(e,t,n,r));return o}e.checkDataTypes=v;let x={message:({schema:e})=>`must be ${e}`,params:({schema:e,schemaValue:t})=>typeof e==`string`?(0,i._)`{type: ${e}}`:(0,i._)`{type: ${t}}`};function S(e){let t=C(e);(0,r.reportError)(t,x)}e.reportTypeError=S;function C(e){let{gen:t,data:n,schema:r}=e,i=(0,a.schemaRefOrVal)(e,r,`type`);return{gen:t,keyword:`type`,data:n,schema:r.type,schemaCode:i,schemaValue:i,parentSchema:r,params:{},it:e}}})),S=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.assignDefaults=void 0;let t=m(),n=h();function r(e,t){let{properties:n,items:r}=e.schema;if(t===`object`&&n)for(let t in n)i(e,t,n[t].default);else t===`array`&&Array.isArray(r)&&r.forEach((t,n)=>i(e,n,t.default))}e.assignDefaults=r;function i(e,r,i){let{gen:a,compositeRule:o,data:s,opts:c}=e;if(i===void 0)return;let l=(0,t._)`${s}${(0,t.getProperty)(r)}`;if(o){(0,n.checkStrictMode)(e,`default is ignored for: ${l}`);return}let u=(0,t._)`${l} === undefined`;c.useDefaults===`empty`&&(u=(0,t._)`${u} || ${l} === null || ${l} === ""`),a.if(u,(0,t._)`${l} = ${(0,t.stringify)(i)}`)}})),C=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.validateUnion=e.validateArray=e.usePattern=e.callValidateCode=e.schemaProperties=e.allSchemaProperties=e.noPropertyInData=e.propertyInData=e.isOwnProperty=e.hasPropFunc=e.reportMissingProp=e.checkMissingProp=e.checkReportMissingProp=void 0;let t=m(),n=h(),r=g(),i=h();function a(e,n){let{gen:r,data:i,it:a}=e;r.if(d(r,i,n,a.opts.ownProperties),()=>{e.setParams({missingProperty:(0,t._)`${n}`},!0),e.error()})}e.checkReportMissingProp=a;function o({gen:e,data:n,it:{opts:r}},i,a){return(0,t.or)(...i.map(i=>(0,t.and)(d(e,n,i,r.ownProperties),(0,t._)`${a} = ${i}`)))}e.checkMissingProp=o;function s(e,t){e.setParams({missingProperty:t},!0),e.error()}e.reportMissingProp=s;function c(e){return e.scopeValue(`func`,{ref:Object.prototype.hasOwnProperty,code:(0,t._)`Object.prototype.hasOwnProperty`})}e.hasPropFunc=c;function l(e,n,r){return(0,t._)`${c(e)}.call(${n}, ${r})`}e.isOwnProperty=l;function u(e,n,r,i){let a=(0,t._)`${n}${(0,t.getProperty)(r)} !== undefined`;return i?(0,t._)`${a} && ${l(e,n,r)}`:a}e.propertyInData=u;function d(e,n,r,i){let a=(0,t._)`${n}${(0,t.getProperty)(r)} === undefined`;return i?(0,t.or)(a,(0,t.not)(l(e,n,r))):a}e.noPropertyInData=d;function f(e){return e?Object.keys(e).filter(e=>e!==`__proto__`):[]}e.allSchemaProperties=f;function p(e,t){return f(t).filter(r=>!(0,n.alwaysValidSchema)(e,t[r]))}e.schemaProperties=p;function _({schemaCode:e,data:n,it:{gen:i,topSchemaRef:a,schemaPath:o,errorPath:s},it:c},l,u,d){let f=d?(0,t._)`${e}, ${n}, ${a}${o}`:n,p=[[r.default.instancePath,(0,t.strConcat)(r.default.instancePath,s)],[r.default.parentData,c.parentData],[r.default.parentDataProperty,c.parentDataProperty],[r.default.rootData,r.default.rootData]];c.opts.dynamicRef&&p.push([r.default.dynamicAnchors,r.default.dynamicAnchors]);let m=(0,t._)`${f}, ${i.object(...p)}`;return u===t.nil?(0,t._)`${l}(${m})`:(0,t._)`${l}.call(${u}, ${m})`}e.callValidateCode=_;let v=(0,t._)`new RegExp`;function y({gen:e,it:{opts:n}},r){let a=n.unicodeRegExp?`u`:``,{regExp:o}=n.code,s=o(r,a);return e.scopeValue(`pattern`,{key:s.toString(),ref:s,code:(0,t._)`${o.code===`new RegExp`?v:(0,i.useFunc)(e,o)}(${r}, ${a})`})}e.usePattern=y;function b(e){let{gen:r,data:i,keyword:a,it:o}=e,s=r.name(`valid`);if(o.allErrors){let e=r.let(`valid`,!0);return c(()=>r.assign(e,!1)),e}return r.var(s,!0),c(()=>r.break()),s;function c(o){let c=r.const(`len`,(0,t._)`${i}.length`);r.forRange(`i`,0,c,i=>{e.subschema({keyword:a,dataProp:i,dataPropType:n.Type.Num},s),r.if((0,t.not)(s),o)})}}e.validateArray=b;function x(e){let{gen:r,schema:i,keyword:a,it:o}=e;if(!Array.isArray(i))throw Error(`ajv implementation error`);if(i.some(e=>(0,n.alwaysValidSchema)(o,e))&&!o.opts.unevaluated)return;let s=r.let(`valid`,!1),c=r.name(`_valid`);r.block(()=>i.forEach((n,i)=>{let o=e.subschema({keyword:a,schemaProp:i,compositeRule:!0},c);r.assign(s,(0,t._)`${s} || ${c}`),e.mergeValidEvaluated(o,c)||r.if((0,t.not)(s))})),e.result(s,()=>e.reset(),()=>e.error(!0))}e.validateUnion=x})),w=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.validateKeywordUsage=e.validSchemaType=e.funcKeywordCode=e.macroKeywordCode=void 0;let t=m(),n=g(),r=C(),i=_();function a(e,n){let{gen:r,keyword:i,schema:a,parentSchema:o,it:s}=e,c=n.macro.call(s.self,a,o,s),l=u(r,i,c);s.opts.validateSchema!==!1&&s.self.validateSchema(c,!0);let d=r.name(`valid`);e.subschema({schema:c,schemaPath:t.nil,errSchemaPath:`${s.errSchemaPath}/${i}`,topSchemaRef:l,compositeRule:!0},d),e.pass(d,()=>e.error(!0))}e.macroKeywordCode=a;function o(e,i){let{gen:a,keyword:o,schema:d,parentSchema:f,$data:p,it:m}=e;l(m,i);let h=u(a,o,!p&&i.compile?i.compile.call(m.self,d,f,m):i.validate),g=a.let(`valid`);e.block$data(g,_),e.ok(i.valid??g);function _(){if(i.errors===!1)b(),i.modifying&&s(e),x(()=>e.error());else{let t=i.async?v():y();i.modifying&&s(e),x(()=>c(e,t))}}function v(){let e=a.let(`ruleErrs`,null);return a.try(()=>b((0,t._)`await `),n=>a.assign(g,!1).if((0,t._)`${n} instanceof ${m.ValidationError}`,()=>a.assign(e,(0,t._)`${n}.errors`),()=>a.throw(n))),e}function y(){let e=(0,t._)`${h}.errors`;return a.assign(e,null),b(t.nil),e}function b(o=i.async?(0,t._)`await `:t.nil){let s=m.opts.passContext?n.default.this:n.default.self,c=!(`compile`in i&&!p||i.schema===!1);a.assign(g,(0,t._)`${o}${(0,r.callValidateCode)(e,h,s,c)}`,i.modifying)}function x(e){a.if((0,t.not)(i.valid??g),e)}}e.funcKeywordCode=o;function s(e){let{gen:n,data:r,it:i}=e;n.if(i.parentData,()=>n.assign(r,(0,t._)`${i.parentData}[${i.parentDataProperty}]`))}function c(e,r){let{gen:a}=e;a.if((0,t._)`Array.isArray(${r})`,()=>{a.assign(n.default.vErrors,(0,t._)`${n.default.vErrors} === null ? ${r} : ${n.default.vErrors}.concat(${r})`).assign(n.default.errors,(0,t._)`${n.default.vErrors}.length`),(0,i.extendErrors)(e)},()=>e.error())}function l({schemaEnv:e},t){if(t.async&&!e.$async)throw Error(`async keyword in sync schema`)}function u(e,n,r){if(r===void 0)throw Error(`keyword "${n}" failed to compile`);return e.scopeValue(`keyword`,typeof r==`function`?{ref:r}:{ref:r,code:(0,t.stringify)(r)})}function d(e,t,n=!1){return!t.length||t.some(t=>t===`array`?Array.isArray(e):t===`object`?e&&typeof e==`object`&&!Array.isArray(e):typeof e==t||n&&e===void 0)}e.validSchemaType=d;function f({schema:e,opts:t,self:n,errSchemaPath:r},i,a){if(Array.isArray(i.keyword)?!i.keyword.includes(a):i.keyword!==a)throw Error(`ajv implementation error`);let o=i.dependencies;if(o?.some(t=>!Object.prototype.hasOwnProperty.call(e,t)))throw Error(`parent schema must have dependencies of ${a}: ${o.join(`,`)}`);if(i.validateSchema&&!i.validateSchema(e[a])){let e=`keyword "${a}" value is invalid at path "${r}": `+n.errorsText(i.validateSchema.errors);if(t.validateSchema===`log`)n.logger.error(e);else throw Error(e)}}e.validateKeywordUsage=f})),ee=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.extendSubschemaMode=e.extendSubschemaData=e.getSubschema=void 0;let t=m(),n=h();function r(e,{keyword:r,schemaProp:i,schema:a,schemaPath:o,errSchemaPath:s,topSchemaRef:c}){if(r!==void 0&&a!==void 0)throw Error(`both "keyword" and "schema" passed, only one allowed`);if(r!==void 0){let a=e.schema[r];return i===void 0?{schema:a,schemaPath:(0,t._)`${e.schemaPath}${(0,t.getProperty)(r)}`,errSchemaPath:`${e.errSchemaPath}/${r}`}:{schema:a[i],schemaPath:(0,t._)`${e.schemaPath}${(0,t.getProperty)(r)}${(0,t.getProperty)(i)}`,errSchemaPath:`${e.errSchemaPath}/${r}/${(0,n.escapeFragment)(i)}`}}if(a!==void 0){if(o===void 0||s===void 0||c===void 0)throw Error(`"schemaPath", "errSchemaPath" and "topSchemaRef" are required with "schema"`);return{schema:a,schemaPath:o,topSchemaRef:c,errSchemaPath:s}}throw Error(`either "keyword" or "schema" must be passed`)}e.getSubschema=r;function i(e,r,{dataProp:i,dataPropType:a,data:o,dataTypes:s,propertyName:c}){if(o!==void 0&&i!==void 0)throw Error(`both "data" and "dataProp" passed, only one allowed`);let{gen:l}=r;if(i!==void 0){let{errorPath:o,dataPathArr:s,opts:c}=r;u(l.let(`data`,(0,t._)`${r.data}${(0,t.getProperty)(i)}`,!0)),e.errorPath=(0,t.str)`${o}${(0,n.getErrorPath)(i,a,c.jsPropertySyntax)}`,e.parentDataProperty=(0,t._)`${i}`,e.dataPathArr=[...s,e.parentDataProperty]}o!==void 0&&(u(o instanceof t.Name?o:l.let(`data`,o,!0)),c!==void 0&&(e.propertyName=c)),s&&(e.dataTypes=s);function u(t){e.data=t,e.dataLevel=r.dataLevel+1,e.dataTypes=[],r.definedProperties=new Set,e.parentData=r.data,e.dataNames=[...r.dataNames,t]}}e.extendSubschemaData=i;function a(e,{jtdDiscriminator:t,jtdMetadata:n,compositeRule:r,createErrors:i,allErrors:a}){r!==void 0&&(e.compositeRule=r),i!==void 0&&(e.createErrors=i),a!==void 0&&(e.allErrors=a),e.jtdDiscriminator=t,e.jtdMetadata=n}e.extendSubschemaMode=a})),te=s(((e,t)=>{t.exports=function e(t,n){if(t===n)return!0;if(t&&n&&typeof t==`object`&&typeof n==`object`){if(t.constructor!==n.constructor)return!1;var r,i,a;if(Array.isArray(t)){if(r=t.length,r!=n.length)return!1;for(i=r;i--!==0;)if(!e(t[i],n[i]))return!1;return!0}if(t.constructor===RegExp)return t.source===n.source&&t.flags===n.flags;if(t.valueOf!==Object.prototype.valueOf)return t.valueOf()===n.valueOf();if(t.toString!==Object.prototype.toString)return t.toString()===n.toString();if(a=Object.keys(t),r=a.length,r!==Object.keys(n).length)return!1;for(i=r;i--!==0;)if(!Object.prototype.hasOwnProperty.call(n,a[i]))return!1;for(i=r;i--!==0;){var o=a[i];if(!e(t[o],n[o]))return!1}return!0}return t!==t&&n!==n}})),ne=s(((e,t)=>{var n=t.exports=function(e,t,n){typeof t==`function`&&(n=t,t={}),n=t.cb||n;var i=typeof n==`function`?n:n.pre||function(){},a=n.post||function(){};r(t,i,a,e,``,e)};n.keywords={additionalItems:!0,items:!0,contains:!0,additionalProperties:!0,propertyNames:!0,not:!0,if:!0,then:!0,else:!0},n.arrayKeywords={items:!0,allOf:!0,anyOf:!0,oneOf:!0},n.propsKeywords={$defs:!0,definitions:!0,properties:!0,patternProperties:!0,dependencies:!0},n.skipKeywords={default:!0,enum:!0,const:!0,required:!0,maximum:!0,minimum:!0,exclusiveMaximum:!0,exclusiveMinimum:!0,multipleOf:!0,maxLength:!0,minLength:!0,pattern:!0,format:!0,maxItems:!0,minItems:!0,uniqueItems:!0,maxProperties:!0,minProperties:!0};function r(e,t,a,o,s,c,l,u,d,f){if(o&&typeof o==`object`&&!Array.isArray(o)){for(var p in t(o,s,c,l,u,d,f),o){var m=o[p];if(Array.isArray(m)){if(p in n.arrayKeywords)for(var h=0;h<m.length;h++)r(e,t,a,m[h],s+`/`+p+`/`+h,c,s,p,o,h)}else if(p in n.propsKeywords){if(m&&typeof m==`object`)for(var g in m)r(e,t,a,m[g],s+`/`+p+`/`+i(g),c,s,p,o,g)}else(p in n.keywords||e.allKeys&&!(p in n.skipKeywords))&&r(e,t,a,m,s+`/`+p,c,s,p,o)}a(o,s,c,l,u,d,f)}}function i(e){return e.replace(/~/g,`~0`).replace(/\//g,`~1`)}})),T=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.getSchemaRefs=e.resolveUrl=e.normalizeId=e._getFullPath=e.getFullPath=e.inlineRef=void 0;let t=h(),n=te(),r=ne(),i=new Set([`type`,`format`,`pattern`,`maxLength`,`minLength`,`maxProperties`,`minProperties`,`maxItems`,`minItems`,`maximum`,`minimum`,`uniqueItems`,`multipleOf`,`required`,`enum`,`const`]);function a(e,t=!0){return typeof e==`boolean`?!0:t===!0?!s(e):t?c(e)<=t:!1}e.inlineRef=a;let o=new Set([`$ref`,`$recursiveRef`,`$recursiveAnchor`,`$dynamicRef`,`$dynamicAnchor`]);function s(e){for(let t in e){if(o.has(t))return!0;let n=e[t];if(Array.isArray(n)&&n.some(s)||typeof n==`object`&&s(n))return!0}return!1}function c(e){let n=0;for(let r in e)if(r===`$ref`||(n++,!i.has(r)&&(typeof e[r]==`object`&&(0,t.eachItem)(e[r],e=>n+=c(e)),n===1/0)))return 1/0;return n}function l(e,t=``,n){return n!==!1&&(t=f(t)),u(e,e.parse(t))}e.getFullPath=l;function u(e,t){return e.serialize(t).split(`#`)[0]+`#`}e._getFullPath=u;let d=/#\/?$/;function f(e){return e?e.replace(d,``):``}e.normalizeId=f;function p(e,t,n){return n=f(n),e.resolve(t,n)}e.resolveUrl=p;let m=/^[a-z_][-a-z0-9._]*$/i;function g(e,t){if(typeof e==`boolean`)return{};let{schemaId:i,uriResolver:a}=this.opts,o=f(e[i]||t),s={"":o},c=l(a,o,!1),u={},d=new Set;return r(e,{allKeys:!0},(e,t,n,r)=>{if(r===void 0)return;let a=c+t,o=s[r];typeof e[i]==`string`&&(o=l.call(this,e[i])),g.call(this,e.$anchor),g.call(this,e.$dynamicAnchor),s[t]=o;function l(t){let n=this.opts.uriResolver.resolve;if(t=f(o?n(o,t):t),d.has(t))throw h(t);d.add(t);let r=this.refs[t];return typeof r==`string`&&(r=this.refs[r]),typeof r==`object`?p(e,r.schema,t):t!==f(a)&&(t[0]===`#`?(p(e,u[t],t),u[t]=e):this.refs[t]=a),t}function g(e){if(typeof e==`string`){if(!m.test(e))throw Error(`invalid anchor "${e}"`);l.call(this,`#${e}`)}}}),u;function p(e,t,r){if(t!==void 0&&!n(e,t))throw h(r)}function h(e){return Error(`reference "${e}" resolves to more than one schema`)}}e.getSchemaRefs=g})),E=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.getData=e.KeywordCxt=e.validateFunctionCode=void 0;let t=v(),n=x(),r=b(),i=x(),a=S(),o=w(),s=ee(),c=m(),l=g(),u=T(),d=h(),f=_();function p(e){if(A(e)&&(j(e),k(e))){ne(e);return}y(e,()=>(0,t.topBoolOrEmptySchema)(e))}e.validateFunctionCode=p;function y({gen:e,validateName:t,schema:n,schemaEnv:r,opts:i},a){i.code.es5?e.func(t,(0,c._)`${l.default.data}, ${l.default.valCxt}`,r.$async,()=>{e.code((0,c._)`"use strict"; ${D(n,i)}`),te(e,i),e.code(a)}):e.func(t,(0,c._)`${l.default.data}, ${C(i)}`,r.$async,()=>e.code(D(n,i)).code(a))}function C(e){return(0,c._)`{${l.default.instancePath}="", ${l.default.parentData}, ${l.default.parentDataProperty}, ${l.default.rootData}=${l.default.data}${e.dynamicRef?(0,c._)`, ${l.default.dynamicAnchors}={}`:c.nil}}={}`}function te(e,t){e.if(l.default.valCxt,()=>{e.var(l.default.instancePath,(0,c._)`${l.default.valCxt}.${l.default.instancePath}`),e.var(l.default.parentData,(0,c._)`${l.default.valCxt}.${l.default.parentData}`),e.var(l.default.parentDataProperty,(0,c._)`${l.default.valCxt}.${l.default.parentDataProperty}`),e.var(l.default.rootData,(0,c._)`${l.default.valCxt}.${l.default.rootData}`),t.dynamicRef&&e.var(l.default.dynamicAnchors,(0,c._)`${l.default.valCxt}.${l.default.dynamicAnchors}`)},()=>{e.var(l.default.instancePath,(0,c._)`""`),e.var(l.default.parentData,(0,c._)`undefined`),e.var(l.default.parentDataProperty,(0,c._)`undefined`),e.var(l.default.rootData,l.default.data),t.dynamicRef&&e.var(l.default.dynamicAnchors,(0,c._)`{}`)})}function ne(e){let{schema:t,opts:n,gen:r}=e;y(e,()=>{n.$comment&&t.$comment&&ce(e),ae(e),r.let(l.default.vErrors,null),r.let(l.default.errors,0),n.unevaluated&&E(e),ie(e),le(e)})}function E(e){let{gen:t,validateName:n}=e;e.evaluated=t.const(`evaluated`,(0,c._)`${n}.evaluated`),t.if((0,c._)`${e.evaluated}.dynamicProps`,()=>t.assign((0,c._)`${e.evaluated}.props`,(0,c._)`undefined`)),t.if((0,c._)`${e.evaluated}.dynamicItems`,()=>t.assign((0,c._)`${e.evaluated}.items`,(0,c._)`undefined`))}function D(e,t){let n=typeof e==`object`&&e[t.schemaId];return n&&(t.code.source||t.code.process)?(0,c._)`/*# sourceURL=${n} */`:c.nil}function O(e,n){if(A(e)&&(j(e),k(e))){re(e,n);return}(0,t.boolOrEmptySchema)(e,n)}function k({schema:e,self:t}){if(typeof e==`boolean`)return!e;for(let n in e)if(t.RULES.all[n])return!0;return!1}function A(e){return typeof e.schema!=`boolean`}function re(e,t){let{schema:n,gen:r,opts:i}=e;i.$comment&&n.$comment&&ce(e),oe(e),se(e);let a=r.const(`_errs`,l.default.errors);ie(e,a),r.var(t,(0,c._)`${a} === ${l.default.errors}`)}function j(e){(0,d.checkUnknownRules)(e),M(e)}function ie(e,t){if(e.opts.jtd)return de(e,[],!1,t);let r=(0,n.getSchemaTypes)(e.schema);de(e,r,!(0,n.coerceAndCheckDataType)(e,r),t)}function M(e){let{schema:t,errSchemaPath:n,opts:r,self:i}=e;t.$ref&&r.ignoreKeywordsWithRef&&(0,d.schemaHasRulesButRef)(t,i.RULES)&&i.logger.warn(`$ref: keywords ignored in schema at path "${n}"`)}function ae(e){let{schema:t,opts:n}=e;t.default!==void 0&&n.useDefaults&&n.strictSchema&&(0,d.checkStrictMode)(e,`default is ignored in the schema root`)}function oe(e){let t=e.schema[e.opts.schemaId];t&&(e.baseId=(0,u.resolveUrl)(e.opts.uriResolver,e.baseId,t))}function se(e){if(e.schema.$async&&!e.schemaEnv.$async)throw Error(`async schema in sync schema`)}function ce({gen:e,schemaEnv:t,schema:n,errSchemaPath:r,opts:i}){let a=n.$comment;if(i.$comment===!0)e.code((0,c._)`${l.default.self}.logger.log(${a})`);else if(typeof i.$comment==`function`){let n=(0,c.str)`${r}/$comment`,i=e.scopeValue(`root`,{ref:t.root});e.code((0,c._)`${l.default.self}.opts.$comment(${a}, ${n}, ${i}.schema)`)}}function le(e){let{gen:t,schemaEnv:n,validateName:r,ValidationError:i,opts:a}=e;n.$async?t.if((0,c._)`${l.default.errors} === 0`,()=>t.return(l.default.data),()=>t.throw((0,c._)`new ${i}(${l.default.vErrors})`)):(t.assign((0,c._)`${r}.errors`,l.default.vErrors),a.unevaluated&&ue(e),t.return((0,c._)`${l.default.errors} === 0`))}function ue({gen:e,evaluated:t,props:n,items:r}){n instanceof c.Name&&e.assign((0,c._)`${t}.props`,n),r instanceof c.Name&&e.assign((0,c._)`${t}.items`,r)}function de(e,t,n,a){let{gen:o,schema:s,data:u,allErrors:f,opts:p,self:m}=e,{RULES:h}=m;if(s.$ref&&(p.ignoreKeywordsWithRef||!(0,d.schemaHasRulesButRef)(s,h))){o.block(()=>Se(e,`$ref`,h.all.$ref.definition));return}p.jtd||pe(e,t),o.block(()=>{for(let e of h.rules)g(e);g(h.post)});function g(d){(0,r.shouldUseGroup)(s,d)&&(d.type?(o.if((0,i.checkDataType)(d.type,u,p.strictNumbers)),fe(e,d),t.length===1&&t[0]===d.type&&n&&(o.else(),(0,i.reportTypeError)(e)),o.endIf()):fe(e,d),f||o.if((0,c._)`${l.default.errors} === ${a||0}`))}}function fe(e,t){let{gen:n,schema:i,opts:{useDefaults:o}}=e;o&&(0,a.assignDefaults)(e,t.type),n.block(()=>{for(let n of t.rules)(0,r.shouldUseRule)(i,n)&&Se(e,n.keyword,n.definition,t.type)})}function pe(e,t){!e.schemaEnv.meta&&e.opts.strictTypes&&(me(e,t),e.opts.allowUnionTypes||he(e,t),ge(e,e.dataTypes))}function me(e,t){if(t.length){if(!e.dataTypes.length){e.dataTypes=t;return}t.forEach(t=>{ve(e.dataTypes,t)||be(e,`type "${t}" not allowed by context "${e.dataTypes.join(`,`)}"`)}),ye(e,t)}}function he(e,t){t.length>1&&!(t.length===2&&t.includes(`null`))&&be(e,`use allowUnionTypes to allow union type keyword`)}function ge(e,t){let n=e.self.RULES.all;for(let i in n){let a=n[i];if(typeof a==`object`&&(0,r.shouldUseRule)(e.schema,a)){let{type:n}=a.definition;n.length&&!n.some(e=>_e(t,e))&&be(e,`missing type "${n.join(`,`)}" for keyword "${i}"`)}}}function _e(e,t){return e.includes(t)||t===`number`&&e.includes(`integer`)}function ve(e,t){return e.includes(t)||t===`integer`&&e.includes(`number`)}function ye(e,t){let n=[];for(let r of e.dataTypes)ve(t,r)?n.push(r):t.includes(`integer`)&&r===`number`&&n.push(`integer`);e.dataTypes=n}function be(e,t){let n=e.schemaEnv.baseId+e.errSchemaPath;t+=` at "${n}" (strictTypes)`,(0,d.checkStrictMode)(e,t,e.opts.strictTypes)}var xe=class{constructor(e,t,n){if((0,o.validateKeywordUsage)(e,t,n),this.gen=e.gen,this.allErrors=e.allErrors,this.keyword=n,this.data=e.data,this.schema=e.schema[n],this.$data=t.$data&&e.opts.$data&&this.schema&&this.schema.$data,this.schemaValue=(0,d.schemaRefOrVal)(e,this.schema,n,this.$data),this.schemaType=t.schemaType,this.parentSchema=e.schema,this.params={},this.it=e,this.def=t,this.$data)this.schemaCode=e.gen.const(`vSchema`,Te(this.$data,e));else if(this.schemaCode=this.schemaValue,!(0,o.validSchemaType)(this.schema,t.schemaType,t.allowUndefined))throw Error(`${n} value must be ${JSON.stringify(t.schemaType)}`);(`code`in t?t.trackErrors:t.errors!==!1)&&(this.errsCount=e.gen.const(`_errs`,l.default.errors))}result(e,t,n){this.failResult((0,c.not)(e),t,n)}failResult(e,t,n){this.gen.if(e),n?n():this.error(),t?(this.gen.else(),t(),this.allErrors&&this.gen.endIf()):this.allErrors?this.gen.endIf():this.gen.else()}pass(e,t){this.failResult((0,c.not)(e),void 0,t)}fail(e){if(e===void 0){this.error(),this.allErrors||this.gen.if(!1);return}this.gen.if(e),this.error(),this.allErrors?this.gen.endIf():this.gen.else()}fail$data(e){if(!this.$data)return this.fail(e);let{schemaCode:t}=this;this.fail((0,c._)`${t} !== undefined && (${(0,c.or)(this.invalid$data(),e)})`)}error(e,t,n){if(t){this.setParams(t),this._error(e,n),this.setParams({});return}this._error(e,n)}_error(e,t){(e?f.reportExtraError:f.reportError)(this,this.def.error,t)}$dataError(){(0,f.reportError)(this,this.def.$dataError||f.keyword$DataError)}reset(){if(this.errsCount===void 0)throw Error(`add "trackErrors" to keyword definition`);(0,f.resetErrorsCount)(this.gen,this.errsCount)}ok(e){this.allErrors||this.gen.if(e)}setParams(e,t){t?Object.assign(this.params,e):this.params=e}block$data(e,t,n=c.nil){this.gen.block(()=>{this.check$data(e,n),t()})}check$data(e=c.nil,t=c.nil){if(!this.$data)return;let{gen:n,schemaCode:r,schemaType:i,def:a}=this;n.if((0,c.or)((0,c._)`${r} === undefined`,t)),e!==c.nil&&n.assign(e,!0),(i.length||a.validateSchema)&&(n.elseIf(this.invalid$data()),this.$dataError(),e!==c.nil&&n.assign(e,!1)),n.else()}invalid$data(){let{gen:e,schemaCode:t,schemaType:n,def:r,it:a}=this;return(0,c.or)(o(),s());function o(){if(n.length){if(!(t instanceof c.Name))throw Error(`ajv implementation error`);let e=Array.isArray(n)?n:[n];return(0,c._)`${(0,i.checkDataTypes)(e,t,a.opts.strictNumbers,i.DataType.Wrong)}`}return c.nil}function s(){if(r.validateSchema){let n=e.scopeValue(`validate$data`,{ref:r.validateSchema});return(0,c._)`!${n}(${t})`}return c.nil}}subschema(e,t){let n=(0,s.getSubschema)(this.it,e);(0,s.extendSubschemaData)(n,this.it,e),(0,s.extendSubschemaMode)(n,e);let r={...this.it,...n,items:void 0,props:void 0};return O(r,t),r}mergeEvaluated(e,t){let{it:n,gen:r}=this;n.opts.unevaluated&&(n.props!==!0&&e.props!==void 0&&(n.props=d.mergeEvaluated.props(r,e.props,n.props,t)),n.items!==!0&&e.items!==void 0&&(n.items=d.mergeEvaluated.items(r,e.items,n.items,t)))}mergeValidEvaluated(e,t){let{it:n,gen:r}=this;if(n.opts.unevaluated&&(n.props!==!0||n.items!==!0))return r.if(t,()=>this.mergeEvaluated(e,c.Name)),!0}};e.KeywordCxt=xe;function Se(e,t,n,r){let i=new xe(e,n,t);`code`in n?n.code(i,r):i.$data&&n.validate?(0,o.funcKeywordCode)(i,n):`macro`in n?(0,o.macroKeywordCode)(i,n):(n.compile||n.validate)&&(0,o.funcKeywordCode)(i,n)}let Ce=/^\/(?:[^~]|~0|~1)*$/,we=/^([0-9]+)(#|\/(?:[^~]|~0|~1)*)?$/;function Te(e,{dataLevel:t,dataNames:n,dataPathArr:r}){let i,a;if(e===``)return l.default.rootData;if(e[0]===`/`){if(!Ce.test(e))throw Error(`Invalid JSON-pointer: ${e}`);i=e,a=l.default.rootData}else{let o=we.exec(e);if(!o)throw Error(`Invalid JSON-pointer: ${e}`);let s=+o[1];if(i=o[2],i===`#`){if(s>=t)throw Error(u(`property/index`,s));return r[t-s]}if(s>t)throw Error(u(`data`,s));if(a=n[t-s],!i)return a}let o=a,s=i.split(`/`);for(let e of s)e&&(a=(0,c._)`${a}${(0,c.getProperty)((0,d.unescapeJsonPointer)(e))}`,o=(0,c._)`${o} && ${a}`);return o;function u(e,n){return`Cannot access ${e} ${n} levels up, current level is ${t}`}}e.getData=Te})),D=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.default=class extends Error{constructor(e){super(`validation failed`),this.errors=e,this.ajv=this.validation=!0}}})),O=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=T();e.default=class extends Error{constructor(e,n,r,i){super(i||`can't resolve reference ${r} from id ${n}`),this.missingRef=(0,t.resolveUrl)(e,n,r),this.missingSchema=(0,t.normalizeId)((0,t.getFullPath)(e,this.missingRef))}}})),k=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.resolveSchema=e.getCompilingSchema=e.resolveRef=e.compileSchema=e.SchemaEnv=void 0;let t=m(),n=D(),r=g(),i=T(),a=h(),o=E();var s=class{constructor(e){this.refs={},this.dynamicAnchors={};let t;typeof e.schema==`object`&&(t=e.schema),this.schema=e.schema,this.schemaId=e.schemaId,this.root=e.root||this,this.baseId=e.baseId??(0,i.normalizeId)(t?.[e.schemaId||`$id`]),this.schemaPath=e.schemaPath,this.localRefs=e.localRefs,this.meta=e.meta,this.$async=t?.$async,this.refs={}}};e.SchemaEnv=s;function c(e){let a=d.call(this,e);if(a)return a;let s=(0,i.getFullPath)(this.opts.uriResolver,e.root.baseId),{es5:c,lines:l}=this.opts.code,{ownProperties:u}=this.opts,f=new t.CodeGen(this.scope,{es5:c,lines:l,ownProperties:u}),p;e.$async&&(p=f.scopeValue(`Error`,{ref:n.default,code:(0,t._)`require("ajv/dist/runtime/validation_error").default`}));let m=f.scopeName(`validate`);e.validateName=m;let h={gen:f,allErrors:this.opts.allErrors,data:r.default.data,parentData:r.default.parentData,parentDataProperty:r.default.parentDataProperty,dataNames:[r.default.data],dataPathArr:[t.nil],dataLevel:0,dataTypes:[],definedProperties:new Set,topSchemaRef:f.scopeValue(`schema`,this.opts.code.source===!0?{ref:e.schema,code:(0,t.stringify)(e.schema)}:{ref:e.schema}),validateName:m,ValidationError:p,schema:e.schema,schemaEnv:e,rootId:s,baseId:e.baseId||s,schemaPath:t.nil,errSchemaPath:e.schemaPath||(this.opts.jtd?``:`#`),errorPath:(0,t._)`""`,opts:this.opts,self:this},g;try{this._compilations.add(e),(0,o.validateFunctionCode)(h),f.optimize(this.opts.code.optimize);let n=f.toString();g=`${f.scopeRefs(r.default.scope)}return ${n}`,this.opts.code.process&&(g=this.opts.code.process(g,e));let i=Function(`${r.default.self}`,`${r.default.scope}`,g)(this,this.scope.get());if(this.scope.value(m,{ref:i}),i.errors=null,i.schema=e.schema,i.schemaEnv=e,e.$async&&(i.$async=!0),this.opts.code.source===!0&&(i.source={validateName:m,validateCode:n,scopeValues:f._values}),this.opts.unevaluated){let{props:e,items:n}=h;i.evaluated={props:e instanceof t.Name?void 0:e,items:n instanceof t.Name?void 0:n,dynamicProps:e instanceof t.Name,dynamicItems:n instanceof t.Name},i.source&&(i.source.evaluated=(0,t.stringify)(i.evaluated))}return e.validate=i,e}catch(t){throw delete e.validate,delete e.validateName,g&&this.logger.error(`Error compiling schema, function code:`,g),t}finally{this._compilations.delete(e)}}e.compileSchema=c;function l(e,t,n){n=(0,i.resolveUrl)(this.opts.uriResolver,t,n);let r=e.refs[n];if(r)return r;let a=p.call(this,e,n);if(a===void 0){let r=e.localRefs?.[n],{schemaId:i}=this.opts;r&&(a=new s({schema:r,schemaId:i,root:e,baseId:t}))}if(a!==void 0)return e.refs[n]=u.call(this,a)}e.resolveRef=l;function u(e){return(0,i.inlineRef)(e.schema,this.opts.inlineRefs)?e.schema:e.validate?e:c.call(this,e)}function d(e){for(let t of this._compilations)if(f(t,e))return t}e.getCompilingSchema=d;function f(e,t){return e.schema===t.schema&&e.root===t.root&&e.baseId===t.baseId}function p(e,t){let n;for(;typeof(n=this.refs[t])==`string`;)t=n;return n||this.schemas[t]||_.call(this,e,t)}function _(e,t){let n=this.opts.uriResolver.parse(t),r=(0,i._getFullPath)(this.opts.uriResolver,n),a=(0,i.getFullPath)(this.opts.uriResolver,e.baseId,void 0);if(Object.keys(e.schema).length>0&&r===a)return y.call(this,n,e);let o=(0,i.normalizeId)(r),l=this.refs[o]||this.schemas[o];if(typeof l==`string`){let t=_.call(this,e,l);return typeof t?.schema==`object`?y.call(this,n,t):void 0}if(typeof l?.schema==`object`){if(l.validate||c.call(this,l),o===(0,i.normalizeId)(t)){let{schema:t}=l,{schemaId:n}=this.opts,r=t[n];return r&&(a=(0,i.resolveUrl)(this.opts.uriResolver,a,r)),new s({schema:t,schemaId:n,root:e,baseId:a})}return y.call(this,n,l)}}e.resolveSchema=_;let v=new Set([`properties`,`patternProperties`,`enum`,`dependencies`,`definitions`]);function y(e,{baseId:t,schema:n,root:r}){if(e.fragment?.[0]!==`/`)return;for(let r of e.fragment.slice(1).split(`/`)){if(typeof n==`boolean`)return;let e=n[(0,a.unescapeFragment)(r)];if(e===void 0)return;n=e;let o=typeof n==`object`&&n[this.opts.schemaId];!v.has(r)&&o&&(t=(0,i.resolveUrl)(this.opts.uriResolver,t,o))}let o;if(typeof n!=`boolean`&&n.$ref&&!(0,a.schemaHasRulesButRef)(n,this.RULES)){let e=(0,i.resolveUrl)(this.opts.uriResolver,t,n.$ref);o=_.call(this,r,e)}let{schemaId:c}=this.opts;if(o||=new s({schema:n,schemaId:c,root:r,baseId:t}),o.schema!==o.root.schema)return o}})),A=c({$id:()=>re,additionalProperties:()=>!1,default:()=>oe,description:()=>j,properties:()=>ae,required:()=>M,type:()=>ie}),re,j,ie,M,ae,oe,se=o((()=>{re=`https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#`,j=`Meta-schema for $data reference (JSON AnySchema extension proposal)`,ie=`object`,M=[`$data`],ae={$data:{type:`string`,anyOf:[{format:`relative-json-pointer`},{format:`json-pointer`}]}},oe={$id:re,description:j,type:ie,required:M,properties:ae,additionalProperties:!1}})),ce=s(((e,t)=>{let n=RegExp.prototype.test.bind(/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/iu),r=RegExp.prototype.test.bind(/^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)$/u),i=RegExp.prototype.test.bind(/^\d*$/u),a=RegExp.prototype.test.bind(/^[\da-f]{2}$/iu),o=RegExp.prototype.test.bind(/^[\da-z\-._~]$/iu),s=RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/]$/u),c=RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/?]$/u),l=RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:]$/u),u=Array(256);{let e=`0123456789ABCDEF`;for(let t=0;t<256;t++)u[t]=`%`+e[t>>4]+e[t&15]}function d(e){return e<2048?u[192|e>>6]+u[128|e&63]:e<65536?u[224|e>>12]+u[128|e>>6&63]+u[128|e&63]:u[240|e>>18]+u[128|e>>12&63]+u[128|e>>6&63]+u[128|e&63]}function f(e){let t=``,n=0,r=0;for(r=0;r<e.length;r++)if(n=e[r].charCodeAt(0),n!==48){if(!(n>=48&&n<=57||n>=65&&n<=70||n>=97&&n<=102))return``;t+=e[r];break}for(r+=1;r<e.length;r++){if(n=e[r].charCodeAt(0),!(n>=48&&n<=57||n>=65&&n<=70||n>=97&&n<=102))return``;t+=e[r]}return t}let p=RegExp.prototype.test.bind(/^[\dA-Fa-f]{1,4}$/),m=RegExp.prototype.test.bind(/^[vV][\dA-Fa-f]+\.[A-Za-z\d\-._~!$&'()*+,;=:]+$/),h=RegExp.prototype.test.bind(/^[A-Za-z\d\-._~]$/),g=RegExp.prototype.test.bind(/[^!"$&'()*+,\-.;=_`a-z{}~]/u);function _(e){if(e.length===0)return!1;for(let t=0;t<e.length;t++)if(!h(e[t])){if(e[t]===`%`&&t+2<e.length&&a(e.slice(t+1,t+3))){t+=2;continue}return!1}return!0}function v(e){let t=-1,n=0,r=-1,i=0;for(let a=0;a<e.length;a++)e[a]===`0`?(r===-1&&(r=a),i++,i>n&&(n=i,t=r)):(r=-1,i=0);if(n<2)return e.join(`:`);let a=e.slice(0,t).join(`:`),o=e.slice(t+n).join(`:`);return a+`::`+o}function y(e){let t=e.indexOf(`::`);if(t!==-1&&e.indexOf(`::`,t+1)!==-1)return;let n=t===-1?e.split(`:`):e.slice(0,t).split(`:`),i=t===-1?[]:e.slice(t+2).split(`:`);t!==-1&&(n.length===1&&n[0]===``&&(n.length=0),i.length===1&&i[0]===``&&(i.length=0));let a=n.concat(i),o=0;for(let e=0;e<a.length;e++){let n=a[e];if(n===``)return;if(n.indexOf(`.`)!==-1){if(e!==a.length-1||t!==-1&&i.length===0||!r(n))return;o+=2;continue}if(!p(n))return;a[e]=parseInt(n,16).toString(16),o++}if(t===-1)return o===8?v(a):void 0;if(o>=8)return;let s=a.slice(0,n.length);for(let e=o;e<8;e++)s.push(`0`);for(let e=n.length;e<a.length;e++)s.push(a[e]);return v(s)}function b(e){let t=e[0]===`[`&&e[e.length-1]===`]`;if((e[0]===`[`||e[e.length-1]===`]`)&&!t)return{host:e,isIPV6:!1,error:!0};let n=t?e.slice(1,-1):e;if(t&&m(n))return n=n.toLowerCase(),{host:`[${n}]`,escapedHost:n,isIPV6:!1,isIPVFuture:!0};if(x(n,`:`)<2)return{host:e,isIPV6:!1,error:t};let r=``,i=n.indexOf(`%`);if(i!==-1){let t=n.slice(i,i+3).toLowerCase()===`%25`?3:1;if(r=n.slice(i+t),!_(r))return{host:e,isIPV6:!1,error:!0};n=n.slice(0,i)}let a=y(n);return a===void 0?{host:e,isIPV6:!1,error:!0}:{host:a+(r?`%`+r:``),escapedHost:a+(r?`%25`+r:``),isIPV6:!0}}function x(e,t){let n=0;for(let r=0;r<e.length;r++)e[r]===t&&n++;return n}function S(e){let t=e,n=[],r=-1,i=0;for(;i=t.length;){if(i===1){if(t===`.`)break;if(t===`/`){n.push(`/`);break}n.push(t);break}if(i===2){if(t[0]===`.`){if(t[1]===`.`)break;if(t[1]===`/`){t=t.slice(2);continue}}else if(t[0]===`/`&&(t[1]===`.`||t[1]===`/`)){n.push(`/`);break}}else if(i===3&&t===`/..`){n.length!==0&&n.pop(),n.push(`/`);break}if(t[0]===`.`){if(t[1]===`.`){if(t[2]===`/`){t=t.slice(3);continue}}else if(t[1]===`/`){t=t.slice(2);continue}}else if(t[0]===`/`&&t[1]===`.`){if(t[2]===`/`){t=t.slice(2);continue}if(t[2]===`.`&&t[3]===`/`){t=t.slice(3),n.length!==0&&n.pop();continue}}if((r=t.indexOf(`/`,1))===-1){n.push(t);break}n.push(t.slice(0,r)),t=t.slice(r)}return n.join(``)}let C={"@":`%40`,"/":`%2F`,"?":`%3F`,"#":`%23`,":":`%3A`},w=/[@/?#:]/g,ee=/[@/?#]/g;function te(e,t){let n=t?ee:w;return n.lastIndex=0,e.replace(n,e=>C[e])}function ne(e,t=!1){if(e.indexOf(`%`)===-1)return e;let n=``;for(let r=0;r<e.length;r++){if(e[r]===`%`&&r+2<e.length){let i=e.slice(r+1,r+3);if(a(i)){let e=i.toUpperCase(),a=String.fromCharCode(parseInt(e,16));t&&o(a)?n+=a:n+=`%`+e,r+=2;continue}}n+=e[r]}return n}function T(e){let t=``;for(let n=0;n<e.length;n++){let r=e[n];if(r===`%`&&n+2<e.length){let r=e.slice(n+1,n+3);if(a(r)){let e=r.toUpperCase(),i=String.fromCharCode(parseInt(e,16));i!==`.`&&o(i)?t+=i:t+=`%`+e,n+=2;continue}}if(s(r))t+=r;else{let i=e.charCodeAt(n);if(i<128)t+=re(i)?r:u[i];else if(i<55296||i>57343)t+=d(i);else if(i<=56319&&n+1<e.length){let r=e.charCodeAt(n+1);r>=56320&&r<=57343?(t+=d(65536+(i-55296<<10)+(r-56320)),n++):t+=d(65533)}else t+=d(65533)}}return t}function E(e,t=!1){let n=``,r=t&&e[0]!==`/`;for(let t=0;t<e.length;t++){let i=e[t];if(i===`%`&&t+2<e.length){let r=e.slice(t+1,t+3);if(a(r)){n+=`%`+r.toUpperCase(),t+=2;continue}}if(i===`/`&&(r=!1),s(i)&&(i!==`:`||!r))n+=i;else{let r=e.charCodeAt(t);if(r<128)n+=u[r];else if(r<55296||r>57343)n+=d(r);else if(r<=56319&&t+1<e.length){let i=e.charCodeAt(t+1);i>=56320&&i<=57343?(n+=d(65536+(r-55296<<10)+(i-56320)),t++):n+=d(65533)}else n+=d(65533)}}return n}function D(e,t){let n=``;for(let r=0;r<e.length;r++){let i=e[r];if(i===`%`&&r+2<e.length){let t=e.slice(r+1,r+3);if(a(t)){n+=`%`+t.toUpperCase(),r+=2;continue}}if(t(i))n+=i;else{let t=e.charCodeAt(r);if(t<128)n+=u[t];else if(t<55296||t>57343)n+=d(t);else if(t<=56319&&r+1<e.length){let i=e.charCodeAt(r+1);i>=56320&&i<=57343?(n+=d(65536+(t-55296<<10)+(i-56320)),r++):n+=d(65533)}else n+=d(65533)}}return n}function O(e){return D(e,l)}function k(e){return D(e,c)}function A(e){return D(e,c)}function re(e){return e>=48&&e<=57||e>=65&&e<=90||e>=97&&e<=122||e===42||e===43||e===45||e===46||e===47||e===64||e===95}function j(e){let t=``;for(let n=0;n<e.length;n++){let r=e[n];if(r===`%`&&n+2<e.length){let r=e.slice(n+1,n+3);if(a(r)){let e=r.toUpperCase(),i=String.fromCharCode(parseInt(e,16));o(i)?t+=i:t+=`%`+e,n+=2;continue}}if(c(r))t+=r;else{let i=e.charCodeAt(n);if(i<128)t+=re(i)?r:u[i];else if(i<55296||i>57343)t+=d(i);else if(i<=56319&&n+1<e.length){let r=e.charCodeAt(n+1);r>=56320&&r<=57343?(t+=d(65536+(i-55296<<10)+(r-56320)),n++):t+=d(65533)}else t+=d(65533)}}return t}function ie(e){let t=``;for(let n=0;n<e.length;n++){if(e[n]===`%`&&n+2<e.length){let r=e.slice(n+1,n+3);if(a(r)){t+=`%`+r.toUpperCase(),n+=2;continue}}t+=escape(e[n])}return t}function M(e){let t=[];if(e.userinfo!==void 0&&(t.push(O(e.userinfo)),t.push(`@`)),e.host!==void 0){let n=e.host;if(!r(n)){let e=b(n);e.isIPV6!==!0&&e.isIPVFuture!==!0&&(n=ne(n,!0),e=b(n)),n=e.isIPV6===!0||e.isIPVFuture===!0?`[${e.escapedHost}]`:te(n,!1)}t.push(n)}if(typeof e.port==`number`||typeof e.port==`string`){let n=String(e.port);if(!i(n))throw TypeError(`URI port is malformed.`);t.push(`:`),t.push(n)}return t.length?t.join(``):void 0}t.exports={nonSimpleDomain:g,recomposeAuthority:M,reescapeHostDelimiters:te,normalizePercentEncoding:ne,normalizePathEncoding:T,serializePathEncoding:E,normalizeQueryFragmentEncoding:j,encodeUserinfo:O,encodeQuery:k,encodeFragment:A,escapePreservingEscapes:ie,removeDotSegments:S,isIPv4:r,isUUID:n,normalizeIPv6:b,stringArrayToHexStripped:f}})),le=s(((e,t)=>{let{isUUID:n}=ce(),r=/^([\da-z][\d\-a-z]{0,31}):((?:[\w!$'()*+,\-./:;=@]|%[\da-f]{2})+)$/iu,i=[`http`,`https`,`ws`,`wss`,`urn`,`urn:uuid`];function a(e){return i.indexOf(e)!==-1}function o(e){return e.secure===!0?!0:e.secure===!1?!1:e.scheme?e.scheme.length===3&&(e.scheme[0]===`w`||e.scheme[0]===`W`)&&(e.scheme[1]===`s`||e.scheme[1]===`S`)&&(e.scheme[2]===`s`||e.scheme[2]===`S`):!1}function s(e){return e.host||(e.error=e.error||`HTTP URIs must have a host.`),e}function c(e){let t=String(e.scheme).toLowerCase()===`https`;return(e.port===(t?443:80)||e.port===``)&&(e.port=void 0),e.path||=`/`,e}function l(e){return e.secure=o(e),e.resourceName=(e.path||`/`)+(e.query?`?`+e.query:``),e.path=void 0,e.query=void 0,e}function u(e){if((e.port===(o(e)?443:80)||e.port===``)&&(e.port=void 0),typeof e.secure==`boolean`&&(e.scheme=e.secure?`wss`:`ws`,e.secure=void 0),e.resourceName){let t=e.resourceName.indexOf(`?`),n=t===-1?e.resourceName:e.resourceName.slice(0,t);e.path=n&&n!==`/`?n:void 0,e.query=t===-1?void 0:e.resourceName.slice(t+1),e.resourceName=void 0}return e.fragment=void 0,e}function d(e,t){if(!e.path)return e.error=`URN can not be parsed`,e;let n=e.path.match(r);if(n&&n[0]===e.path){let r=t.scheme||e.scheme||`urn`;e.nid=n[1].toLowerCase(),e.nss=n[2];let i=y(`${r}:${t.nid||e.nid}`);e.path=void 0,i&&(e=i.parse(e,t))}else e.error=e.error||`URN can not be parsed.`;return e}function f(e,t){if(e.nid===void 0)throw Error(`URN without nid cannot be serialized`);let n=t.scheme||e.scheme||`urn`,r=e.nid.toLowerCase(),i=y(`${n}:${t.nid||r}`);i&&(e=i.serialize(e,t));let a=e,o=e.nss;return a.path=`${r||t.nid}:${o}`,t.skipEscape=!0,a}function p(e,t){let r=e;return r.uuid=r.nss,r.nss=void 0,!t.tolerant&&(!r.uuid||!n(r.uuid))&&(r.error=r.error||`UUID is not valid.`),r}function m(e){let t=e;return t.nss=(e.uuid||``).toLowerCase(),t}let h={scheme:`http`,domainHost:!0,parse:s,serialize:c},g={scheme:`https`,domainHost:h.domainHost,parse:s,serialize:c},_={scheme:`ws`,domainHost:!0,parse:l,serialize:u},v={http:h,https:g,ws:_,wss:{scheme:`wss`,domainHost:_.domainHost,parse:_.parse,serialize:_.serialize},urn:{scheme:`urn`,parse:d,serialize:f,skipNormalize:!0},"urn:uuid":{scheme:`urn:uuid`,parse:p,serialize:m,skipNormalize:!0}};Object.setPrototypeOf(v,null);function y(e){return e&&(v[e]||v[e.toLowerCase()])||void 0}t.exports={wsIsSecure:o,SCHEMES:v,isValidSchemeName:a,getSchemeHandler:y}})),ue=s(((e,t)=>{let{normalizeIPv6:n,removeDotSegments:r,recomposeAuthority:i,normalizePercentEncoding:a,normalizePathEncoding:o,serializePathEncoding:s,normalizeQueryFragmentEncoding:c,encodeQuery:l,encodeFragment:u,reescapeHostDelimiters:d,isIPv4:f,nonSimpleDomain:p}=ce(),{SCHEMES:m,getSchemeHandler:h}=le(),g=/^[A-Za-z][A-Za-z0-9+.-]*$/u,_=`URI scheme is malformed.`;function v(e){let t=unescape(String(e));if(!g.test(t))throw TypeError(_);return t}function y(e,t){return typeof e==`string`?e=re(e,t):typeof e==`object`&&(e=A(C(e,t),t)),e}function b(e,t,r){let i=r?Object.assign({scheme:`null`},r):{scheme:`null`},{parsed:a,malformedAuthorityOrPort:o,malformedPercentEncoding:s,malformedSchemeSpecific:c,malformedHost:l,malformedScheme:u}=k(e,i),{parsed:d,malformedAuthorityOrPort:p,malformedPercentEncoding:m,malformedSchemeSpecific:g,malformedHost:_,malformedScheme:v}=k(t,i);if(o||p||s||m||c||g||l||_||u||v)throw Error(a.error||d.error||`URI is malformed.`);let y=x(a,d,i,!0),b=h(r&&r.scheme||y.scheme),S=y.host,w=S!==void 0&&S!==``&&(f(S)||n(S).isIPV6);O(y,r||{},b,w);let ee=S&&S.indexOf(`%`)!==-1&&!/\P{ASCII}/u.test(S);if(y.error&&!ee)throw Error(y.error);return i.skipEscape=!0,C(y,i)}function x(e,t,n,i){let a={};return i||(e=A(C(e,n),n),t=A(C(t,n),n)),n||={},!n.tolerant&&t.scheme?(a.scheme=t.scheme,a.userinfo=t.userinfo,a.host=t.host,a.port=t.port,a.path=r(t.path||``),a.query=t.query):(t.userinfo!==void 0||t.host!==void 0||t.port!==void 0?(a.userinfo=t.userinfo,a.host=t.host,a.port=t.port,a.path=r(t.path||``),a.query=t.query):(t.path?(t.path[0]===`/`?a.path=r(t.path):(a.path=(e.userinfo!==void 0||e.host!==void 0||e.port!==void 0)&&!e.path?`/`+t.path:e.path?e.path.slice(0,e.path.lastIndexOf(`/`)+1)+t.path:t.path,a.path=r(a.path)),a.query=t.query):(a.path=e.path,a.query=t.query===void 0?e.query:t.query),a.userinfo=e.userinfo,a.host=e.host,a.port=e.port),a.scheme=e.scheme),a.fragment=t.fragment,a}function S(e,t,n){let r=ie(e,n),i=ie(t,n);return r!==void 0&&i!==void 0&&r===i}function C(e,t){let n={host:e.host,scheme:e.scheme,userinfo:e.userinfo,port:e.port,path:e.path,query:e.query,nid:e.nid,nss:e.nss,uuid:e.uuid,fragment:e.fragment,reference:e.reference,resourceName:e.resourceName,secure:e.secure,error:``},o=Object.assign({},t),c=[];n.scheme&&=v(n.scheme);let d=h(o.scheme||n.scheme);d&&d.serialize&&d.serialize(n,o);let f=n.userinfo!==void 0||n.host!==void 0||n.port!==void 0,p=!o.skipEscape&&n.scheme===void 0&&!f;n.path!==void 0&&(n.path=o.skipEscape?a(n.path):s(n.path,p)),o.reference!==`suffix`&&n.scheme&&(n.scheme=v(n.scheme),c.push(n.scheme,`:`));let m=i(n);if(m!==void 0&&(o.reference!==`suffix`&&c.push(`//`),c.push(m),n.path&&n.path[0]!==`/`&&c.push(`/`)),n.path!==void 0){let e=n.path;!o.absolutePath&&(!d||!d.absolutePath)&&(e=r(e)),p&&(e=s(e,!0)),m===void 0&&e[0]===`/`&&e[1]===`/`&&(e=`/%2F`+e.slice(2)),c.push(e)}return n.query!==void 0&&c.push(`?`,l(n.query)),n.fragment!==void 0&&c.push(`#`,u(n.fragment)),c.join(``)}let w=/^(?:([^#/:?]+):)?(?:\/\/((?:([^#/?@]*)@)?(\[[^#/?\]]+\]|[^#/:?]*)(?::(\d*))?))?([^#?]*)(?:\?([^#]*))?(?:#((?:.|[\n\r])*))?/u,ee=/^(?:[^#/:?]+:)?\/\/([^/?#]*)/,te=/^(?:[^#/:?]+:)?([/\\\t\n\r]*)/;function ne(e,t){if(t[2]!==void 0&&e.path&&e.path[0]!==`/`)return`URI path must start with "/" when authority is present.`;if(typeof e.port==`number`&&(e.port<0||e.port>65535))return`URI port is malformed.`}function T(e){if(e===void 0)return!1;let t=e.indexOf(`%`);for(;t!==-1;){if(t+2>=e.length||!/^[\da-f]{2}$/iu.test(e.slice(t+1,t+3)))return!0;t=e.indexOf(`%`,t+3)}return!1}function E(e){return e[0]===`[`&&e[e.length-1]===`]`}function D(e){let t=e[4];return T(e[3])||t!==void 0&&!E(t)&&T(t)||T(e[6])||T(e[7])||T(e[8])}function O(e,t,n,r){if(!t.unicodeSupport&&(!n||!n.unicodeSupport)&&e.host&&!E(e.host)&&(t.domainHost||n&&n.domainHost)&&r===!1&&p(e.host))try{e.host=new URL(`http://`+e.host).hostname}catch(t){return e.error=e.error||`Host's domain name can not be converted to ASCII: `+t,!0}return!1}function k(e,t){let r=Object.assign({},t),i={scheme:void 0,userinfo:void 0,host:``,port:void 0,path:``,query:void 0,fragment:void 0},s=!1,l=!1,u=!1,p=!1,v=!1,y=!1,b=!1;r.reference===`suffix`&&(e=r.scheme?r.scheme+`:`+e:`//`+e);let x=e.match(ee);x!==null&&x[1].indexOf(`\\`)!==-1&&(i.error=`URI authority must not contain a literal backslash.`,s=!0);let S=e.match(te);if(S!==null){let e=S[1],t=e.replace(/[\t\n\r]/g,``);t.length>=2&&(t.slice(0,2)===`//`?e.length!==t.length&&(i.error=i.error||`URI authority introducer must not contain whitespace.`,s=!0):(i.error=i.error||`URI authority must not contain a literal backslash.`,s=!0))}let C=e.match(w);if(C){if(i.scheme=C[1],i.userinfo=C[3],i.host=C[4],i.port=parseInt(C[5],10),i.path=C[6]||``,i.query=C[7],i.fragment=C[8],i.scheme!==void 0){let e=unescape(i.scheme);g.test(e)?i.scheme=e.toLowerCase():(i.error=i.error||_,y=!0)}l=D(C),l&&(i.error=i.error||`URI contains malformed percent-encoding.`),isNaN(i.port)&&(i.port=C[5]);let t=ne(i,C);if(t!==void 0&&(i.error=i.error||t,s=!0),i.host){if(f(i.host)===!1){let e=E(i.host),t=i.host.indexOf(`[`)!==-1||i.host.indexOf(`]`)!==-1,r=n(i.host);b=r.isIPV6||r.isIPVFuture===!0,v=t&&(!e||r.error===!0),i.host=b?r.host:r.host.toLowerCase(),v&&(i.error=i.error||`URI host is malformed.`,s=!0)}else b=!0}i.reference=i.scheme===void 0&&i.userinfo===void 0&&i.host===void 0&&i.port===void 0&&i.query===void 0&&!i.path?`same-document`:i.scheme===void 0?`relative`:i.fragment===void 0?`absolute`:`uri`,r.reference&&r.reference!==`suffix`&&r.reference!==i.reference&&(i.error=i.error||`URI is not a `+r.reference+` reference.`);let x=h(r.scheme||i.scheme);if(v||(p=O(i,r,x,b)),!x||x&&!x.skipNormalize){if(e.indexOf(`%`)!==-1&&i.host!==void 0&&!v){let e=b?i.host:a(i.host,!0);i.host=d(e,b)}i.path&&=o(i.path),i.query&&=c(i.query),i.fragment&&=c(i.fragment)}x&&x.parse&&(x.parse(i,r),x===m.urn&&i.nid===void 0&&(u=!0))}else i.error=i.error||`URI can not be parsed.`;return{parsed:i,malformedAuthorityOrPort:s,malformedPercentEncoding:l,malformedSchemeSpecific:u,malformedHost:p,malformedScheme:y}}function A(e,t){return k(e,t).parsed}function re(e,t){return j(e,t).normalized}function j(e,t){let{parsed:n,malformedAuthorityOrPort:r,malformedPercentEncoding:i,malformedSchemeSpecific:a,malformedHost:o,malformedScheme:s}=k(e,t);return{normalized:r||i||a||o||s?e:C(n,t),malformedAuthorityOrPort:r,malformedPercentEncoding:i,malformedSchemeSpecific:a,malformedHost:o,malformedScheme:s}}function ie(e,t){if(typeof e!=`string`&&typeof e!=`object`)return;let n;try{n=typeof e==`string`?e:C(e,t)}catch{return}let{normalized:r,malformedAuthorityOrPort:i,malformedPercentEncoding:a,malformedSchemeSpecific:o,malformedHost:s,malformedScheme:c}=j(n,t);return i||a||o||s||c?void 0:r}let M={SCHEMES:m,normalize:y,resolve:b,resolveComponent:x,equal:S,serialize:C,parse:A};t.exports=M,t.exports.default=M,t.exports.fastUri=M})),de=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=ue();t.code=`require("ajv/dist/runtime/uri").default`,e.default=t})),fe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.CodeGen=e.Name=e.nil=e.stringify=e.str=e._=e.KeywordCxt=void 0;var t=E();Object.defineProperty(e,"KeywordCxt",{enumerable:!0,get:function(){return t.KeywordCxt}});var n=m();Object.defineProperty(e,"_",{enumerable:!0,get:function(){return n._}}),Object.defineProperty(e,"str",{enumerable:!0,get:function(){return n.str}}),Object.defineProperty(e,"stringify",{enumerable:!0,get:function(){return n.stringify}}),Object.defineProperty(e,"nil",{enumerable:!0,get:function(){return n.nil}}),Object.defineProperty(e,"Name",{enumerable:!0,get:function(){return n.Name}}),Object.defineProperty(e,"CodeGen",{enumerable:!0,get:function(){return n.CodeGen}});let r=D(),i=O(),a=y(),o=k(),s=m(),c=T(),l=x(),u=h(),f=(se(),d(A).default),p=de(),g=(e,t)=>new RegExp(e,t);g.code=`new RegExp`;let _=[`removeAdditional`,`useDefaults`,`coerceTypes`],v=new Set([`validate`,`serialize`,`parse`,`wrapper`,`root`,`schema`,`keyword`,`pattern`,`formats`,`validate$data`,`func`,`obj`,`Error`]),b={errorDataPath:``,format:"`validateFormats: false` can be used instead.",nullable:`"nullable" keyword is supported by default.`,jsonPointers:`Deprecated jsPropertySyntax can be used instead.`,extendRefs:`Deprecated ignoreKeywordsWithRef can be used instead.`,missingRefs:`Pass empty schema with $id that should be ignored to ajv.addSchema.`,processCode:"Use option `code: {process: (code, schemaEnv: object) => string}`",sourceCode:"Use option `code: {source: true}`",strictDefaults:"It is default now, see option `strict`.",strictKeywords:"It is default now, see option `strict`.",uniqueItems:`"uniqueItems" keyword is always validated.`,unknownFormats:"Disable strict mode or pass `true` to `ajv.addFormat` (or `formats` option).",cache:`Map is used as cache, schema object as key.`,serialize:`Map is used as cache, schema object as key.`,ajvErrors:`It is default now.`},S={ignoreKeywordsWithRef:``,jsPropertySyntax:``,unicode:`"minLength"/"maxLength" account for unicode characters by default.`};function C(e){let t=e.strict,n=e.code?.optimize,r=n===!0||n===void 0?1:n||0,i=e.code?.regExp??g,a=e.uriResolver??p.default;return{strictSchema:e.strictSchema??t??!0,strictNumbers:e.strictNumbers??t??!0,strictTypes:e.strictTypes??t??`log`,strictTuples:e.strictTuples??t??`log`,strictRequired:e.strictRequired??t??!1,code:e.code?{...e.code,optimize:r,regExp:i}:{optimize:r,regExp:i},loopRequired:e.loopRequired??200,loopEnum:e.loopEnum??200,meta:e.meta??!0,messages:e.messages??!0,inlineRefs:e.inlineRefs??!0,schemaId:e.schemaId??`$id`,addUsedSchema:e.addUsedSchema??!0,validateSchema:e.validateSchema??!0,validateFormats:e.validateFormats??!0,unicodeRegExp:e.unicodeRegExp??!0,int32range:e.int32range??!0,uriResolver:a}}var w=class{constructor(e={}){this.schemas={},this.refs={},this.formats={},this._compilations=new Set,this._loading={},this._cache=new Map,e=this.opts={...e,...C(e)};let{es5:t,lines:n}=this.opts.code;this.scope=new s.ValueScope({scope:{},prefixes:v,es5:t,lines:n}),this.logger=ae(e.logger);let r=e.validateFormats;e.validateFormats=!1,this.RULES=(0,a.getRules)(),ee.call(this,b,e,`NOT SUPPORTED`),ee.call(this,S,e,`DEPRECATED`,`warn`),this._metaOpts=ie.call(this),e.formats&&re.call(this),this._addVocabularies(),this._addDefaultMetaSchema(),e.keywords&&j.call(this,e.keywords),typeof e.meta==`object`&&this.addMetaSchema(e.meta),ne.call(this),e.validateFormats=r}_addVocabularies(){this.addKeyword(`$async`)}_addDefaultMetaSchema(){let{$data:e,meta:t,schemaId:n}=this.opts,r=f;n===`id`&&(r={...f},r.id=r.$id,delete r.$id),t&&e&&this.addMetaSchema(r,r[n],!1)}defaultMeta(){let{meta:e,schemaId:t}=this.opts;return this.opts.defaultMeta=typeof e==`object`?e[t]||e:void 0}validate(e,t){let n;if(typeof e==`string`){if(n=this.getSchema(e),!n)throw Error(`no schema with key or ref "${e}"`)}else n=this.compile(e);let r=n(t);return`$async`in n||(this.errors=n.errors),r}compile(e,t){let n=this._addSchema(e,t);return n.validate||this._compileSchemaEnv(n)}compileAsync(e,t){if(typeof this.opts.loadSchema!=`function`)throw Error(`options.loadSchema should be a function`);let{loadSchema:n}=this.opts;return r.call(this,e,t);async function r(e,t){await a.call(this,e.$schema);let n=this._addSchema(e,t);return n.validate||o.call(this,n)}async function a(e){e&&!this.getSchema(e)&&await r.call(this,{$ref:e},!0)}async function o(e){try{return this._compileSchemaEnv(e)}catch(t){if(!(t instanceof i.default))throw t;return s.call(this,t),await c.call(this,t.missingSchema),o.call(this,e)}}function s({missingSchema:e,missingRef:t}){if(this.refs[e])throw Error(`AnySchema ${e} is loaded but ${t} cannot be resolved`)}async function c(e){let n=await l.call(this,e);this.refs[e]||await a.call(this,n.$schema),this.refs[e]||this.addSchema(n,e,t)}async function l(e){let t=this._loading[e];if(t)return t;try{return await(this._loading[e]=n(e))}finally{delete this._loading[e]}}}addSchema(e,t,n,r=this.opts.validateSchema){if(Array.isArray(e)){for(let t of e)this.addSchema(t,void 0,n,r);return this}let i;if(typeof e==`object`){let{schemaId:t}=this.opts;if(i=e[t],i!==void 0&&typeof i!=`string`)throw Error(`schema ${t} must be string`)}return t=(0,c.normalizeId)(t||i),this._checkUnique(t),this.schemas[t]=this._addSchema(e,n,t,r,!0),this}addMetaSchema(e,t,n=this.opts.validateSchema){return this.addSchema(e,t,!0,n),this}validateSchema(e,t){if(typeof e==`boolean`)return!0;let n;if(n=e.$schema,n!==void 0&&typeof n!=`string`)throw Error(`$schema must be a string`);if(n=n||this.opts.defaultMeta||this.defaultMeta(),!n)return this.logger.warn(`meta-schema not available`),this.errors=null,!0;let r=this.validate(n,e);if(!r&&t){let e=`schema is invalid: `+this.errorsText();if(this.opts.validateSchema===`log`)this.logger.error(e);else throw Error(e)}return r}getSchema(e){let t;for(;typeof(t=te.call(this,e))==`string`;)e=t;if(t===void 0){let{schemaId:n}=this.opts,r=new o.SchemaEnv({schema:{},schemaId:n});if(t=o.resolveSchema.call(this,r,e),!t)return;this.refs[e]=t}return t.validate||this._compileSchemaEnv(t)}removeSchema(e){if(e instanceof RegExp)return this._removeAllSchemas(this.schemas,e),this._removeAllSchemas(this.refs,e),this;switch(typeof e){case`undefined`:return this._removeAllSchemas(this.schemas),this._removeAllSchemas(this.refs),this._cache.clear(),this;case`string`:{let t=te.call(this,e);return typeof t==`object`&&this._cache.delete(t.schema),delete this.schemas[e],delete this.refs[e],this}case`object`:{let t=e;this._cache.delete(t);let n=e[this.opts.schemaId];return n&&(n=(0,c.normalizeId)(n),delete this.schemas[n],delete this.refs[n]),this}default:throw Error(`ajv.removeSchema: invalid parameter`)}}addVocabulary(e){for(let t of e)this.addKeyword(t);return this}addKeyword(e,t){let n;if(typeof e==`string`)n=e,typeof t==`object`&&(this.logger.warn(`these parameters are deprecated, see docs for addKeyword`),t.keyword=n);else if(typeof e==`object`&&t===void 0){if(t=e,n=t.keyword,Array.isArray(n)&&!n.length)throw Error(`addKeywords: keyword must be string or non-empty array`)}else throw Error(`invalid addKeywords parameters`);if(ce.call(this,n,t),!t)return(0,u.eachItem)(n,e=>le.call(this,e)),this;fe.call(this,t);let r={...t,type:(0,l.getJSONTypes)(t.type),schemaType:(0,l.getJSONTypes)(t.schemaType)};return(0,u.eachItem)(n,r.type.length===0?e=>le.call(this,e,r):e=>r.type.forEach(t=>le.call(this,e,r,t))),this}getKeyword(e){let t=this.RULES.all[e];return typeof t==`object`?t.definition:!!t}removeKeyword(e){let{RULES:t}=this;delete t.keywords[e],delete t.all[e];for(let n of t.rules){let t=n.rules.findIndex(t=>t.keyword===e);t>=0&&n.rules.splice(t,1)}return this}addFormat(e,t){return typeof t==`string`&&(t=new RegExp(t)),this.formats[e]=t,this}errorsText(e=this.errors,{separator:t=`, `,dataVar:n=`data`}={}){return!e||e.length===0?`No errors`:e.map(e=>`${n}${e.instancePath} ${e.message}`).reduce((e,n)=>e+t+n)}$dataMetaSchema(e,t){let n=this.RULES.all;e=JSON.parse(JSON.stringify(e));for(let r of t){let t=r.split(`/`).slice(1),i=e;for(let e of t)i=i[e];for(let e in n){let t=n[e];if(typeof t!=`object`)continue;let{$data:r}=t.definition,a=i[e];r&&a&&(i[e]=me(a))}}return e}_removeAllSchemas(e,t){for(let n in e){let r=e[n];(!t||t.test(n))&&(typeof r==`string`?delete e[n]:r&&!r.meta&&(this._cache.delete(r.schema),delete e[n]))}}_addSchema(e,t,n,r=this.opts.validateSchema,i=this.opts.addUsedSchema){let a,{schemaId:s}=this.opts;if(typeof e==`object`)a=e[s];else if(this.opts.jtd)throw Error(`schema must be object`);else if(typeof e!=`boolean`)throw Error(`schema must be object or boolean`);let l=this._cache.get(e);if(l!==void 0)return l;n=(0,c.normalizeId)(a||n);let u=c.getSchemaRefs.call(this,e,n);return l=new o.SchemaEnv({schema:e,schemaId:s,meta:t,baseId:n,localRefs:u}),this._cache.set(l.schema,l),i&&!n.startsWith(`#`)&&(n&&this._checkUnique(n),this.refs[n]=l),r&&this.validateSchema(e,!0),l}_checkUnique(e){if(this.schemas[e]||this.refs[e])throw Error(`schema with key or id "${e}" already exists`)}_compileSchemaEnv(e){if(e.meta?this._compileMetaSchema(e):o.compileSchema.call(this,e),!e.validate)throw Error(`ajv implementation error`);return e.validate}_compileMetaSchema(e){let t=this.opts;this.opts=this._metaOpts;try{o.compileSchema.call(this,e)}finally{this.opts=t}}};w.ValidationError=r.default,w.MissingRefError=i.default,e.default=w;function ee(e,t,n,r=`error`){for(let i in e){let a=i;a in t&&this.logger[r](`${n}: option ${i}. ${e[a]}`)}}function te(e){return e=(0,c.normalizeId)(e),this.schemas[e]||this.refs[e]}function ne(){let e=this.opts.schemas;if(e){if(Array.isArray(e))this.addSchema(e);else for(let t in e)this.addSchema(e[t],t)}}function re(){for(let e in this.opts.formats){let t=this.opts.formats[e];t&&this.addFormat(e,t)}}function j(e){if(Array.isArray(e)){this.addVocabulary(e);return}this.logger.warn(`keywords option as map is deprecated, pass array`);for(let t in e){let n=e[t];n.keyword||=t,this.addKeyword(n)}}function ie(){let e={...this.opts};for(let t of _)delete e[t];return e}let M={log(){},warn(){},error(){}};function ae(e){if(e===!1)return M;if(e===void 0)return console;if(e.log&&e.warn&&e.error)return e;throw Error(`logger must implement log, warn and error methods`)}let oe=/^[a-z_$][a-z0-9_$:-]*$/i;function ce(e,t){let{RULES:n}=this;if((0,u.eachItem)(e,e=>{if(n.keywords[e])throw Error(`Keyword ${e} is already defined`);if(!oe.test(e))throw Error(`Keyword ${e} has invalid name`)}),t&&t.$data&&!(`code`in t||`validate`in t))throw Error(`$data keyword must have "code" or "validate" function`)}function le(e,t,n){var r;let i=t?.post;if(n&&i)throw Error(`keyword with "post" flag cannot have "type"`);let{RULES:a}=this,o=i?a.post:a.rules.find(({type:e})=>e===n);if(o||(o={type:n,rules:[]},a.rules.push(o)),a.keywords[e]=!0,!t)return;let s={keyword:e,definition:{...t,type:(0,l.getJSONTypes)(t.type),schemaType:(0,l.getJSONTypes)(t.schemaType)}};t.before?ue.call(this,o,s,t.before):o.rules.push(s),a.all[e]=s,(r=t.implements)==null||r.forEach(e=>this.addKeyword(e))}function ue(e,t,n){let r=e.rules.findIndex(e=>e.keyword===n);r>=0?e.rules.splice(r,0,t):(e.rules.push(t),this.logger.warn(`rule ${n} is not defined`))}function fe(e){let{metaSchema:t}=e;t!==void 0&&(e.$data&&this.opts.$data&&(t=me(t)),e.validateSchema=this.compile(t,!0))}let pe={$ref:`https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#`};function me(e){return{anyOf:[e,pe]}}})),pe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.default={keyword:`id`,code(){throw Error(`NOT SUPPORTED: keyword "id", use "$id" for schema ID`)}}})),me=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.callRef=e.getValidate=void 0;let t=O(),n=C(),r=m(),i=g(),a=k(),o=h(),s={keyword:`$ref`,schemaType:`string`,code(e){let{gen:n,schema:i,it:o}=e,{baseId:s,schemaEnv:u,validateName:d,opts:f,self:p}=o,{root:m}=u;if((i===`#`||i===`#/`)&&s===m.baseId)return g();let h=a.resolveRef.call(p,m,s,i);if(h===void 0)throw new t.default(o.opts.uriResolver,s,i);return h instanceof a.SchemaEnv?_(h):v(h);function g(){if(u===m)return l(e,d,u,u.$async);let t=n.scopeValue(`root`,{ref:m});return l(e,(0,r._)`${t}.validate`,m,m.$async)}function _(t){l(e,c(e,t),t,t.$async)}function v(t){let a=n.scopeValue(`schema`,f.code.source===!0?{ref:t,code:(0,r.stringify)(t)}:{ref:t}),o=n.name(`valid`),s=e.subschema({schema:t,dataTypes:[],schemaPath:r.nil,topSchemaRef:a,errSchemaPath:i},o);e.mergeEvaluated(s),e.ok(o)}}};function c(e,t){let{gen:n}=e;return t.validate?n.scopeValue(`validate`,{ref:t.validate}):(0,r._)`${n.scopeValue(`wrapper`,{ref:t})}.validate`}e.getValidate=c;function l(e,t,a,s){let{gen:c,it:l}=e,{allErrors:u,schemaEnv:d,opts:f}=l,p=f.passContext?i.default.this:r.nil;s?m():h();function m(){if(!d.$async)throw Error(`async schema referenced by sync schema`);let i=c.let(`valid`);c.try(()=>{c.code((0,r._)`await ${(0,n.callValidateCode)(e,t,p)}`),_(t),u||c.assign(i,!0)},e=>{c.if((0,r._)`!(${e} instanceof ${l.ValidationError})`,()=>c.throw(e)),g(e),u||c.assign(i,!1)}),e.ok(i)}function h(){e.result((0,n.callValidateCode)(e,t,p),()=>_(t),()=>g(t))}function g(e){let t=(0,r._)`${e}.errors`;c.assign(i.default.vErrors,(0,r._)`${i.default.vErrors} === null ? ${t} : ${i.default.vErrors}.concat(${t})`),c.assign(i.default.errors,(0,r._)`${i.default.vErrors}.length`)}function _(e){if(!l.opts.unevaluated)return;let t=a?.validate?.evaluated;if(l.props!==!0){if(t&&!t.dynamicProps)t.props!==void 0&&(l.props=o.mergeEvaluated.props(c,t.props,l.props));else{let t=c.var(`props`,(0,r._)`${e}.evaluated.props`);l.props=o.mergeEvaluated.props(c,t,l.props,r.Name)}}if(l.items!==!0){if(t&&!t.dynamicItems)t.items!==void 0&&(l.items=o.mergeEvaluated.items(c,t.items,l.items));else{let t=c.var(`items`,(0,r._)`${e}.evaluated.items`);l.items=o.mergeEvaluated.items(c,t,l.items,r.Name)}}}}e.callRef=l,e.default=s})),he=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=pe(),n=me();e.default=[`$schema`,`$id`,`$defs`,`$vocabulary`,{keyword:`$comment`},`definitions`,t.default,n.default]})),ge=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=t.operators,r={maximum:{okStr:`<=`,ok:n.LTE,fail:n.GT},minimum:{okStr:`>=`,ok:n.GTE,fail:n.LT},exclusiveMaximum:{okStr:`<`,ok:n.LT,fail:n.GTE},exclusiveMinimum:{okStr:`>`,ok:n.GT,fail:n.LTE}};e.default={keyword:Object.keys(r),type:`number`,schemaType:`number`,$data:!0,error:{message:({keyword:e,schemaCode:n})=>(0,t.str)`must be ${r[e].okStr} ${n}`,params:({keyword:e,schemaCode:n})=>(0,t._)`{comparison: ${r[e].okStr}, limit: ${n}}`},code(e){let{keyword:n,data:i,schemaCode:a}=e;e.fail$data((0,t._)`${i} ${r[n].fail} ${a} || isNaN(${i})`)}}})),_e=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m();e.default={keyword:`multipleOf`,type:`number`,schemaType:`number`,$data:!0,error:{message:({schemaCode:e})=>(0,t.str)`must be multiple of ${e}`,params:({schemaCode:e})=>(0,t._)`{multipleOf: ${e}}`},code(e){let{gen:n,data:r,schemaCode:i,it:a}=e,o=a.opts.multipleOfPrecision,s=n.let(`res`),c=o?(0,t._)`Math.abs(Math.round(${s}) - ${s}) > 1e-${o}`:(0,t._)`${s} !== parseInt(${s})`;e.fail$data((0,t._)`(${i} === 0 || (${s} = ${r}/${i}, ${c}))`)}}})),ve=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});function t(e){let t=e.length,n=0,r=0,i;for(;r<t;)n++,i=e.charCodeAt(r++),i>=55296&&i<=56319&&r<t&&(i=e.charCodeAt(r),(i&64512)==56320&&r++);return n}e.default=t,t.code=`require("ajv/dist/runtime/ucs2length").default`})),ye=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h(),r=ve();e.default={keyword:[`maxLength`,`minLength`],type:`string`,schemaType:`number`,$data:!0,error:{message({keyword:e,schemaCode:n}){let r=e===`maxLength`?`more`:`fewer`;return(0,t.str)`must NOT have ${r} than ${n} characters`},params:({schemaCode:e})=>(0,t._)`{limit: ${e}}`},code(e){let{keyword:i,data:a,schemaCode:o,it:s}=e,c=i===`maxLength`?t.operators.GT:t.operators.LT,l=s.opts.unicode===!1?(0,t._)`${a}.length`:(0,t._)`${(0,n.useFunc)(e.gen,r.default)}(${a})`;e.fail$data((0,t._)`${l} ${c} ${o}`)}}})),be=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=C(),n=m();e.default={keyword:`pattern`,type:`string`,schemaType:`string`,$data:!0,error:{message:({schemaCode:e})=>(0,n.str)`must match pattern "${e}"`,params:({schemaCode:e})=>(0,n._)`{pattern: ${e}}`},code(e){let{data:r,$data:i,schema:a,schemaCode:o,it:s}=e,c=s.opts.unicodeRegExp?`u`:``,l=i?(0,n._)`(new RegExp(${o}, ${c}))`:(0,t.usePattern)(e,a);e.fail$data((0,n._)`!${l}.test(${r})`)}}})),xe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m();e.default={keyword:[`maxProperties`,`minProperties`],type:`object`,schemaType:`number`,$data:!0,error:{message({keyword:e,schemaCode:n}){let r=e===`maxProperties`?`more`:`fewer`;return(0,t.str)`must NOT have ${r} than ${n} properties`},params:({schemaCode:e})=>(0,t._)`{limit: ${e}}`},code(e){let{keyword:n,data:r,schemaCode:i}=e,a=n===`maxProperties`?t.operators.GT:t.operators.LT;e.fail$data((0,t._)`Object.keys(${r}).length ${a} ${i}`)}}})),Se=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=C(),n=m(),r=h();e.default={keyword:`required`,type:`object`,schemaType:`array`,$data:!0,error:{message:({params:{missingProperty:e}})=>(0,n.str)`must have required property '${e}'`,params:({params:{missingProperty:e}})=>(0,n._)`{missingProperty: ${e}}`},code(e){let{gen:i,schema:a,schemaCode:o,data:s,$data:c,it:l}=e,{opts:u}=l;if(!c&&a.length===0)return;let d=a.length>=u.loopRequired;if(l.allErrors?f():p(),u.strictRequired){let t=e.parentSchema.properties,{definedProperties:n}=e.it;for(let e of a)if(t?.[e]===void 0&&!n.has(e)){let t=`required property "${e}" is not defined at "${l.schemaEnv.baseId+l.errSchemaPath}" (strictRequired)`;(0,r.checkStrictMode)(l,t,l.opts.strictRequired)}}function f(){if(d||c)e.block$data(n.nil,m);else for(let n of a)(0,t.checkReportMissingProp)(e,n)}function p(){let n=i.let(`missing`);if(d||c){let t=i.let(`valid`,!0);e.block$data(t,()=>h(n,t)),e.ok(t)}else i.if((0,t.checkMissingProp)(e,a,n)),(0,t.reportMissingProp)(e,n),i.else()}function m(){i.forOf(`prop`,o,n=>{e.setParams({missingProperty:n}),i.if((0,t.noPropertyInData)(i,s,n,u.ownProperties),()=>e.error())})}function h(r,a){e.setParams({missingProperty:r}),i.forOf(r,o,()=>{i.assign(a,(0,t.propertyInData)(i,s,r,u.ownProperties)),i.if((0,n.not)(a),()=>{e.error(),i.break()})},n.nil)}}}})),Ce=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m();e.default={keyword:[`maxItems`,`minItems`],type:`array`,schemaType:`number`,$data:!0,error:{message({keyword:e,schemaCode:n}){let r=e===`maxItems`?`more`:`fewer`;return(0,t.str)`must NOT have ${r} than ${n} items`},params:({schemaCode:e})=>(0,t._)`{limit: ${e}}`},code(e){let{keyword:n,data:r,schemaCode:i}=e,a=n===`maxItems`?t.operators.GT:t.operators.LT;e.fail$data((0,t._)`${r}.length ${a} ${i}`)}}})),we=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=te();t.code=`require("ajv/dist/runtime/equal").default`,e.default=t})),Te=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=x(),n=m(),r=h(),i=we();e.default={keyword:`uniqueItems`,type:`array`,schemaType:`boolean`,$data:!0,error:{message:({params:{i:e,j:t}})=>(0,n.str)`must NOT have duplicate items (items ## ${t} and ${e} are identical)`,params:({params:{i:e,j:t}})=>(0,n._)`{i: ${e}, j: ${t}}`},code(e){let{gen:a,data:o,$data:s,schema:c,parentSchema:l,schemaCode:u,it:d}=e;if(!s&&!c)return;let f=a.let(`valid`),p=l.items?(0,t.getSchemaTypes)(l.items):[];e.block$data(f,m,(0,n._)`${u} === false`),e.ok(f);function m(){let t=a.let(`i`,(0,n._)`${o}.length`),r=a.let(`j`);e.setParams({i:t,j:r}),a.assign(f,!0),a.if((0,n._)`${t} > 1`,()=>(h()?g:_)(t,r))}function h(){return p.length>0&&!p.some(e=>e===`object`||e===`array`)}function g(r,i){let s=a.name(`item`),c=(0,t.checkDataTypes)(p,s,d.opts.strictNumbers,t.DataType.Wrong),l=a.const(`indices`,(0,n._)`{}`);a.for((0,n._)`;${r}--;`,()=>{a.let(s,(0,n._)`${o}[${r}]`),a.if(c,(0,n._)`continue`),p.length>1&&a.if((0,n._)`typeof ${s} == "string"`,(0,n._)`${s} += "_"`),a.if((0,n._)`typeof ${l}[${s}] == "number"`,()=>{a.assign(i,(0,n._)`${l}[${s}]`),e.error(),a.assign(f,!1).break()}).code((0,n._)`${l}[${s}] = ${r}`)})}function _(t,s){let c=(0,r.useFunc)(a,i.default),l=a.name(`outer`);a.label(l).for((0,n._)`;${t}--;`,()=>a.for((0,n._)`${s} = ${t}; ${s}--;`,()=>a.if((0,n._)`${c}(${o}[${t}], ${o}[${s}])`,()=>{e.error(),a.assign(f,!1).break(l)})))}}}})),Ee=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h(),r=we();e.default={keyword:`const`,$data:!0,error:{message:`must be equal to constant`,params:({schemaCode:e})=>(0,t._)`{allowedValue: ${e}}`},code(e){let{gen:i,data:a,$data:o,schemaCode:s,schema:c}=e;o||c&&typeof c==`object`?e.fail$data((0,t._)`!${(0,n.useFunc)(i,r.default)}(${a}, ${s})`):e.fail((0,t._)`${c} !== ${a}`)}}})),De=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h(),r=we();e.default={keyword:`enum`,schemaType:`array`,$data:!0,error:{message:`must be equal to one of the allowed values`,params:({schemaCode:e})=>(0,t._)`{allowedValues: ${e}}`},code(e){let{gen:i,data:a,$data:o,schema:s,schemaCode:c,it:l}=e;if(!o&&s.length===0)throw Error(`enum must have non-empty array`);let u=s.length>=l.opts.loopEnum,d,f=()=>d??=(0,n.useFunc)(i,r.default),p;if(u||o)p=i.let(`valid`),e.block$data(p,m);else{if(!Array.isArray(s))throw Error(`ajv implementation error`);let e=i.const(`vSchema`,c);p=(0,t.or)(...s.map((t,n)=>h(e,n)))}e.pass(p);function m(){i.assign(p,!1),i.forOf(`v`,c,e=>i.if((0,t._)`${f()}(${a}, ${e})`,()=>i.assign(p,!0).break()))}function h(e,n){let r=s[n];return typeof r==`object`&&r?(0,t._)`${f()}(${a}, ${e}[${n}])`:(0,t._)`${a} === ${r}`}}}})),Oe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=ge(),n=_e(),r=ye(),i=be(),a=xe(),o=Se(),s=Ce(),c=Te(),l=Ee(),u=De();e.default=[t.default,n.default,r.default,i.default,a.default,o.default,s.default,c.default,{keyword:`type`,schemaType:[`string`,`array`]},{keyword:`nullable`,schemaType:`boolean`},l.default,u.default]})),ke=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.validateAdditionalItems=void 0;let t=m(),n=h(),r={keyword:`additionalItems`,type:`array`,schemaType:[`boolean`,`object`],before:`uniqueItems`,error:{message:({params:{len:e}})=>(0,t.str)`must NOT have more than ${e} items`,params:({params:{len:e}})=>(0,t._)`{limit: ${e}}`},code(e){let{parentSchema:t,it:r}=e,{items:a}=t;if(!Array.isArray(a)){(0,n.checkStrictMode)(r,`"additionalItems" is ignored when "items" is not an array of schemas`);return}i(e,a)}};function i(e,r){let{gen:i,schema:a,data:o,keyword:s,it:c}=e;c.items=!0;let l=i.const(`len`,(0,t._)`${o}.length`);if(a===!1)e.setParams({len:r.length}),e.pass((0,t._)`${l} <= ${r.length}`);else if(typeof a==`object`&&!(0,n.alwaysValidSchema)(c,a)){let n=i.var(`valid`,(0,t._)`${l} <= ${r.length}`);i.if((0,t.not)(n),()=>u(n)),e.ok(n)}function u(a){i.forRange(`i`,r.length,l,r=>{e.subschema({keyword:s,dataProp:r,dataPropType:n.Type.Num},a),c.allErrors||i.if((0,t.not)(a),()=>i.break())})}}e.validateAdditionalItems=i,e.default=r})),Ae=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.validateTuple=void 0;let t=m(),n=h(),r=C(),i={keyword:`items`,type:`array`,schemaType:[`object`,`array`,`boolean`],before:`uniqueItems`,code(e){let{schema:t,it:i}=e;if(Array.isArray(t))return a(e,`additionalItems`,t);i.items=!0,!(0,n.alwaysValidSchema)(i,t)&&e.ok((0,r.validateArray)(e))}};function a(e,r,i=e.schema){let{gen:a,parentSchema:o,data:s,keyword:c,it:l}=e;f(o),l.opts.unevaluated&&i.length&&l.items!==!0&&(l.items=n.mergeEvaluated.items(a,i.length,l.items));let u=a.name(`valid`),d=a.const(`len`,(0,t._)`${s}.length`);i.forEach((r,i)=>{(0,n.alwaysValidSchema)(l,r)||(a.if((0,t._)`${d} > ${i}`,()=>e.subschema({keyword:c,schemaProp:i,dataProp:i},u)),e.ok(u))});function f(e){let{opts:t,errSchemaPath:a}=l,o=i.length,s=o===e.minItems&&(o===e.maxItems||e[r]===!1);if(t.strictTuples&&!s){let e=`"${c}" is ${o}-tuple, but minItems or maxItems/${r} are not specified or different at path "${a}"`;(0,n.checkStrictMode)(l,e,t.strictTuples)}}}e.validateTuple=a,e.default=i})),je=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=Ae();e.default={keyword:`prefixItems`,type:`array`,schemaType:[`array`],before:`uniqueItems`,code:e=>(0,t.validateTuple)(e,`items`)}})),Me=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h(),r=C(),i=ke();e.default={keyword:`items`,type:`array`,schemaType:[`object`,`boolean`],before:`uniqueItems`,error:{message:({params:{len:e}})=>(0,t.str)`must NOT have more than ${e} items`,params:({params:{len:e}})=>(0,t._)`{limit: ${e}}`},code(e){let{schema:t,parentSchema:a,it:o}=e,{prefixItems:s}=a;o.items=!0,!(0,n.alwaysValidSchema)(o,t)&&(s?(0,i.validateAdditionalItems)(e,s):e.ok((0,r.validateArray)(e)))}}})),Ne=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h();e.default={keyword:`contains`,type:`array`,schemaType:[`object`,`boolean`],before:`uniqueItems`,trackErrors:!0,error:{message:({params:{min:e,max:n}})=>n===void 0?(0,t.str)`must contain at least ${e} valid item(s)`:(0,t.str)`must contain at least ${e} and no more than ${n} valid item(s)`,params:({params:{min:e,max:n}})=>n===void 0?(0,t._)`{minContains: ${e}}`:(0,t._)`{minContains: ${e}, maxContains: ${n}}`},code(e){let{gen:r,schema:i,parentSchema:a,data:o,it:s}=e,c,l,{minContains:u,maxContains:d}=a;s.opts.next?(c=u===void 0?1:u,l=d):c=1;let f=r.const(`len`,(0,t._)`${o}.length`);if(e.setParams({min:c,max:l}),l===void 0&&c===0){(0,n.checkStrictMode)(s,`"minContains" == 0 without "maxContains": "contains" keyword ignored`);return}if(l!==void 0&&c>l){(0,n.checkStrictMode)(s,`"minContains" > "maxContains" is always invalid`),e.fail();return}if((0,n.alwaysValidSchema)(s,i)){let n=(0,t._)`${f} >= ${c}`;l!==void 0&&(n=(0,t._)`${n} && ${f} <= ${l}`),e.pass(n);return}s.items=!0;let p=r.name(`valid`);l===void 0&&c===1?h(p,()=>r.if(p,()=>r.break())):c===0?(r.let(p,!0),l!==void 0&&r.if((0,t._)`${o}.length > 0`,m)):(r.let(p,!1),m()),e.result(p,()=>e.reset());function m(){let e=r.name(`_valid`),t=r.let(`count`,0);h(e,()=>r.if(e,()=>g(t)))}function h(t,i){r.forRange(`i`,0,f,r=>{e.subschema({keyword:`contains`,dataProp:r,dataPropType:n.Type.Num,compositeRule:!0},t),i()})}function g(e){r.code((0,t._)`${e}++`),l===void 0?r.if((0,t._)`${e} >= ${c}`,()=>r.assign(p,!0).break()):(r.if((0,t._)`${e} > ${l}`,()=>r.assign(p,!1).break()),c===1?r.assign(p,!0):r.if((0,t._)`${e} >= ${c}`,()=>r.assign(p,!0)))}}}})),Pe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.validateSchemaDeps=e.validatePropertyDeps=e.error=void 0;let t=m(),n=h(),r=C();e.error={message:({params:{property:e,depsCount:n,deps:r}})=>{let i=n===1?`property`:`properties`;return(0,t.str)`must have ${i} ${r} when property ${e} is present`},params:({params:{property:e,depsCount:n,deps:r,missingProperty:i}})=>(0,t._)`{property: ${e},
    missingProperty: ${i},
    depsCount: ${n},
    deps: ${r}}`};let i={keyword:`dependencies`,type:`object`,schemaType:`object`,error:e.error,code(e){let[t,n]=a(e);o(e,t),s(e,n)}};function a({schema:e}){let t={},n={};for(let r in e){if(r===`__proto__`)continue;let i=Array.isArray(e[r])?t:n;i[r]=e[r]}return[t,n]}function o(e,n=e.schema){let{gen:i,data:a,it:o}=e;if(Object.keys(n).length===0)return;let s=i.let(`missing`);for(let c in n){let l=n[c];if(l.length===0)continue;let u=(0,r.propertyInData)(i,a,c,o.opts.ownProperties);e.setParams({property:c,depsCount:l.length,deps:l.join(`, `)}),o.allErrors?i.if(u,()=>{for(let t of l)(0,r.checkReportMissingProp)(e,t)}):(i.if((0,t._)`${u} && (${(0,r.checkMissingProp)(e,l,s)})`),(0,r.reportMissingProp)(e,s),i.else())}}e.validatePropertyDeps=o;function s(e,t=e.schema){let{gen:i,data:a,keyword:o,it:s}=e,c=i.name(`valid`);for(let l in t)(0,n.alwaysValidSchema)(s,t[l])||(i.if((0,r.propertyInData)(i,a,l,s.opts.ownProperties),()=>{let t=e.subschema({keyword:o,schemaProp:l},c);e.mergeValidEvaluated(t,c)},()=>i.var(c,!0)),e.ok(c))}e.validateSchemaDeps=s,e.default=i})),Fe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h();e.default={keyword:`propertyNames`,type:`object`,schemaType:[`object`,`boolean`],error:{message:`property name must be valid`,params:({params:e})=>(0,t._)`{propertyName: ${e.propertyName}}`},code(e){let{gen:r,schema:i,data:a,it:o}=e;if((0,n.alwaysValidSchema)(o,i))return;let s=r.name(`valid`);r.forIn(`key`,a,n=>{e.setParams({propertyName:n}),e.subschema({keyword:`propertyNames`,data:n,dataTypes:[`string`],propertyName:n,compositeRule:!0},s),r.if((0,t.not)(s),()=>{e.error(!0),o.allErrors||r.break()})}),e.ok(s)}}})),Ie=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=C(),n=m(),r=g(),i=h();e.default={keyword:`additionalProperties`,type:[`object`],schemaType:[`boolean`,`object`],allowUndefined:!0,trackErrors:!0,error:{message:`must NOT have additional properties`,params:({params:e})=>(0,n._)`{additionalProperty: ${e.additionalProperty}}`},code(e){let{gen:a,schema:o,parentSchema:s,data:c,errsCount:l,it:u}=e;if(!l)throw Error(`ajv implementation error`);let{allErrors:d,opts:f}=u;if(u.props=!0,f.removeAdditional!==`all`&&(0,i.alwaysValidSchema)(u,o))return;let p=(0,t.allSchemaProperties)(s.properties),m=(0,t.allSchemaProperties)(s.patternProperties);h(),e.ok((0,n._)`${l} === ${r.default.errors}`);function h(){a.forIn(`key`,c,e=>{!p.length&&!m.length?v(e):a.if(g(e),()=>v(e))})}function g(r){let o;if(p.length>8){let e=(0,i.schemaRefOrVal)(u,s.properties,`properties`);o=(0,t.isOwnProperty)(a,e,r)}else o=p.length?(0,n.or)(...p.map(e=>(0,n._)`${r} === ${e}`)):n.nil;return m.length&&(o=(0,n.or)(o,...m.map(i=>(0,n._)`${(0,t.usePattern)(e,i)}.test(${r})`))),(0,n.not)(o)}function _(e){a.code((0,n._)`delete ${c}[${e}]`)}function v(t){if(f.removeAdditional===`all`||f.removeAdditional&&o===!1){_(t);return}if(o===!1){e.setParams({additionalProperty:t}),e.error(),d||a.break();return}if(typeof o==`object`&&!(0,i.alwaysValidSchema)(u,o)){let r=a.name(`valid`);f.removeAdditional===`failing`?(y(t,r,!1),a.if((0,n.not)(r),()=>{e.reset(),_(t)})):(y(t,r),d||a.if((0,n.not)(r),()=>a.break()))}}function y(t,n,r){let a={keyword:`additionalProperties`,dataProp:t,dataPropType:i.Type.Str};r===!1&&Object.assign(a,{compositeRule:!0,createErrors:!1,allErrors:!1}),e.subschema(a,n)}}}})),Le=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=E(),n=C(),r=h(),i=Ie();e.default={keyword:`properties`,type:`object`,schemaType:`object`,code(e){let{gen:a,schema:o,parentSchema:s,data:c,it:l}=e;l.opts.removeAdditional===`all`&&s.additionalProperties===void 0&&i.default.code(new t.KeywordCxt(l,i.default,`additionalProperties`));let u=(0,n.allSchemaProperties)(o);for(let e of u)l.definedProperties.add(e);l.opts.unevaluated&&u.length&&l.props!==!0&&(l.props=r.mergeEvaluated.props(a,(0,r.toHash)(u),l.props));let d=u.filter(e=>!(0,r.alwaysValidSchema)(l,o[e]));if(d.length===0)return;let f=a.name(`valid`);for(let t of d)p(t)?m(t):(a.if((0,n.propertyInData)(a,c,t,l.opts.ownProperties)),m(t),l.allErrors||a.else().var(f,!0),a.endIf()),e.it.definedProperties.add(t),e.ok(f);function p(e){return l.opts.useDefaults&&!l.compositeRule&&o[e].default!==void 0}function m(t){e.subschema({keyword:`properties`,schemaProp:t,dataProp:t},f)}}}})),Re=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=C(),n=m(),r=h(),i=h();e.default={keyword:`patternProperties`,type:`object`,schemaType:`object`,code(e){let{gen:a,schema:o,data:s,parentSchema:c,it:l}=e,{opts:u}=l,d=(0,t.allSchemaProperties)(o),f=d.filter(e=>(0,r.alwaysValidSchema)(l,o[e]));if(d.length===0||f.length===d.length&&(!l.opts.unevaluated||l.props===!0))return;let p=u.strictSchema&&!u.allowMatchingProperties&&c.properties,m=a.name(`valid`);l.props!==!0&&!(l.props instanceof n.Name)&&(l.props=(0,i.evaluatedPropsToName)(a,l.props));let{props:h}=l;g();function g(){for(let e of d)p&&_(e),l.allErrors?v(e):(a.var(m,!0),v(e),a.if(m))}function _(e){for(let t in p)new RegExp(e).test(t)&&(0,r.checkStrictMode)(l,`property ${t} matches pattern ${e} (use allowMatchingProperties)`)}function v(r){a.forIn(`key`,s,o=>{a.if((0,n._)`${(0,t.usePattern)(e,r)}.test(${o})`,()=>{let t=f.includes(r);t||e.subschema({keyword:`patternProperties`,schemaProp:r,dataProp:o,dataPropType:i.Type.Str},m),l.opts.unevaluated&&h!==!0?a.assign((0,n._)`${h}[${o}]`,!0):!t&&!l.allErrors&&a.if((0,n.not)(m),()=>a.break())})})}}}})),ze=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=h();e.default={keyword:`not`,schemaType:[`object`,`boolean`],trackErrors:!0,code(e){let{gen:n,schema:r,it:i}=e;if((0,t.alwaysValidSchema)(i,r)){e.fail();return}let a=n.name(`valid`);e.subschema({keyword:`not`,compositeRule:!0,createErrors:!1,allErrors:!1},a),e.failResult(a,()=>e.reset(),()=>e.error())},error:{message:`must NOT be valid`}}})),Be=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.default={keyword:`anyOf`,schemaType:`array`,trackErrors:!0,code:C().validateUnion,error:{message:`must match a schema in anyOf`}}})),Ve=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h();e.default={keyword:`oneOf`,schemaType:`array`,trackErrors:!0,error:{message:`must match exactly one schema in oneOf`,params:({params:e})=>(0,t._)`{passingSchemas: ${e.passing}}`},code(e){let{gen:r,schema:i,parentSchema:a,it:o}=e;if(!Array.isArray(i))throw Error(`ajv implementation error`);if(o.opts.discriminator&&a.discriminator)return;let s=i,c=r.let(`valid`,!1),l=r.let(`passing`,null),u=r.name(`_valid`);e.setParams({passing:l}),r.block(d),e.result(c,()=>e.reset(),()=>e.error(!0));function d(){s.forEach((i,a)=>{let s;(0,n.alwaysValidSchema)(o,i)?r.var(u,!0):s=e.subschema({keyword:`oneOf`,schemaProp:a,compositeRule:!0},u),a>0&&r.if((0,t._)`${u} && ${c}`).assign(c,!1).assign(l,(0,t._)`[${l}, ${a}]`).else(),r.if(u,()=>{r.assign(c,!0),r.assign(l,a),s&&e.mergeEvaluated(s,t.Name)})})}}}})),He=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=h();e.default={keyword:`allOf`,schemaType:`array`,code(e){let{gen:n,schema:r,it:i}=e;if(!Array.isArray(r))throw Error(`ajv implementation error`);let a=n.name(`valid`);r.forEach((n,r)=>{if((0,t.alwaysValidSchema)(i,n))return;let o=e.subschema({keyword:`allOf`,schemaProp:r},a);e.ok(a),e.mergeEvaluated(o)})}}})),Ue=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h(),r={keyword:`if`,schemaType:[`object`,`boolean`],trackErrors:!0,error:{message:({params:e})=>(0,t.str)`must match "${e.ifClause}" schema`,params:({params:e})=>(0,t._)`{failingKeyword: ${e.ifClause}}`},code(e){let{gen:r,parentSchema:a,it:o}=e;a.then===void 0&&a.else===void 0&&(0,n.checkStrictMode)(o,`"if" without "then" and "else" is ignored`);let s=i(o,`then`),c=i(o,`else`);if(!s&&!c)return;let l=r.let(`valid`,!0),u=r.name(`_valid`);if(d(),e.reset(),s&&c){let t=r.let(`ifClause`);e.setParams({ifClause:t}),r.if(u,f(`then`,t),f(`else`,t))}else s?r.if(u,f(`then`)):r.if((0,t.not)(u),f(`else`));e.pass(l,()=>e.error(!0));function d(){let t=e.subschema({keyword:`if`,compositeRule:!0,createErrors:!1,allErrors:!1},u);e.mergeEvaluated(t)}function f(n,i){return()=>{let a=e.subschema({keyword:n},u);r.assign(l,u),e.mergeValidEvaluated(a,l),i?r.assign(i,(0,t._)`${n}`):e.setParams({ifClause:n})}}}};function i(e,t){let r=e.schema[t];return r!==void 0&&!(0,n.alwaysValidSchema)(e,r)}e.default=r})),We=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=h();e.default={keyword:[`then`,`else`],schemaType:[`object`,`boolean`],code({keyword:e,parentSchema:n,it:r}){n.if===void 0&&(0,t.checkStrictMode)(r,`"${e}" without "if" is ignored`)}}})),Ge=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=ke(),n=je(),r=Ae(),i=Me(),a=Ne(),o=Pe(),s=Fe(),c=Ie(),l=Le(),u=Re(),d=ze(),f=Be(),p=Ve(),m=He(),h=Ue(),g=We();function _(e=!1){let _=[d.default,f.default,p.default,m.default,h.default,g.default,s.default,c.default,o.default,l.default,u.default];return e?_.push(n.default,i.default):_.push(t.default,r.default),_.push(a.default),_}e.default=_})),Ke=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.dynamicAnchor=void 0;let t=m(),n=g(),r=k(),i=me(),a={keyword:`$dynamicAnchor`,schemaType:`string`,code:e=>o(e,e.schema)};function o(e,r){let{gen:i,it:a}=e;a.schemaEnv.root.dynamicAnchors[r]=!0;let o=(0,t._)`${n.default.dynamicAnchors}${(0,t.getProperty)(r)}`,c=a.errSchemaPath===`#`?a.validateName:s(e);i.if((0,t._)`!${o}`,()=>i.assign(o,c))}e.dynamicAnchor=o;function s(e){let{schemaEnv:t,schema:n,self:a}=e.it,{root:o,baseId:s,localRefs:c,meta:l}=t.root,{schemaId:u}=a.opts,d=new r.SchemaEnv({schema:n,schemaId:u,root:o,baseId:s,localRefs:c,meta:l});return r.compileSchema.call(a,d),(0,i.getValidate)(e,d)}e.default=a})),qe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.dynamicRef=void 0;let t=m(),n=g(),r=me(),i={keyword:`$dynamicRef`,schemaType:`string`,code:e=>a(e,e.schema)};function a(e,i){let{gen:a,keyword:o,it:s}=e;if(i[0]!==`#`)throw Error(`"${o}" only supports hash fragment reference`);let c=i.slice(1);if(s.allErrors)l();else{let t=a.let(`valid`,!1);l(t),e.ok(t)}function l(e){if(s.schemaEnv.root.dynamicAnchors[c]){let r=a.let(`_v`,(0,t._)`${n.default.dynamicAnchors}${(0,t.getProperty)(c)}`);a.if(r,u(r,e),u(s.validateName,e))}else u(s.validateName,e)()}function u(t,n){return n?()=>a.block(()=>{(0,r.callRef)(e,t),a.let(n,!0)}):()=>(0,r.callRef)(e,t)}}e.dynamicRef=a,e.default=i})),Je=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=Ke(),n=h();e.default={keyword:`$recursiveAnchor`,schemaType:`boolean`,code(e){e.schema?(0,t.dynamicAnchor)(e,``):(0,n.checkStrictMode)(e.it,`$recursiveAnchor: false is ignored`)}}})),Ye=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=qe();e.default={keyword:`$recursiveRef`,schemaType:`string`,code:e=>(0,t.dynamicRef)(e,e.schema)}})),Xe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=Ke(),n=qe(),r=Je(),i=Ye();e.default=[t.default,n.default,r.default,i.default]})),Ze=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=Pe();e.default={keyword:`dependentRequired`,type:`object`,schemaType:`object`,error:t.error,code:e=>(0,t.validatePropertyDeps)(e)}})),Qe=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=Pe();e.default={keyword:`dependentSchemas`,type:`object`,schemaType:`object`,code:e=>(0,t.validateSchemaDeps)(e)}})),$e=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=h();e.default={keyword:[`maxContains`,`minContains`],type:`array`,schemaType:`number`,code({keyword:e,parentSchema:n,it:r}){n.contains===void 0&&(0,t.checkStrictMode)(r,`"${e}" without "contains" is ignored`)}}})),et=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=Ze(),n=Qe(),r=$e();e.default=[t.default,n.default,r.default]})),tt=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h(),r=g();e.default={keyword:`unevaluatedProperties`,type:`object`,schemaType:[`boolean`,`object`],trackErrors:!0,error:{message:`must NOT have unevaluated properties`,params:({params:e})=>(0,t._)`{unevaluatedProperty: ${e.unevaluatedProperty}}`},code(e){let{gen:i,schema:a,data:o,errsCount:s,it:c}=e;if(!s)throw Error(`ajv implementation error`);let{allErrors:l,props:u}=c;u instanceof t.Name?i.if((0,t._)`${u} !== true`,()=>i.forIn(`key`,o,e=>i.if(f(u,e),()=>d(e)))):u!==!0&&i.forIn(`key`,o,e=>u===void 0?d(e):i.if(p(u,e),()=>d(e))),c.props=!0,e.ok((0,t._)`${s} === ${r.default.errors}`);function d(r){if(a===!1){e.setParams({unevaluatedProperty:r}),e.error(),l||i.break();return}if(!(0,n.alwaysValidSchema)(c,a)){let a=i.name(`valid`);e.subschema({keyword:`unevaluatedProperties`,dataProp:r,dataPropType:n.Type.Str},a),l||i.if((0,t.not)(a),()=>i.break())}}function f(e,n){return(0,t._)`!${e} || !${e}[${n}]`}function p(e,n){let r=[];for(let i in e)e[i]===!0&&r.push((0,t._)`${n} !== ${i}`);return(0,t.and)(...r)}}}})),nt=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=h();e.default={keyword:`unevaluatedItems`,type:`array`,schemaType:[`boolean`,`object`],error:{message:({params:{len:e}})=>(0,t.str)`must NOT have more than ${e} items`,params:({params:{len:e}})=>(0,t._)`{limit: ${e}}`},code(e){let{gen:r,schema:i,data:a,it:o}=e,s=o.items||0;if(s===!0)return;let c=r.const(`len`,(0,t._)`${a}.length`);if(i===!1)e.setParams({len:s}),e.fail((0,t._)`${c} > ${s}`);else if(typeof i==`object`&&!(0,n.alwaysValidSchema)(o,i)){let n=r.var(`valid`,(0,t._)`${c} <= ${s}`);r.if((0,t.not)(n),()=>l(n,s)),e.ok(n)}o.items=!0;function l(i,a){r.forRange(`i`,a,c,a=>{e.subschema({keyword:`unevaluatedItems`,dataProp:a,dataPropType:n.Type.Num},i),o.allErrors||r.if((0,t.not)(i),()=>r.break())})}}}})),rt=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=tt(),n=nt();e.default=[t.default,n.default]})),it=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m();e.default={keyword:`format`,type:[`number`,`string`],schemaType:`string`,$data:!0,error:{message:({schemaCode:e})=>(0,t.str)`must match format "${e}"`,params:({schemaCode:e})=>(0,t._)`{format: ${e}}`},code(e,n){let{gen:r,data:i,$data:a,schema:o,schemaCode:s,it:c}=e,{opts:l,errSchemaPath:u,schemaEnv:d,self:f}=c;if(!l.validateFormats)return;a?p():m();function p(){let a=r.scopeValue(`formats`,{ref:f.formats,code:l.code.formats}),o=r.const(`fDef`,(0,t._)`${a}[${s}]`),c=r.let(`fType`),u=r.let(`format`);r.if((0,t._)`typeof ${o} == "object" && !(${o} instanceof RegExp)`,()=>r.assign(c,(0,t._)`${o}.type || "string"`).assign(u,(0,t._)`${o}.validate`),()=>r.assign(c,(0,t._)`"string"`).assign(u,o)),e.fail$data((0,t.or)(p(),m()));function p(){return l.strictSchema===!1?t.nil:(0,t._)`${s} && !${u}`}function m(){let e=d.$async?(0,t._)`(${o}.async ? await ${u}(${i}) : ${u}(${i}))`:(0,t._)`${u}(${i})`,r=(0,t._)`(typeof ${u} == "function" ? ${e} : ${u}.test(${i}))`;return(0,t._)`${u} && ${u} !== true && ${c} === ${n} && !${r}`}}function m(){let a=f.formats[o];if(!a){m();return}if(a===!0)return;let[s,c,p]=h(a);s===n&&e.pass(g());function m(){if(l.strictSchema===!1){f.logger.warn(e());return}throw Error(e());function e(){return`unknown format "${o}" ignored in schema at path "${u}"`}}function h(e){let n=e instanceof RegExp?(0,t.regexpCode)(e):l.code.formats?(0,t._)`${l.code.formats}${(0,t.getProperty)(o)}`:void 0,i=r.scopeValue(`formats`,{key:o,ref:e,code:n});return typeof e==`object`&&!(e instanceof RegExp)?[e.type||`string`,e.validate,(0,t._)`${i}.validate`]:[`string`,e,i]}function g(){if(typeof a==`object`&&!(a instanceof RegExp)&&a.async){if(!d.$async)throw Error(`async format in sync schema`);return(0,t._)`await ${p}(${i})`}return typeof c==`function`?(0,t._)`${p}(${i})`:(0,t._)`${p}.test(${i})`}}}}})),at=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.default=[it().default]})),ot=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.contentVocabulary=e.metadataVocabulary=void 0,e.metadataVocabulary=[`title`,`description`,`default`,`deprecated`,`readOnly`,`writeOnly`,`examples`],e.contentVocabulary=[`contentMediaType`,`contentEncoding`,`contentSchema`]})),st=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=he(),n=Oe(),r=Ge(),i=Xe(),a=et(),o=rt(),s=at(),c=ot();e.default=[i.default,t.default,n.default,(0,r.default)(!0),s.default,c.metadataVocabulary,c.contentVocabulary,a.default,o.default]})),ct=s((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.DiscrError=void 0;var t;(function(e){e.Tag=`tag`,e.Mapping=`mapping`})(t||(e.DiscrError=t={}))})),lt=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=m(),n=ct(),r=k(),i=O(),a=h();e.default={keyword:`discriminator`,type:`object`,schemaType:`object`,error:{message:({params:{discrError:e,tagName:t}})=>e===n.DiscrError.Tag?`tag "${t}" must be string`:`value of tag "${t}" must be in oneOf`,params:({params:{discrError:e,tag:n,tagName:r}})=>(0,t._)`{error: ${e}, tag: ${r}, tagValue: ${n}}`},code(e){let{gen:o,data:s,schema:c,parentSchema:l,it:u}=e,{oneOf:d}=l;if(!u.opts.discriminator)throw Error(`discriminator: requires discriminator option`);let f=c.propertyName;if(typeof f!=`string`)throw Error(`discriminator: requires propertyName`);if(c.mapping)throw Error(`discriminator: mapping is not supported`);if(!d)throw Error(`discriminator: requires oneOf keyword`);let p=o.let(`valid`,!1),m=o.const(`tag`,(0,t._)`${s}${(0,t.getProperty)(f)}`);o.if((0,t._)`typeof ${m} == "string"`,()=>h(),()=>e.error(!1,{discrError:n.DiscrError.Tag,tag:m,tagName:f})),e.ok(p);function h(){let r=_();o.if(!1);for(let e in r)o.elseIf((0,t._)`${m} === ${e}`),o.assign(p,g(r[e]));o.else(),e.error(!1,{discrError:n.DiscrError.Mapping,tag:m,tagName:f}),o.endIf()}function g(n){let r=o.name(`valid`),i=e.subschema({keyword:`oneOf`,schemaProp:n},r);return e.mergeEvaluated(i,t.Name),r}function _(){let e={},t=o(l),n=!0;for(let e=0;e<d.length;e++){let c=d[e];if(c?.$ref&&!(0,a.schemaHasRulesButRef)(c,u.self.RULES)){let e=c.$ref;if(c=r.resolveRef.call(u.self,u.schemaEnv.root,u.baseId,e),c instanceof r.SchemaEnv&&(c=c.schema),c===void 0)throw new i.default(u.opts.uriResolver,u.baseId,e)}let l=c?.properties?.[f];if(typeof l!=`object`)throw Error(`discriminator: oneOf subschemas (or referenced schemas) must have "properties/${f}"`);n&&=t||o(c),s(l,e)}if(!n)throw Error(`discriminator: "${f}" must be required`);return e;function o({required:e}){return Array.isArray(e)&&e.includes(f)}function s(e,t){if(e.const)c(e.const,t);else if(e.enum)for(let n of e.enum)c(n,t);else throw Error(`discriminator: "properties/${f}" must have "const" or "enum"`)}function c(t,n){if(typeof t!=`string`||t in e)throw Error(`discriminator: "${f}" values must be unique strings`);e[t]=n}}}}})),ut=c({$comment:()=>vt,$dynamicAnchor:()=>mt,$id:()=>ft,$schema:()=>dt,$vocabulary:()=>pt,allOf:()=>gt,default:()=>bt,properties:()=>yt,title:()=>ht,type:()=>_t}),dt,ft,pt,mt,ht,gt,_t,vt,yt,bt,xt=o((()=>{dt=`https://json-schema.org/draft/2020-12/schema`,ft=`https://json-schema.org/draft/2020-12/schema`,pt={"https://json-schema.org/draft/2020-12/vocab/core":!0,"https://json-schema.org/draft/2020-12/vocab/applicator":!0,"https://json-schema.org/draft/2020-12/vocab/unevaluated":!0,"https://json-schema.org/draft/2020-12/vocab/validation":!0,"https://json-schema.org/draft/2020-12/vocab/meta-data":!0,"https://json-schema.org/draft/2020-12/vocab/format-annotation":!0,"https://json-schema.org/draft/2020-12/vocab/content":!0},mt=`meta`,ht=`Core and Validation specifications meta-schema`,gt=[{$ref:`meta/core`},{$ref:`meta/applicator`},{$ref:`meta/unevaluated`},{$ref:`meta/validation`},{$ref:`meta/meta-data`},{$ref:`meta/format-annotation`},{$ref:`meta/content`}],_t=[`object`,`boolean`],vt=`This meta-schema also defines keywords that have appeared in previous drafts in order to prevent incompatible extensions as they remain in common use.`,yt={definitions:{$comment:`"definitions" has been replaced by "$defs".`,type:`object`,additionalProperties:{$dynamicRef:`#meta`},deprecated:!0,default:{}},dependencies:{$comment:`"dependencies" has been split and replaced by "dependentSchemas" and "dependentRequired" in order to serve their differing semantics.`,type:`object`,additionalProperties:{anyOf:[{$dynamicRef:`#meta`},{$ref:`meta/validation#/$defs/stringArray`}]},deprecated:!0,default:{}},$recursiveAnchor:{$comment:`"$recursiveAnchor" has been replaced by "$dynamicAnchor".`,$ref:`meta/core#/$defs/anchorString`,deprecated:!0},$recursiveRef:{$comment:`"$recursiveRef" has been replaced by "$dynamicRef".`,$ref:`meta/core#/$defs/uriReferenceString`,deprecated:!0}},bt={$schema:dt,$id:ft,$vocabulary:pt,$dynamicAnchor:mt,title:ht,allOf:gt,type:_t,$comment:vt,properties:yt}})),St=c({$defs:()=>At,$dynamicAnchor:()=>Et,$id:()=>wt,$schema:()=>Ct,$vocabulary:()=>Tt,default:()=>jt,properties:()=>kt,title:()=>Dt,type:()=>Ot}),Ct,wt,Tt,Et,Dt,Ot,kt,At,jt,Mt=o((()=>{Ct=`https://json-schema.org/draft/2020-12/schema`,wt=`https://json-schema.org/draft/2020-12/meta/applicator`,Tt={"https://json-schema.org/draft/2020-12/vocab/applicator":!0},Et=`meta`,Dt=`Applicator vocabulary meta-schema`,Ot=[`object`,`boolean`],kt={prefixItems:{$ref:`#/$defs/schemaArray`},items:{$dynamicRef:`#meta`},contains:{$dynamicRef:`#meta`},additionalProperties:{$dynamicRef:`#meta`},properties:{type:`object`,additionalProperties:{$dynamicRef:`#meta`},default:{}},patternProperties:{type:`object`,additionalProperties:{$dynamicRef:`#meta`},propertyNames:{format:`regex`},default:{}},dependentSchemas:{type:`object`,additionalProperties:{$dynamicRef:`#meta`},default:{}},propertyNames:{$dynamicRef:`#meta`},if:{$dynamicRef:`#meta`},then:{$dynamicRef:`#meta`},else:{$dynamicRef:`#meta`},allOf:{$ref:`#/$defs/schemaArray`},anyOf:{$ref:`#/$defs/schemaArray`},oneOf:{$ref:`#/$defs/schemaArray`},not:{$dynamicRef:`#meta`}},At={schemaArray:{type:`array`,minItems:1,items:{$dynamicRef:`#meta`}}},jt={$schema:Ct,$id:wt,$vocabulary:Tt,$dynamicAnchor:Et,title:Dt,type:Ot,properties:kt,$defs:At}})),Nt=c({$dynamicAnchor:()=>Lt,$id:()=>Ft,$schema:()=>Pt,$vocabulary:()=>It,default:()=>Vt,properties:()=>Bt,title:()=>Rt,type:()=>zt}),Pt,Ft,It,Lt,Rt,zt,Bt,Vt,Ht=o((()=>{Pt=`https://json-schema.org/draft/2020-12/schema`,Ft=`https://json-schema.org/draft/2020-12/meta/unevaluated`,It={"https://json-schema.org/draft/2020-12/vocab/unevaluated":!0},Lt=`meta`,Rt=`Unevaluated applicator vocabulary meta-schema`,zt=[`object`,`boolean`],Bt={unevaluatedItems:{$dynamicRef:`#meta`},unevaluatedProperties:{$dynamicRef:`#meta`}},Vt={$schema:Pt,$id:Ft,$vocabulary:It,$dynamicAnchor:Lt,title:Rt,type:zt,properties:Bt}})),Ut=c({$dynamicAnchor:()=>qt,$id:()=>Gt,$schema:()=>Wt,$vocabulary:()=>Kt,default:()=>Zt,properties:()=>Xt,title:()=>Jt,type:()=>Yt}),Wt,Gt,Kt,qt,Jt,Yt,Xt,Zt,Qt=o((()=>{Wt=`https://json-schema.org/draft/2020-12/schema`,Gt=`https://json-schema.org/draft/2020-12/meta/content`,Kt={"https://json-schema.org/draft/2020-12/vocab/content":!0},qt=`meta`,Jt=`Content vocabulary meta-schema`,Yt=[`object`,`boolean`],Xt={contentEncoding:{type:`string`},contentMediaType:{type:`string`},contentSchema:{$dynamicRef:`#meta`}},Zt={$schema:Wt,$id:Gt,$vocabulary:Kt,$dynamicAnchor:qt,title:Jt,type:Yt,properties:Xt}})),$t=c({$defs:()=>cn,$dynamicAnchor:()=>rn,$id:()=>tn,$schema:()=>en,$vocabulary:()=>nn,default:()=>ln,properties:()=>sn,title:()=>an,type:()=>on}),en,tn,nn,rn,an,on,sn,cn,ln,un=o((()=>{en=`https://json-schema.org/draft/2020-12/schema`,tn=`https://json-schema.org/draft/2020-12/meta/core`,nn={"https://json-schema.org/draft/2020-12/vocab/core":!0},rn=`meta`,an=`Core vocabulary meta-schema`,on=[`object`,`boolean`],sn={$id:{$ref:`#/$defs/uriReferenceString`,$comment:`Non-empty fragments not allowed.`,pattern:`^[^#]*#?$`},$schema:{$ref:`#/$defs/uriString`},$ref:{$ref:`#/$defs/uriReferenceString`},$anchor:{$ref:`#/$defs/anchorString`},$dynamicRef:{$ref:`#/$defs/uriReferenceString`},$dynamicAnchor:{$ref:`#/$defs/anchorString`},$vocabulary:{type:`object`,propertyNames:{$ref:`#/$defs/uriString`},additionalProperties:{type:`boolean`}},$comment:{type:`string`},$defs:{type:`object`,additionalProperties:{$dynamicRef:`#meta`}}},cn={anchorString:{type:`string`,pattern:`^[A-Za-z_][-A-Za-z0-9._]*$`},uriString:{type:`string`,format:`uri`},uriReferenceString:{type:`string`,format:`uri-reference`}},ln={$schema:en,$id:tn,$vocabulary:nn,$dynamicAnchor:rn,title:an,type:on,properties:sn,$defs:cn}})),dn=c({$dynamicAnchor:()=>hn,$id:()=>pn,$schema:()=>fn,$vocabulary:()=>mn,default:()=>yn,properties:()=>vn,title:()=>gn,type:()=>_n}),fn,pn,mn,hn,gn,_n,vn,yn,bn=o((()=>{fn=`https://json-schema.org/draft/2020-12/schema`,pn=`https://json-schema.org/draft/2020-12/meta/format-annotation`,mn={"https://json-schema.org/draft/2020-12/vocab/format-annotation":!0},hn=`meta`,gn=`Format vocabulary meta-schema for annotation results`,_n=[`object`,`boolean`],vn={format:{type:`string`}},yn={$schema:fn,$id:pn,$vocabulary:mn,$dynamicAnchor:hn,title:gn,type:_n,properties:vn}})),xn=c({$dynamicAnchor:()=>Tn,$id:()=>Cn,$schema:()=>Sn,$vocabulary:()=>wn,default:()=>kn,properties:()=>On,title:()=>En,type:()=>Dn}),Sn,Cn,wn,Tn,En,Dn,On,kn,An=o((()=>{Sn=`https://json-schema.org/draft/2020-12/schema`,Cn=`https://json-schema.org/draft/2020-12/meta/meta-data`,wn={"https://json-schema.org/draft/2020-12/vocab/meta-data":!0},Tn=`meta`,En=`Meta-data vocabulary meta-schema`,Dn=[`object`,`boolean`],On={title:{type:`string`},description:{type:`string`},default:!0,deprecated:{type:`boolean`,default:!1},readOnly:{type:`boolean`,default:!1},writeOnly:{type:`boolean`,default:!1},examples:{type:`array`,items:!0}},kn={$schema:Sn,$id:Cn,$vocabulary:wn,$dynamicAnchor:Tn,title:En,type:Dn,properties:On}})),jn=c({$defs:()=>zn,$dynamicAnchor:()=>Fn,$id:()=>Nn,$schema:()=>Mn,$vocabulary:()=>Pn,default:()=>Bn,properties:()=>Rn,title:()=>In,type:()=>Ln}),Mn,Nn,Pn,Fn,In,Ln,Rn,zn,Bn,Vn=o((()=>{Mn=`https://json-schema.org/draft/2020-12/schema`,Nn=`https://json-schema.org/draft/2020-12/meta/validation`,Pn={"https://json-schema.org/draft/2020-12/vocab/validation":!0},Fn=`meta`,In=`Validation vocabulary meta-schema`,Ln=[`object`,`boolean`],Rn={type:{anyOf:[{$ref:`#/$defs/simpleTypes`},{type:`array`,items:{$ref:`#/$defs/simpleTypes`},minItems:1,uniqueItems:!0}]},const:!0,enum:{type:`array`,items:!0},multipleOf:{type:`number`,exclusiveMinimum:0},maximum:{type:`number`},exclusiveMaximum:{type:`number`},minimum:{type:`number`},exclusiveMinimum:{type:`number`},maxLength:{$ref:`#/$defs/nonNegativeInteger`},minLength:{$ref:`#/$defs/nonNegativeIntegerDefault0`},pattern:{type:`string`,format:`regex`},maxItems:{$ref:`#/$defs/nonNegativeInteger`},minItems:{$ref:`#/$defs/nonNegativeIntegerDefault0`},uniqueItems:{type:`boolean`,default:!1},maxContains:{$ref:`#/$defs/nonNegativeInteger`},minContains:{$ref:`#/$defs/nonNegativeInteger`,default:1},maxProperties:{$ref:`#/$defs/nonNegativeInteger`},minProperties:{$ref:`#/$defs/nonNegativeIntegerDefault0`},required:{$ref:`#/$defs/stringArray`},dependentRequired:{type:`object`,additionalProperties:{$ref:`#/$defs/stringArray`}}},zn={nonNegativeInteger:{type:`integer`,minimum:0},nonNegativeIntegerDefault0:{$ref:`#/$defs/nonNegativeInteger`,default:0},simpleTypes:{enum:[`array`,`boolean`,`integer`,`null`,`number`,`object`,`string`]},stringArray:{type:`array`,items:{type:`string`},uniqueItems:!0,default:[]}},Bn={$schema:Mn,$id:Nn,$vocabulary:Pn,$dynamicAnchor:Fn,title:In,type:Ln,properties:Rn,$defs:zn}})),Hn=s((e=>{Object.defineProperty(e,"__esModule",{value:!0});let t=(xt(),d(ut).default),n=(Mt(),d(St).default),r=(Ht(),d(Nt).default),i=(Qt(),d(Ut).default),a=(un(),d($t).default),o=(bn(),d(dn).default),s=(An(),d(xn).default),c=(Vn(),d(jn).default),l=[`/properties`];function u(e){return[t,n,r,i,a,u(this,o),s,u(this,c)].forEach(e=>this.addMetaSchema(e,void 0,!1)),this;function u(t,n){return e?t.$dataMetaSchema(n,l):n}}e.default=u})),Un=u(s(((e,t)=>{Object.defineProperty(e,"__esModule",{value:!0}),e.MissingRefError=e.ValidationError=e.CodeGen=e.Name=e.nil=e.stringify=e.str=e._=e.KeywordCxt=e.Ajv2020=void 0;let n=fe(),r=st(),i=lt(),a=Hn(),o=`https://json-schema.org/draft/2020-12/schema`;var s=class extends n.default{constructor(e={}){super({...e,dynamicRef:!0,next:!0,unevaluated:!0})}_addVocabularies(){super._addVocabularies(),r.default.forEach(e=>this.addVocabulary(e)),this.opts.discriminator&&this.addKeyword(i.default)}_addDefaultMetaSchema(){super._addDefaultMetaSchema();let{$data:e,meta:t}=this.opts;t&&(a.default.call(this,e),this.refs[`http://json-schema.org/schema`]=o)}defaultMeta(){return this.opts.defaultMeta=super.defaultMeta()||(this.getSchema(o)?o:void 0)}};e.Ajv2020=s,t.exports=e=s,t.exports.Ajv2020=s,Object.defineProperty(e,"__esModule",{value:!0}),e.default=s;var c=E();Object.defineProperty(e,"KeywordCxt",{enumerable:!0,get:function(){return c.KeywordCxt}});var l=m();Object.defineProperty(e,"_",{enumerable:!0,get:function(){return l._}}),Object.defineProperty(e,"str",{enumerable:!0,get:function(){return l.str}}),Object.defineProperty(e,"stringify",{enumerable:!0,get:function(){return l.stringify}}),Object.defineProperty(e,"nil",{enumerable:!0,get:function(){return l.nil}}),Object.defineProperty(e,"Name",{enumerable:!0,get:function(){return l.Name}}),Object.defineProperty(e,"CodeGen",{enumerable:!0,get:function(){return l.CodeGen}});var u=D();Object.defineProperty(e,"ValidationError",{enumerable:!0,get:function(){return u.default}});var d=O();Object.defineProperty(e,"MissingRefError",{enumerable:!0,get:function(){return d.default}})}))(),1),Wn=`{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:ai-ascension:recorded-run-bundle:v1:candidate:2",
  "title": "Recorded-run candidate 1 documents",
  "oneOf": [
    {
      "$ref": "#/$defs/manifest"
    },
    {
      "$ref": "#/$defs/record"
    },
    {
      "$ref": "#/$defs/omissions"
    }
  ],
  "$defs": {
    "identity": {
      "type": "object",
      "properties": {
        "namespace": {
          "type": "string",
          "minLength": 1,
          "maxLength": 128,
          "pattern": "^[a-z0-9][a-z0-9_.-]*$"
        },
        "value": {
          "type": "string",
          "minLength": 1,
          "maxLength": 256,
          "pattern": "^[A-Za-z0-9][A-Za-z0-9_.:-]*$"
        }
      },
      "required": [
        "namespace",
        "value"
      ],
      "additionalProperties": false
    },
    "identities": {
      "type": "object",
      "properties": {
        "run": {
          "$ref": "#/$defs/identity"
        },
        "session": {
          "$ref": "#/$defs/identity"
        },
        "episode": {
          "$ref": "#/$defs/identity"
        },
        "trajectory": {
          "$ref": "#/$defs/identity"
        },
        "request": {
          "$ref": "#/$defs/identity"
        },
        "action": {
          "$ref": "#/$defs/identity"
        },
        "trace": {
          "$ref": "#/$defs/identity"
        },
        "model_execution": {
          "$ref": "#/$defs/identity"
        },
        "workflow": {
          "$ref": "#/$defs/identity"
        },
        "instance": {
          "$ref": "#/$defs/identity"
        },
        "mcp_session": {
          "$ref": "#/$defs/identity"
        },
        "lease": {
          "$ref": "#/$defs/identity"
        },
        "operation": {
          "$ref": "#/$defs/identity"
        },
        "correlation": {
          "$ref": "#/$defs/identity"
        },
        "provider_request": {
          "$ref": "#/$defs/identity"
        }
      },
      "required": [],
      "additionalProperties": false
    },
    "evidence": {
      "type": "object",
      "properties": {
        "process_exit": {
          "enum": [
            "unknown",
            "completed",
            "failed"
          ]
        },
        "request": {
          "enum": [
            "unknown",
            "accepted",
            "rejected"
          ]
        },
        "action": {
          "enum": [
            "unknown",
            "accepted",
            "settled",
            "rejected",
            "cancelled"
          ]
        },
        "outcome": {
          "enum": [
            "unknown",
            "observed"
          ]
        },
        "gameplay": {
          "enum": [
            "unknown",
            "episode_failed",
            "completed"
          ]
        }
      },
      "required": [
        "process_exit",
        "request",
        "action",
        "outcome",
        "gameplay"
      ],
      "additionalProperties": false
    },
    "source": {
      "type": "object",
      "properties": {
        "stream": {
          "type": "string",
          "minLength": 1,
          "maxLength": 64,
          "pattern": "^[a-z0-9][a-z0-9_-]*$"
        },
        "record_ordinal": {
          "type": "integer",
          "minimum": 0,
          "maximum": 25000
        },
        "subrecord_ordinal": {
          "type": "integer",
          "minimum": 0,
          "maximum": 25000
        },
        "stream_sequence": {
          "type": "string",
          "minLength": 1,
          "maxLength": 20,
          "pattern": "^(0|[1-9][0-9]{0,19})$"
        }
      },
      "required": [
        "stream",
        "record_ordinal",
        "subrecord_ordinal"
      ],
      "additionalProperties": false
    },
    "payload": {
      "oneOf": [
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "seed_start"
            },
            "value": {
              "type": "object",
              "properties": {
                "protocol_version": {
                  "const": "seeded-run-v1"
                },
                "schema_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "context_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "generation": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 20,
                  "pattern": "^(0|[1-9][0-9]{0,19})$"
                },
                "run_started": {
                  "type": "boolean"
                },
                "host_ready": {
                  "type": "boolean"
                },
                "effect_kind": {
                  "enum": [
                    "run_started",
                    "unknown"
                  ]
                },
                "requested_seed_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "canonical_seed_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "seed_match": {
                  "type": "boolean"
                },
                "status": {
                  "enum": [
                    "accepted",
                    "settled",
                    "rejected",
                    "unknown",
                    "cancelled"
                  ]
                }
              },
              "required": [
                "protocol_version",
                "schema_digest",
                "context_digest",
                "generation",
                "run_started",
                "host_ready",
                "effect_kind",
                "requested_seed_digest",
                "canonical_seed_digest",
                "seed_match",
                "status"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "observation_summary"
            },
            "value": {
              "type": "object",
              "properties": {
                "generation": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 20,
                  "pattern": "^(0|[1-9][0-9]{0,19})$"
                },
                "state_id_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "observation_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "legal_action_count": {
                  "type": "integer",
                  "minimum": 0,
                  "maximum": 25000
                },
                "player": {
                  "type": "object",
                  "additionalProperties": false,
                  "required": [],
                  "properties": {
                    "hp": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "max_hp": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "energy": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "gold": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    }
                  }
                }
              },
              "required": [
                "generation",
                "state_id_digest",
                "observation_digest",
                "legal_action_count"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "decision_summary"
            },
            "value": {
              "type": "object",
              "properties": {
                "action_id_digests": {
                  "type": "array",
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 64,
                    "pattern": "^[a-f0-9]{64}$"
                  },
                  "maxItems": 128
                },
                "reused_model_execution": {
                  "type": "boolean"
                },
                "observation": {
                  "type": "object",
                  "properties": {
                    "generation": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "state_id_digest": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 64,
                      "pattern": "^[a-f0-9]{64}$"
                    },
                    "observation_digest": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 64,
                      "pattern": "^[a-f0-9]{64}$"
                    },
                    "legal_action_count": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 25000
                    },
                    "player": {
                      "type": "object",
                      "additionalProperties": false,
                      "required": [],
                      "properties": {
                        "hp": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        },
                        "max_hp": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        },
                        "energy": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        },
                        "gold": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        }
                      }
                    }
                  },
                  "required": [
                    "generation",
                    "state_id_digest",
                    "observation_digest",
                    "legal_action_count"
                  ],
                  "additionalProperties": false
                }
              },
              "required": [
                "action_id_digests"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "action_outcome"
            },
            "value": {
              "type": "object",
              "properties": {
                "status": {
                  "enum": [
                    "accepted",
                    "settled",
                    "rejected",
                    "unknown",
                    "cancelled"
                  ]
                },
                "observation": {
                  "type": "object",
                  "properties": {
                    "generation": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "state_id_digest": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 64,
                      "pattern": "^[a-f0-9]{64}$"
                    },
                    "observation_digest": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 64,
                      "pattern": "^[a-f0-9]{64}$"
                    },
                    "legal_action_count": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 25000
                    },
                    "player": {
                      "type": "object",
                      "additionalProperties": false,
                      "required": [],
                      "properties": {
                        "hp": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        },
                        "max_hp": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        },
                        "energy": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        },
                        "gold": {
                          "type": "string",
                          "minLength": 1,
                          "maxLength": 20,
                          "pattern": "^(0|[1-9][0-9]{0,19})$"
                        }
                      }
                    }
                  },
                  "required": [
                    "generation",
                    "state_id_digest",
                    "observation_digest",
                    "legal_action_count"
                  ],
                  "additionalProperties": false
                },
                "from_generation": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 20,
                  "pattern": "^(0|[1-9][0-9]{0,19})$"
                },
                "to_generation": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 20,
                  "pattern": "^(0|[1-9][0-9]{0,19})$"
                },
                "effect_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                }
              },
              "required": [
                "status"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "accounting"
            },
            "value": {
              "type": "object",
              "properties": {
                "source_schema": {
                  "const": "sts2.provider-accounting-v1"
                },
                "provider": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 128,
                  "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
                },
                "model": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 128,
                  "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
                },
                "provider_execution_status": {
                  "enum": [
                    "completed",
                    "unknown"
                  ]
                },
                "decision_status": {
                  "enum": [
                    "valid",
                    "unknown"
                  ]
                },
                "provider_request_identity_kind": {
                  "enum": [
                    "codex_thread_id",
                    "unknown"
                  ]
                },
                "provider_request_identity_status": {
                  "enum": [
                    "reported",
                    "unknown"
                  ]
                },
                "request_sha256": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "decision_sha256": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "input_written": {
                  "type": "boolean"
                },
                "counts": {
                  "type": "object",
                  "properties": {
                    "stdout_bytes": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "stderr_bytes": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "event_count": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "turn_count": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    },
                    "completed_turn_count": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 20,
                      "pattern": "^(0|[1-9][0-9]{0,19})$"
                    }
                  },
                  "required": [],
                  "additionalProperties": false
                },
                "usage": {
                  "type": "object",
                  "properties": {
                    "input_tokens": {
                      "type": "object",
                      "properties": {
                        "unit": {
                          "const": "tokens"
                        },
                        "scope": {
                          "const": "model_execution"
                        },
                        "value_status": {
                          "enum": [
                            "reported",
                            "measured",
                            "estimated",
                            "unknown",
                            "not_applicable"
                          ]
                        },
                        "value": {
                          "anyOf": [
                            {
                              "type": "string",
                              "minLength": 1,
                              "maxLength": 20,
                              "pattern": "^(0|[1-9][0-9]{0,19})$"
                            },
                            {
                              "type": "null"
                            }
                          ]
                        }
                      },
                      "required": [
                        "unit",
                        "scope",
                        "value_status",
                        "value"
                      ],
                      "additionalProperties": false
                    },
                    "output_tokens": {
                      "type": "object",
                      "properties": {
                        "unit": {
                          "const": "tokens"
                        },
                        "scope": {
                          "const": "model_execution"
                        },
                        "value_status": {
                          "enum": [
                            "reported",
                            "measured",
                            "estimated",
                            "unknown",
                            "not_applicable"
                          ]
                        },
                        "value": {
                          "anyOf": [
                            {
                              "type": "string",
                              "minLength": 1,
                              "maxLength": 20,
                              "pattern": "^(0|[1-9][0-9]{0,19})$"
                            },
                            {
                              "type": "null"
                            }
                          ]
                        }
                      },
                      "required": [
                        "unit",
                        "scope",
                        "value_status",
                        "value"
                      ],
                      "additionalProperties": false
                    },
                    "cached_input_tokens": {
                      "type": "object",
                      "properties": {
                        "unit": {
                          "const": "tokens"
                        },
                        "scope": {
                          "const": "model_execution"
                        },
                        "value_status": {
                          "enum": [
                            "reported",
                            "measured",
                            "estimated",
                            "unknown",
                            "not_applicable"
                          ]
                        },
                        "value": {
                          "anyOf": [
                            {
                              "type": "string",
                              "minLength": 1,
                              "maxLength": 20,
                              "pattern": "^(0|[1-9][0-9]{0,19})$"
                            },
                            {
                              "type": "null"
                            }
                          ]
                        }
                      },
                      "required": [
                        "unit",
                        "scope",
                        "value_status",
                        "value"
                      ],
                      "additionalProperties": false
                    },
                    "cache_write_input_tokens": {
                      "type": "object",
                      "properties": {
                        "unit": {
                          "const": "tokens"
                        },
                        "scope": {
                          "const": "model_execution"
                        },
                        "value_status": {
                          "enum": [
                            "reported",
                            "measured",
                            "estimated",
                            "unknown",
                            "not_applicable"
                          ]
                        },
                        "value": {
                          "anyOf": [
                            {
                              "type": "string",
                              "minLength": 1,
                              "maxLength": 20,
                              "pattern": "^(0|[1-9][0-9]{0,19})$"
                            },
                            {
                              "type": "null"
                            }
                          ]
                        }
                      },
                      "required": [
                        "unit",
                        "scope",
                        "value_status",
                        "value"
                      ],
                      "additionalProperties": false
                    },
                    "reasoning_output_tokens": {
                      "type": "object",
                      "properties": {
                        "unit": {
                          "const": "tokens"
                        },
                        "scope": {
                          "const": "model_execution"
                        },
                        "value_status": {
                          "enum": [
                            "reported",
                            "measured",
                            "estimated",
                            "unknown",
                            "not_applicable"
                          ]
                        },
                        "value": {
                          "anyOf": [
                            {
                              "type": "string",
                              "minLength": 1,
                              "maxLength": 20,
                              "pattern": "^(0|[1-9][0-9]{0,19})$"
                            },
                            {
                              "type": "null"
                            }
                          ]
                        }
                      },
                      "required": [
                        "unit",
                        "scope",
                        "value_status",
                        "value"
                      ],
                      "additionalProperties": false
                    }
                  },
                  "required": [],
                  "additionalProperties": false
                }
              },
              "required": [
                "source_schema",
                "provider_execution_status",
                "decision_status",
                "counts",
                "usage"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "process_result"
            },
            "value": {
              "type": "object",
              "properties": {
                "exit_code": {
                  "type": "integer",
                  "minimum": -2147483648,
                  "maximum": 2147483647
                }
              },
              "required": [
                "exit_code"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "const": "ai-ascension.sts2.seed-readiness.v1"
            },
            "kind": {
              "const": "diagnostic"
            },
            "value": {
              "type": "object",
              "properties": {
                "code": {
                  "enum": [
                    "unsupported_source_event",
                    "unsupported_source_status",
                    "invalid_source_record",
                    "partial_final_record",
                    "operation_wait_completed",
                    "episode_failed",
                    "unsupported_profile"
                  ]
                },
                "value_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                }
              },
              "required": [
                "code"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        },
        {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "properties": {
            "profile": {
              "const": "ai-ascension.recorded-run.common.v1"
            },
            "kind": {
              "const": "gameplay_result"
            },
            "value": {
              "type": "object",
              "additionalProperties": false,
              "required": [
                "status",
                "result",
                "authority",
                "source_profile",
                "source_schema_sha256",
                "witness_sha256"
              ],
              "properties": {
                "status": {
                  "const": "completed"
                },
                "result": {
                  "enum": [
                    "victory",
                    "defeat",
                    "completed"
                  ]
                },
                "authority": {
                  "$ref": "#/$defs/identity"
                },
                "source_profile": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 128,
                  "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
                },
                "source_schema_sha256": {
                  "type": "string",
                  "pattern": "^[a-f0-9]{64}$",
                  "minLength": 64,
                  "maxLength": 64
                },
                "witness_sha256": {
                  "type": "string",
                  "pattern": "^[a-f0-9]{64}$",
                  "minLength": 64,
                  "maxLength": 64
                }
              }
            }
          }
        },
        {
          "type": "object",
          "properties": {
            "profile": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-z0-9][a-z0-9_.-]*$"
            },
            "kind": {
              "const": "opaque"
            },
            "value": {
              "type": "object",
              "properties": {
                "content_digest": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 64,
                  "pattern": "^[a-f0-9]{64}$"
                },
                "bytes": {
                  "type": "integer",
                  "minimum": 0,
                  "maximum": 16777216
                },
                "media_type": {
                  "const": "application/json"
                }
              },
              "required": [
                "content_digest",
                "bytes",
                "media_type"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "profile",
            "kind",
            "value"
          ],
          "additionalProperties": false
        }
      ]
    },
    "manifest": {
      "type": "object",
      "properties": {
        "format": {
          "const": "ai-ascension.recorded-run-bundle"
        },
        "format_version": {
          "const": "1.0.0-candidate.2"
        },
        "contract_schema_sha256": {
          "type": "string",
          "minLength": 1,
          "maxLength": 64,
          "pattern": "^[a-f0-9]{64}$"
        },
        "required_profiles": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128,
            "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
          },
          "maxItems": 16,
          "minItems": 1,
          "uniqueItems": true
        },
        "optional_profiles": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128,
            "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
          },
          "maxItems": 16,
          "uniqueItems": true
        },
        "bundle_id": {
          "type": "string",
          "minLength": 1,
          "maxLength": 64,
          "pattern": "^[a-f0-9]{64}$"
        },
        "recording": {
          "type": "object",
          "properties": {
            "identity": {
              "$ref": "#/$defs/identity"
            },
            "identities": {
              "$ref": "#/$defs/identities"
            }
          },
          "required": [
            "identity",
            "identities"
          ],
          "additionalProperties": false
        },
        "producer": {
          "type": "object",
          "properties": {
            "name": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "version": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "source_format": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            }
          },
          "required": [
            "name",
            "version",
            "source_format"
          ],
          "additionalProperties": false
        },
        "adapter": {
          "type": "object",
          "properties": {
            "name": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "version": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "source_revision": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            }
          },
          "required": [
            "name",
            "version",
            "source_revision"
          ],
          "additionalProperties": false
        },
        "versions": {
          "type": "object",
          "properties": {
            "protocol": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "runtime": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "game_mod": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "game": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "provider": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "model": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "workflow": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            },
            "schema": {
              "type": "string",
              "minLength": 1,
              "maxLength": 128,
              "pattern": "^[a-zA-Z0-9][a-zA-Z0-9_.:+-]*$"
            }
          },
          "required": [],
          "additionalProperties": false
        },
        "capabilities": {
          "type": "object",
          "properties": {
            "inspection": {
              "const": true
            },
            "execution_replay": {
              "const": false
            },
            "live_control": {
              "const": false
            },
            "raw_mcp": {
              "const": false
            }
          },
          "required": [
            "inspection",
            "execution_replay",
            "live_control",
            "raw_mcp"
          ],
          "additionalProperties": false
        },
        "completeness": {
          "type": "object",
          "properties": {
            "status": {
              "enum": [
                "complete",
                "partial",
                "unknown"
              ]
            },
            "source_snapshot": {
              "enum": [
                "stable",
                "unverified"
              ]
            }
          },
          "required": [
            "status",
            "source_snapshot"
          ],
          "additionalProperties": false
        },
        "evidence": {
          "$ref": "#/$defs/evidence"
        },
        "entries": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "path": {
                "enum": [
                  "records/events.ndjson",
                  "records/accounting.ndjson",
                  "reports/omissions.json"
                ]
              },
              "media_type": {
                "enum": [
                  "application/x-ndjson",
                  "application/json"
                ]
              },
              "bytes": {
                "type": "integer",
                "minimum": 0,
                "maximum": 16777216
              },
              "sha256": {
                "type": "string",
                "minLength": 1,
                "maxLength": 64,
                "pattern": "^[a-f0-9]{64}$"
              }
            },
            "required": [
              "path",
              "media_type",
              "bytes",
              "sha256"
            ],
            "additionalProperties": false
          },
          "maxItems": 31,
          "minItems": 2
        },
        "integrity": {
          "type": "object",
          "properties": {
            "digest_algorithm": {
              "const": "sha-256"
            },
            "bundle_semantic_digest": {
              "type": "string",
              "minLength": 1,
              "maxLength": 64,
              "pattern": "^[a-f0-9]{64}$"
            }
          },
          "required": [
            "digest_algorithm",
            "bundle_semantic_digest"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "format",
        "format_version",
        "contract_schema_sha256",
        "required_profiles",
        "optional_profiles",
        "bundle_id",
        "recording",
        "producer",
        "adapter",
        "versions",
        "capabilities",
        "completeness",
        "evidence",
        "entries",
        "integrity"
      ],
      "additionalProperties": false
    },
    "record": {
      "type": "object",
      "properties": {
        "profile": {
          "const": "ai-ascension.recorded-run.common.v1"
        },
        "source": {
          "$ref": "#/$defs/source"
        },
        "time": {
          "type": "object",
          "properties": {
            "unix_ns": {
              "type": "string",
              "minLength": 1,
              "maxLength": 20,
              "pattern": "^(0|[1-9][0-9]{0,19})$"
            }
          },
          "required": [
            "unix_ns"
          ],
          "additionalProperties": false
        },
        "identities": {
          "$ref": "#/$defs/identities"
        },
        "evidence": {
          "$ref": "#/$defs/evidence"
        },
        "payload": {
          "$ref": "#/$defs/payload"
        }
      },
      "required": [
        "profile",
        "source",
        "identities",
        "evidence",
        "payload"
      ],
      "additionalProperties": false
    },
    "omissions": {
      "type": "object",
      "properties": {
        "profile": {
          "const": "ai-ascension.recorded-run.common.v1"
        },
        "streams": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "stream": {
                "type": "string",
                "minLength": 1,
                "maxLength": 64,
                "pattern": "^[a-z0-9][a-z0-9_-]*$"
              },
              "state": {
                "enum": [
                  "present",
                  "absent",
                  "omitted",
                  "interrupted",
                  "unsupported",
                  "unknown"
                ]
              },
              "input_records": {
                "anyOf": [
                  {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 25000
                  },
                  {
                    "type": "null"
                  }
                ]
              },
              "emitted_rows": {
                "type": "integer",
                "minimum": 0,
                "maximum": 25000
              },
              "filtered_rows": {
                "type": "integer",
                "minimum": 0,
                "maximum": 25000
              },
              "unsupported_rows": {
                "type": "integer",
                "minimum": 0,
                "maximum": 25000
              },
              "rejected_rows": {
                "type": "integer",
                "minimum": 0,
                "maximum": 25000
              },
              "output_records": {
                "type": "integer",
                "minimum": 0,
                "maximum": 25000
              },
              "dispositions": {
                "type": "array",
                "items": {
                  "type": "object",
                  "properties": {
                    "first": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 25000
                    },
                    "last": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 25000
                    },
                    "disposition": {
                      "enum": [
                        "filtered",
                        "unsupported",
                        "rejected"
                      ]
                    },
                    "reason": {
                      "enum": [
                        "raw_mcp_disallowed",
                        "private_source_metadata",
                        "unsupported_source_event",
                        "unsupported_source_status",
                        "invalid_source_record",
                        "partial_final_record",
                        "optional_stream_absent"
                      ]
                    }
                  },
                  "required": [
                    "first",
                    "last",
                    "disposition",
                    "reason"
                  ],
                  "additionalProperties": false
                },
                "maxItems": 25000
              },
              "field_omissions": {
                "type": "array",
                "items": {
                  "type": "object",
                  "properties": {
                    "rule": {
                      "enum": [
                        "raw_mcp_disallowed",
                        "private_source_metadata",
                        "raw_observation_disallowed",
                        "raw_seed_disallowed",
                        "raw_decision_text_disallowed",
                        "raw_error_disallowed",
                        "provider_request_id_disallowed",
                        "identity_digest_transformation"
                      ]
                    },
                    "affected_rows": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 25000
                    }
                  },
                  "required": [
                    "rule",
                    "affected_rows"
                  ],
                  "additionalProperties": false
                },
                "maxItems": 16
              },
              "mcp_redacted_path_count": {
                "type": "integer",
                "minimum": 0,
                "maximum": 25000
              }
            },
            "required": [
              "stream",
              "state",
              "input_records",
              "emitted_rows",
              "filtered_rows",
              "unsupported_rows",
              "rejected_rows",
              "output_records",
              "dispositions",
              "field_omissions"
            ],
            "additionalProperties": false
          },
          "maxItems": 16,
          "minItems": 1
        },
        "fixture_provenance": {
          "enum": [
            "synthetic",
            "sanitized_source_derived"
          ]
        }
      },
      "required": [
        "profile",
        "streams",
        "fixture_provenance"
      ],
      "additionalProperties": false
    }
  }
}
`;
/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function Gn(e){return e instanceof Uint8Array||ArrayBuffer.isView(e)&&e.constructor.name===`Uint8Array`}function Kn(e,t,n=``){let r=Gn(e),i=e?.length,a=t!==void 0;if(!r||a&&i!==t){let o=n&&`"${n}" `,s=a?` of length ${t}`:``,c=r?`length=${i}`:`type=${typeof e}`;throw Error(o+`expected Uint8Array`+s+`, got `+c)}return e}function qn(e,t=!0){if(e.destroyed)throw Error(`Hash instance has been destroyed`);if(t&&e.finished)throw Error(`Hash#digest() has already been called`)}function Jn(e,t){Kn(e,void 0,`digestInto() output`);let n=t.outputLen;if(e.length<n)throw Error(`"digestInto() output" expected to be of length >=`+n)}function Yn(...e){for(let t=0;t<e.length;t++)e[t].fill(0)}function Xn(e){return new DataView(e.buffer,e.byteOffset,e.byteLength)}function N(e,t){return e<<32-t|e>>>t}let Zn=typeof Uint8Array.from([]).toHex==`function`&&typeof Uint8Array.fromHex==`function`,Qn=Array.from({length:256},(e,t)=>t.toString(16).padStart(2,`0`));function $n(e){if(Kn(e),Zn)return e.toHex();let t=``;for(let n=0;n<e.length;n++)t+=Qn[e[n]];return t}function er(e,t={}){let n=(t,n)=>e(n).update(t).digest(),r=e(void 0);return n.outputLen=r.outputLen,n.blockLen=r.blockLen,n.create=t=>e(t),Object.assign(n,t),Object.freeze(n)}let tr=e=>({oid:Uint8Array.from([6,9,96,134,72,1,101,3,4,2,e])});function nr(e,t,n){return e&t^~e&n}function rr(e,t,n){return e&t^e&n^t&n}var ir=class{blockLen;outputLen;padOffset;isLE;buffer;view;finished=!1;length=0;pos=0;destroyed=!1;constructor(e,t,n,r){this.blockLen=e,this.outputLen=t,this.padOffset=n,this.isLE=r,this.buffer=new Uint8Array(e),this.view=Xn(this.buffer)}update(e){qn(this),Kn(e);let{view:t,buffer:n,blockLen:r}=this,i=e.length;for(let a=0;a<i;){let o=Math.min(r-this.pos,i-a);if(o===r){let t=Xn(e);for(;r<=i-a;a+=r)this.process(t,a);continue}n.set(e.subarray(a,a+o),this.pos),this.pos+=o,a+=o,this.pos===r&&(this.process(t,0),this.pos=0)}return this.length+=e.length,this.roundClean(),this}digestInto(e){qn(this),Jn(e,this),this.finished=!0;let{buffer:t,view:n,blockLen:r,isLE:i}=this,{pos:a}=this;t[a++]=128,Yn(this.buffer.subarray(a)),this.padOffset>r-a&&(this.process(n,0),a=0);for(let e=a;e<r;e++)t[e]=0;n.setBigUint64(r-8,BigInt(this.length*8),i),this.process(n,0);let o=Xn(e),s=this.outputLen;if(s%4)throw Error(`_sha2: outputLen must be aligned to 32bit`);let c=s/4,l=this.get();if(c>l.length)throw Error(`_sha2: outputLen bigger than state`);for(let e=0;e<c;e++)o.setUint32(4*e,l[e],i)}digest(){let{buffer:e,outputLen:t}=this;this.digestInto(e);let n=e.slice(0,t);return this.destroy(),n}_cloneInto(e){e||=new this.constructor,e.set(...this.get());let{blockLen:t,buffer:n,length:r,finished:i,destroyed:a,pos:o}=this;return e.destroyed=a,e.finished=i,e.length=r,e.pos=o,r%t&&e.buffer.set(n),e}clone(){return this._cloneInto()}};let ar=Uint32Array.from([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),or=Uint32Array.from([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),sr=new Uint32Array(64);var cr=class extends ir{constructor(e){super(64,e,8,!1)}get(){let{A:e,B:t,C:n,D:r,E:i,F:a,G:o,H:s}=this;return[e,t,n,r,i,a,o,s]}set(e,t,n,r,i,a,o,s){this.A=e|0,this.B=t|0,this.C=n|0,this.D=r|0,this.E=i|0,this.F=a|0,this.G=o|0,this.H=s|0}process(e,t){for(let n=0;n<16;n++,t+=4)sr[n]=e.getUint32(t,!1);for(let e=16;e<64;e++){let t=sr[e-15],n=sr[e-2],r=N(t,7)^N(t,18)^t>>>3,i=N(n,17)^N(n,19)^n>>>10;sr[e]=i+sr[e-7]+r+sr[e-16]|0}let{A:n,B:r,C:i,D:a,E:o,F:s,G:c,H:l}=this;for(let e=0;e<64;e++){let t=N(o,6)^N(o,11)^N(o,25),u=l+t+nr(o,s,c)+or[e]+sr[e]|0,d=(N(n,2)^N(n,13)^N(n,22))+rr(n,r,i)|0;l=c,c=s,s=o,o=a+u|0,a=i,i=r,r=n,n=u+d|0}n=n+this.A|0,r=r+this.B|0,i=i+this.C|0,a=a+this.D|0,o=o+this.E|0,s=s+this.F|0,c=c+this.G|0,l=l+this.H|0,this.set(n,r,i,a,o,s,c,l)}roundClean(){Yn(sr)}destroy(){this.set(0,0,0,0,0,0,0,0),Yn(this.buffer)}},lr=class extends cr{A=ar[0]|0;B=ar[1]|0;C=ar[2]|0;D=ar[3]|0;E=ar[4]|0;F=ar[5]|0;G=ar[6]|0;H=ar[7]|0;constructor(){super(32)}};let ur=er(()=>new lr,tr(1));Object.freeze({status:`aborted`});function P(e,t,n){function r(n,r){var i;Object.defineProperty(n,"_zod",{value:n._zod??{},enumerable:!1}),(i=n._zod).traits??(i.traits=new Set),n._zod.traits.add(e),t(n,r);for(let e in o.prototype)e in n||Object.defineProperty(n,e,{value:o.prototype[e].bind(n)});n._zod.constr=o,n._zod.def=r}let i=n?.Parent??Object;class a extends i{}Object.defineProperty(a,"name",{value:e});function o(e){var t;let i=n?.Parent?new a:this;r(i,e),(t=i._zod).deferred??(t.deferred=[]);for(let e of i._zod.deferred)e();return i}return Object.defineProperty(o,"init",{value:r}),Object.defineProperty(o,Symbol.hasInstance,{value:t=>n?.Parent&&t instanceof n.Parent?!0:t?._zod?.traits?.has(e)}),Object.defineProperty(o,"name",{value:e}),o}var dr=class extends Error{constructor(){super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`)}},fr=class extends Error{constructor(e){super(`Encountered unidirectional transform during encode: ${e}`),this.name=`ZodEncodeError`}};let pr={};function mr(e){return e&&Object.assign(pr,e),pr}function hr(e){let t=Object.values(e).filter(e=>typeof e==`number`);return Object.entries(e).filter(([e,n])=>t.indexOf(+e)===-1).map(([e,t])=>t)}function gr(e,t){return typeof t==`bigint`?t.toString():t}function _r(e){return{get value(){{let t=e();return Object.defineProperty(this,"value",{value:t}),t}}}}function vr(e){return e==null}function yr(e){let t=+!!e.startsWith(`^`),n=e.endsWith(`$`)?e.length-1:e.length;return e.slice(t,n)}function br(e,t){let n=(e.toString().split(`.`)[1]||``).length,r=t.toString(),i=(r.split(`.`)[1]||``).length;if(i===0&&/\d?e-\d?/.test(r)){let e=r.match(/\d?e-(\d?)/);e?.[1]&&(i=Number.parseInt(e[1]))}let a=n>i?n:i;return Number.parseInt(e.toFixed(a).replace(`.`,``))%Number.parseInt(t.toFixed(a).replace(`.`,``))/10**a}let xr=Symbol(`evaluating`);function F(e,t,n){let r;Object.defineProperty(e,t,{get(){if(r!==xr)return r===void 0&&(r=xr,r=n()),r},set(n){Object.defineProperty(e,t,{value:n})},configurable:!0})}function Sr(e,t,n){Object.defineProperty(e,t,{value:n,writable:!0,enumerable:!0,configurable:!0})}function Cr(...e){let t={};for(let n of e){let e=Object.getOwnPropertyDescriptors(n);Object.assign(t,e)}return Object.defineProperties({},t)}function wr(e){return JSON.stringify(e)}let Tr=`captureStackTrace`in Error?Error.captureStackTrace:(...e)=>{};function Er(e){return typeof e==`object`&&!!e&&!Array.isArray(e)}let Dr=_r(()=>{if(typeof navigator<`u`&&navigator?.userAgent?.includes(`Cloudflare`))return!1;try{return Function(``),!0}catch{return!1}});function Or(e){if(Er(e)===!1)return!1;let t=e.constructor;if(t===void 0)return!0;let n=t.prototype;return Er(n)!==!1&&Object.prototype.hasOwnProperty.call(n,`isPrototypeOf`)!==!1}function kr(e){return Or(e)?{...e}:Array.isArray(e)?[...e]:e}let Ar=new Set([`string`,`number`,`symbol`]);function jr(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}function Mr(e,t,n){let r=new e._zod.constr(t??e._zod.def);return(!t||n?.parent)&&(r._zod.parent=e),r}function I(e){let t=e;if(!t)return{};if(typeof t==`string`)return{error:()=>t};if(t?.message!==void 0){if(t?.error!==void 0)throw Error("Cannot specify both `message` and `error` params");t.error=t.message}return delete t.message,typeof t.error==`string`?{...t,error:()=>t.error}:t}function Nr(e){return Object.keys(e).filter(t=>e[t]._zod.optin===`optional`&&e[t]._zod.optout===`optional`)}let Pr={safeint:[-(2**53-1),2**53-1],int32:[-2147483648,2147483647],uint32:[0,4294967295],float32:[-34028234663852886e22,34028234663852886e22],float64:[-Number.MAX_VALUE,Number.MAX_VALUE]};function Fr(e,t){let n=e._zod.def;return Mr(e,Cr(e._zod.def,{get shape(){let e={};for(let r in t){if(!(r in n.shape))throw Error(`Unrecognized key: "${r}"`);t[r]&&(e[r]=n.shape[r])}return Sr(this,`shape`,e),e},checks:[]}))}function Ir(e,t){let n=e._zod.def;return Mr(e,Cr(e._zod.def,{get shape(){let r={...e._zod.def.shape};for(let e in t){if(!(e in n.shape))throw Error(`Unrecognized key: "${e}"`);t[e]&&delete r[e]}return Sr(this,`shape`,r),r},checks:[]}))}function Lr(e,t){if(!Or(t))throw Error(`Invalid input to extend: expected a plain object`);let n=e._zod.def.checks;if(n&&n.length>0)throw Error("Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.");return Mr(e,Cr(e._zod.def,{get shape(){let n={...e._zod.def.shape,...t};return Sr(this,`shape`,n),n},checks:[]}))}function Rr(e,t){if(!Or(t))throw Error(`Invalid input to safeExtend: expected a plain object`);return Mr(e,{...e._zod.def,get shape(){let n={...e._zod.def.shape,...t};return Sr(this,`shape`,n),n},checks:e._zod.def.checks})}function zr(e,t){return Mr(e,Cr(e._zod.def,{get shape(){let n={...e._zod.def.shape,...t._zod.def.shape};return Sr(this,`shape`,n),n},get catchall(){return t._zod.def.catchall},checks:[]}))}function Br(e,t,n){return Mr(t,Cr(t._zod.def,{get shape(){let r=t._zod.def.shape,i={...r};if(n)for(let t in n){if(!(t in r))throw Error(`Unrecognized key: "${t}"`);n[t]&&(i[t]=e?new e({type:`optional`,innerType:r[t]}):r[t])}else for(let t in r)i[t]=e?new e({type:`optional`,innerType:r[t]}):r[t];return Sr(this,`shape`,i),i},checks:[]}))}function Vr(e,t,n){return Mr(t,Cr(t._zod.def,{get shape(){let r=t._zod.def.shape,i={...r};if(n)for(let t in n){if(!(t in i))throw Error(`Unrecognized key: "${t}"`);n[t]&&(i[t]=new e({type:`nonoptional`,innerType:r[t]}))}else for(let t in r)i[t]=new e({type:`nonoptional`,innerType:r[t]});return Sr(this,`shape`,i),i},checks:[]}))}function Hr(e,t=0){if(e.aborted===!0)return!0;for(let n=t;n<e.issues.length;n++)if(e.issues[n]?.continue!==!0)return!0;return!1}function Ur(e,t){return t.map(t=>{var n;return(n=t).path??(n.path=[]),t.path.unshift(e),t})}function Wr(e){return typeof e==`string`?e:e?.message}function Gr(e,t,n){let r={...e,path:e.path??[]};return e.message||(r.message=Wr(e.inst?._zod.def?.error?.(e))??Wr(t?.error?.(e))??Wr(n.customError?.(e))??Wr(n.localeError?.(e))??`Invalid input`),delete r.inst,delete r.continue,t?.reportInput||delete r.input,r}function Kr(e){return Array.isArray(e)?`array`:typeof e==`string`?`string`:`unknown`}function qr(...e){let[t,n,r]=e;return typeof t==`string`?{message:t,code:`custom`,input:n,inst:r}:{...t}}let Jr=(e,t)=>{e.name=`$ZodError`,Object.defineProperty(e,"_zod",{value:e._zod,enumerable:!1}),Object.defineProperty(e,"issues",{value:t,enumerable:!1}),e.message=JSON.stringify(t,gr,2),Object.defineProperty(e,"toString",{value:()=>e.message,enumerable:!1})},Yr=P(`$ZodError`,Jr),Xr=P(`$ZodError`,Jr,{Parent:Error});function Zr(e,t=e=>e.message){let n={},r=[];for(let i of e.issues)i.path.length>0?(n[i.path[0]]=n[i.path[0]]||[],n[i.path[0]].push(t(i))):r.push(t(i));return{formErrors:r,fieldErrors:n}}function Qr(e,t=e=>e.message){let n={_errors:[]},r=e=>{for(let i of e.issues)if(i.code===`invalid_union`&&i.errors.length)i.errors.map(e=>r({issues:e}));else if(i.code===`invalid_key`)r({issues:i.issues});else if(i.code===`invalid_element`)r({issues:i.issues});else if(i.path.length===0)n._errors.push(t(i));else{let e=n,r=0;for(;r<i.path.length;){let n=i.path[r];r===i.path.length-1?(e[n]=e[n]||{_errors:[]},e[n]._errors.push(t(i))):e[n]=e[n]||{_errors:[]},e=e[n],r++}}};return r(e),n}let $r=e=>(t,n,r,i)=>{let a=r?Object.assign(r,{async:!1}):{async:!1},o=t._zod.run({value:n,issues:[]},a);if(o instanceof Promise)throw new dr;if(o.issues.length){let t=new((i?.Err)??e)(o.issues.map(e=>Gr(e,a,mr())));throw Tr(t,i?.callee),t}return o.value},ei=e=>async(t,n,r,i)=>{let a=r?Object.assign(r,{async:!0}):{async:!0},o=t._zod.run({value:n,issues:[]},a);if(o instanceof Promise&&(o=await o),o.issues.length){let t=new((i?.Err)??e)(o.issues.map(e=>Gr(e,a,mr())));throw Tr(t,i?.callee),t}return o.value},ti=e=>(t,n,r)=>{let i=r?{...r,async:!1}:{async:!1},a=t._zod.run({value:n,issues:[]},i);if(a instanceof Promise)throw new dr;return a.issues.length?{success:!1,error:new(e??Yr)(a.issues.map(e=>Gr(e,i,mr())))}:{success:!0,data:a.value}},ni=ti(Xr),ri=e=>async(t,n,r)=>{let i=r?Object.assign(r,{async:!0}):{async:!0},a=t._zod.run({value:n,issues:[]},i);return a instanceof Promise&&(a=await a),a.issues.length?{success:!1,error:new e(a.issues.map(e=>Gr(e,i,mr())))}:{success:!0,data:a.value}},ii=ri(Xr),ai=e=>(t,n,r)=>{let i=r?Object.assign(r,{direction:`backward`}):{direction:`backward`};return $r(e)(t,n,i)},oi=e=>(t,n,r)=>$r(e)(t,n,r),si=e=>async(t,n,r)=>{let i=r?Object.assign(r,{direction:`backward`}):{direction:`backward`};return ei(e)(t,n,i)},ci=e=>async(t,n,r)=>ei(e)(t,n,r),li=e=>(t,n,r)=>{let i=r?Object.assign(r,{direction:`backward`}):{direction:`backward`};return ti(e)(t,n,i)},ui=e=>(t,n,r)=>ti(e)(t,n,r),di=e=>async(t,n,r)=>{let i=r?Object.assign(r,{direction:`backward`}):{direction:`backward`};return ri(e)(t,n,i)},fi=e=>async(t,n,r)=>ri(e)(t,n,r),pi=/^[cC][^\s-]{8,}$/,mi=/^[0-9a-z]+$/,hi=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,gi=/^[0-9a-vA-V]{20}$/,_i=/^[A-Za-z0-9]{27}$/,vi=/^[a-zA-Z0-9_-]{21}$/,yi=/^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,bi=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,xi=e=>e?RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`):/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,Si=/^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;function Ci(){return RegExp(`^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`,`u`)}let wi=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,Ti=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,Ei=/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,Di=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,Oi=/^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,ki=/^[A-Za-z0-9_-]*$/,Ai=/^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/,ji=/^\+(?:[0-9]){6,14}[0-9]$/,Mi=`(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`,Ni=RegExp(`^${Mi}$`);function Pi(e){let t=`(?:[01]\\d|2[0-3]):[0-5]\\d`;return typeof e.precision==`number`?e.precision===-1?`${t}`:e.precision===0?`${t}:[0-5]\\d`:`${t}:[0-5]\\d\\.\\d{${e.precision}}`:`${t}(?::[0-5]\\d(?:\\.\\d+)?)?`}function Fi(e){return RegExp(`^${Pi(e)}$`)}function Ii(e){let t=Pi({precision:e.precision}),n=[`Z`];e.local&&n.push(``),e.offset&&n.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);let r=`${t}(?:${n.join(`|`)})`;return RegExp(`^${Mi}T(?:${r})$`)}let Li=e=>{let t=e?`[\\s\\S]{${e?.minimum??0},${e?.maximum??``}}`:`[\\s\\S]*`;return RegExp(`^${t}$`)},Ri=/^-?\d+$/,zi=/^-?\d+(?:\.\d+)?/,Bi=/^(?:true|false)$/i,Vi=/^null$/i,Hi=/^[^A-Z]*$/,Ui=/^[^a-z]*$/,L=P(`$ZodCheck`,(e,t)=>{var n;e._zod??={},e._zod.def=t,(n=e._zod).onattach??(n.onattach=[])}),Wi={number:`number`,bigint:`bigint`,object:`date`},Gi=P(`$ZodCheckLessThan`,(e,t)=>{L.init(e,t);let n=Wi[typeof t.value];e._zod.onattach.push(e=>{let n=e._zod.bag,r=(t.inclusive?n.maximum:n.exclusiveMaximum)??1/0;t.value<r&&(t.inclusive?n.maximum=t.value:n.exclusiveMaximum=t.value)}),e._zod.check=r=>{(t.inclusive?r.value<=t.value:r.value<t.value)||r.issues.push({origin:n,code:`too_big`,maximum:t.value,input:r.value,inclusive:t.inclusive,inst:e,continue:!t.abort})}}),Ki=P(`$ZodCheckGreaterThan`,(e,t)=>{L.init(e,t);let n=Wi[typeof t.value];e._zod.onattach.push(e=>{let n=e._zod.bag,r=(t.inclusive?n.minimum:n.exclusiveMinimum)??-1/0;t.value>r&&(t.inclusive?n.minimum=t.value:n.exclusiveMinimum=t.value)}),e._zod.check=r=>{(t.inclusive?r.value>=t.value:r.value>t.value)||r.issues.push({origin:n,code:`too_small`,minimum:t.value,input:r.value,inclusive:t.inclusive,inst:e,continue:!t.abort})}}),qi=P(`$ZodCheckMultipleOf`,(e,t)=>{L.init(e,t),e._zod.onattach.push(e=>{var n;(n=e._zod.bag).multipleOf??(n.multipleOf=t.value)}),e._zod.check=n=>{if(typeof n.value!=typeof t.value)throw Error(`Cannot mix number and bigint in multiple_of check.`);(typeof n.value==`bigint`?n.value%t.value===BigInt(0):br(n.value,t.value)===0)||n.issues.push({origin:typeof n.value,code:`not_multiple_of`,divisor:t.value,input:n.value,inst:e,continue:!t.abort})}}),Ji=P(`$ZodCheckNumberFormat`,(e,t)=>{L.init(e,t),t.format=t.format||`float64`;let n=t.format?.includes(`int`),r=n?`int`:`number`,[i,a]=Pr[t.format];e._zod.onattach.push(e=>{let r=e._zod.bag;r.format=t.format,r.minimum=i,r.maximum=a,n&&(r.pattern=Ri)}),e._zod.check=o=>{let s=o.value;if(n){if(!Number.isInteger(s)){o.issues.push({expected:r,format:t.format,code:`invalid_type`,continue:!1,input:s,inst:e});return}if(!Number.isSafeInteger(s)){s>0?o.issues.push({input:s,code:`too_big`,maximum:2**53-1,note:`Integers must be within the safe integer range.`,inst:e,origin:r,continue:!t.abort}):o.issues.push({input:s,code:`too_small`,minimum:-(2**53-1),note:`Integers must be within the safe integer range.`,inst:e,origin:r,continue:!t.abort});return}}s<i&&o.issues.push({origin:`number`,input:s,code:`too_small`,minimum:i,inclusive:!0,inst:e,continue:!t.abort}),s>a&&o.issues.push({origin:`number`,input:s,code:`too_big`,maximum:a,inst:e})}}),Yi=P(`$ZodCheckMaxLength`,(e,t)=>{var n;L.init(e,t),(n=e._zod.def).when??(n.when=e=>{let t=e.value;return!vr(t)&&t.length!==void 0}),e._zod.onattach.push(e=>{let n=e._zod.bag.maximum??1/0;t.maximum<n&&(e._zod.bag.maximum=t.maximum)}),e._zod.check=n=>{let r=n.value;if(r.length<=t.maximum)return;let i=Kr(r);n.issues.push({origin:i,code:`too_big`,maximum:t.maximum,inclusive:!0,input:r,inst:e,continue:!t.abort})}}),Xi=P(`$ZodCheckMinLength`,(e,t)=>{var n;L.init(e,t),(n=e._zod.def).when??(n.when=e=>{let t=e.value;return!vr(t)&&t.length!==void 0}),e._zod.onattach.push(e=>{let n=e._zod.bag.minimum??-1/0;t.minimum>n&&(e._zod.bag.minimum=t.minimum)}),e._zod.check=n=>{let r=n.value;if(r.length>=t.minimum)return;let i=Kr(r);n.issues.push({origin:i,code:`too_small`,minimum:t.minimum,inclusive:!0,input:r,inst:e,continue:!t.abort})}}),Zi=P(`$ZodCheckLengthEquals`,(e,t)=>{var n;L.init(e,t),(n=e._zod.def).when??(n.when=e=>{let t=e.value;return!vr(t)&&t.length!==void 0}),e._zod.onattach.push(e=>{let n=e._zod.bag;n.minimum=t.length,n.maximum=t.length,n.length=t.length}),e._zod.check=n=>{let r=n.value,i=r.length;if(i===t.length)return;let a=Kr(r),o=i>t.length;n.issues.push({origin:a,...o?{code:`too_big`,maximum:t.length}:{code:`too_small`,minimum:t.length},inclusive:!0,exact:!0,input:n.value,inst:e,continue:!t.abort})}}),Qi=P(`$ZodCheckStringFormat`,(e,t)=>{var n,r;L.init(e,t),e._zod.onattach.push(e=>{let n=e._zod.bag;n.format=t.format,t.pattern&&(n.patterns??=new Set,n.patterns.add(t.pattern))}),t.pattern?(n=e._zod).check??(n.check=n=>{t.pattern.lastIndex=0,!t.pattern.test(n.value)&&n.issues.push({origin:`string`,code:`invalid_format`,format:t.format,input:n.value,...t.pattern?{pattern:t.pattern.toString()}:{},inst:e,continue:!t.abort})}):(r=e._zod).check??(r.check=()=>{})}),$i=P(`$ZodCheckRegex`,(e,t)=>{Qi.init(e,t),e._zod.check=n=>{t.pattern.lastIndex=0,!t.pattern.test(n.value)&&n.issues.push({origin:`string`,code:`invalid_format`,format:`regex`,input:n.value,pattern:t.pattern.toString(),inst:e,continue:!t.abort})}}),ea=P(`$ZodCheckLowerCase`,(e,t)=>{t.pattern??=Hi,Qi.init(e,t)}),ta=P(`$ZodCheckUpperCase`,(e,t)=>{t.pattern??=Ui,Qi.init(e,t)}),na=P(`$ZodCheckIncludes`,(e,t)=>{L.init(e,t);let n=jr(t.includes),r=new RegExp(typeof t.position==`number`?`^.{${t.position}}${n}`:n);t.pattern=r,e._zod.onattach.push(e=>{let t=e._zod.bag;t.patterns??=new Set,t.patterns.add(r)}),e._zod.check=n=>{n.value.includes(t.includes,t.position)||n.issues.push({origin:`string`,code:`invalid_format`,format:`includes`,includes:t.includes,input:n.value,inst:e,continue:!t.abort})}}),ra=P(`$ZodCheckStartsWith`,(e,t)=>{L.init(e,t);let n=RegExp(`^${jr(t.prefix)}.*`);t.pattern??=n,e._zod.onattach.push(e=>{let t=e._zod.bag;t.patterns??=new Set,t.patterns.add(n)}),e._zod.check=n=>{n.value.startsWith(t.prefix)||n.issues.push({origin:`string`,code:`invalid_format`,format:`starts_with`,prefix:t.prefix,input:n.value,inst:e,continue:!t.abort})}}),ia=P(`$ZodCheckEndsWith`,(e,t)=>{L.init(e,t);let n=RegExp(`.*${jr(t.suffix)}$`);t.pattern??=n,e._zod.onattach.push(e=>{let t=e._zod.bag;t.patterns??=new Set,t.patterns.add(n)}),e._zod.check=n=>{n.value.endsWith(t.suffix)||n.issues.push({origin:`string`,code:`invalid_format`,format:`ends_with`,suffix:t.suffix,input:n.value,inst:e,continue:!t.abort})}}),aa=P(`$ZodCheckOverwrite`,(e,t)=>{L.init(e,t),e._zod.check=e=>{e.value=t.tx(e.value)}});var oa=class{constructor(e=[]){this.content=[],this.indent=0,this&&(this.args=e)}indented(e){this.indent+=1,e(this),--this.indent}write(e){if(typeof e==`function`){e(this,{execution:`sync`}),e(this,{execution:`async`});return}let t=e.split(`
`).filter(e=>e),n=Math.min(...t.map(e=>e.length-e.trimStart().length)),r=t.map(e=>e.slice(n)).map(e=>` `.repeat(this.indent*2)+e);for(let e of r)this.content.push(e)}compile(){let e=Function,t=this?.args,n=[...(this?.content??[``]).map(e=>`  ${e}`)];return new e(...t,n.join(`
`))}};let sa={major:4,minor:1,patch:12},R=P(`$ZodType`,(e,t)=>{var n;e??={},e._zod.def=t,e._zod.bag=e._zod.bag||{},e._zod.version=sa;let r=[...e._zod.def.checks??[]];e._zod.traits.has(`$ZodCheck`)&&r.unshift(e);for(let t of r)for(let n of t._zod.onattach)n(e);if(r.length===0)(n=e._zod).deferred??(n.deferred=[]),e._zod.deferred?.push(()=>{e._zod.run=e._zod.parse});else{let t=(e,t,n)=>{let r=Hr(e),i;for(let a of t){if(a._zod.def.when){if(!a._zod.def.when(e))continue}else if(r)continue;let t=e.issues.length,o=a._zod.check(e);if(o instanceof Promise&&n?.async===!1)throw new dr;if(i||o instanceof Promise)i=(i??Promise.resolve()).then(async()=>{await o,e.issues.length!==t&&(r||=Hr(e,t))});else{if(e.issues.length===t)continue;r||=Hr(e,t)}}return i?i.then(()=>e):e},n=(n,i,a)=>{if(Hr(n))return n.aborted=!0,n;let o=t(i,r,a);if(o instanceof Promise){if(a.async===!1)throw new dr;return o.then(t=>e._zod.parse(t,a))}return e._zod.parse(o,a)};e._zod.run=(i,a)=>{if(a.skipChecks)return e._zod.parse(i,a);if(a.direction===`backward`){let t=e._zod.parse({value:i.value,issues:[]},{...a,skipChecks:!0});return t instanceof Promise?t.then(e=>n(e,i,a)):n(t,i,a)}let o=e._zod.parse(i,a);if(o instanceof Promise){if(a.async===!1)throw new dr;return o.then(e=>t(e,r,a))}return t(o,r,a)}}e[`~standard`]={validate:t=>{try{let n=ni(e,t);return n.success?{value:n.data}:{issues:n.error?.issues}}catch{return ii(e,t).then(e=>e.success?{value:e.data}:{issues:e.error?.issues})}},vendor:`zod`,version:1}}),ca=P(`$ZodString`,(e,t)=>{R.init(e,t),e._zod.pattern=[...e?._zod.bag?.patterns??[]].pop()??Li(e._zod.bag),e._zod.parse=(n,r)=>{if(t.coerce)try{n.value=String(n.value)}catch{}return typeof n.value==`string`||n.issues.push({expected:`string`,code:`invalid_type`,input:n.value,inst:e}),n}}),z=P(`$ZodStringFormat`,(e,t)=>{Qi.init(e,t),ca.init(e,t)}),la=P(`$ZodGUID`,(e,t)=>{t.pattern??=bi,z.init(e,t)}),ua=P(`$ZodUUID`,(e,t)=>{if(t.version){let e={v1:1,v2:2,v3:3,v4:4,v5:5,v6:6,v7:7,v8:8}[t.version];if(e===void 0)throw Error(`Invalid UUID version: "${t.version}"`);t.pattern??=xi(e)}else t.pattern??=xi();z.init(e,t)}),da=P(`$ZodEmail`,(e,t)=>{t.pattern??=Si,z.init(e,t)}),fa=P(`$ZodURL`,(e,t)=>{z.init(e,t),e._zod.check=n=>{try{let r=n.value.trim(),i=new URL(r);t.hostname&&(t.hostname.lastIndex=0,t.hostname.test(i.hostname)||n.issues.push({code:`invalid_format`,format:`url`,note:`Invalid hostname`,pattern:Ai.source,input:n.value,inst:e,continue:!t.abort})),t.protocol&&(t.protocol.lastIndex=0,t.protocol.test(i.protocol.endsWith(`:`)?i.protocol.slice(0,-1):i.protocol)||n.issues.push({code:`invalid_format`,format:`url`,note:`Invalid protocol`,pattern:t.protocol.source,input:n.value,inst:e,continue:!t.abort})),n.value=t.normalize?i.href:r;return}catch{n.issues.push({code:`invalid_format`,format:`url`,input:n.value,inst:e,continue:!t.abort})}}}),pa=P(`$ZodEmoji`,(e,t)=>{t.pattern??=Ci(),z.init(e,t)}),ma=P(`$ZodNanoID`,(e,t)=>{t.pattern??=vi,z.init(e,t)}),ha=P(`$ZodCUID`,(e,t)=>{t.pattern??=pi,z.init(e,t)}),ga=P(`$ZodCUID2`,(e,t)=>{t.pattern??=mi,z.init(e,t)}),_a=P(`$ZodULID`,(e,t)=>{t.pattern??=hi,z.init(e,t)}),va=P(`$ZodXID`,(e,t)=>{t.pattern??=gi,z.init(e,t)}),ya=P(`$ZodKSUID`,(e,t)=>{t.pattern??=_i,z.init(e,t)}),ba=P(`$ZodISODateTime`,(e,t)=>{t.pattern??=Ii(t),z.init(e,t)}),xa=P(`$ZodISODate`,(e,t)=>{t.pattern??=Ni,z.init(e,t)}),Sa=P(`$ZodISOTime`,(e,t)=>{t.pattern??=Fi(t),z.init(e,t)}),Ca=P(`$ZodISODuration`,(e,t)=>{t.pattern??=yi,z.init(e,t)}),wa=P(`$ZodIPv4`,(e,t)=>{t.pattern??=wi,z.init(e,t),e._zod.onattach.push(e=>{let t=e._zod.bag;t.format=`ipv4`})}),Ta=P(`$ZodIPv6`,(e,t)=>{t.pattern??=Ti,z.init(e,t),e._zod.onattach.push(e=>{let t=e._zod.bag;t.format=`ipv6`}),e._zod.check=n=>{try{new URL(`http://[${n.value}]`)}catch{n.issues.push({code:`invalid_format`,format:`ipv6`,input:n.value,inst:e,continue:!t.abort})}}}),Ea=P(`$ZodCIDRv4`,(e,t)=>{t.pattern??=Ei,z.init(e,t)}),Da=P(`$ZodCIDRv6`,(e,t)=>{t.pattern??=Di,z.init(e,t),e._zod.check=n=>{let r=n.value.split(`/`);try{if(r.length!==2)throw Error();let[e,t]=r;if(!t)throw Error();let n=Number(t);if(`${n}`!==t||n<0||n>128)throw Error();new URL(`http://[${e}]`)}catch{n.issues.push({code:`invalid_format`,format:`cidrv6`,input:n.value,inst:e,continue:!t.abort})}}});function Oa(e){if(e===``)return!0;if(e.length%4!=0)return!1;try{return atob(e),!0}catch{return!1}}let ka=P(`$ZodBase64`,(e,t)=>{t.pattern??=Oi,z.init(e,t),e._zod.onattach.push(e=>{e._zod.bag.contentEncoding=`base64`}),e._zod.check=n=>{Oa(n.value)||n.issues.push({code:`invalid_format`,format:`base64`,input:n.value,inst:e,continue:!t.abort})}});function Aa(e){if(!ki.test(e))return!1;let t=e.replace(/[-_]/g,e=>e===`-`?`+`:`/`);return Oa(t.padEnd(Math.ceil(t.length/4)*4,`=`))}let ja=P(`$ZodBase64URL`,(e,t)=>{t.pattern??=ki,z.init(e,t),e._zod.onattach.push(e=>{e._zod.bag.contentEncoding=`base64url`}),e._zod.check=n=>{Aa(n.value)||n.issues.push({code:`invalid_format`,format:`base64url`,input:n.value,inst:e,continue:!t.abort})}}),Ma=P(`$ZodE164`,(e,t)=>{t.pattern??=ji,z.init(e,t)});function Na(e,t=null){try{let n=e.split(`.`);if(n.length!==3)return!1;let[r]=n;if(!r)return!1;let i=JSON.parse(atob(r));return!(`typ`in i&&i?.typ!==`JWT`||!i.alg||t&&(!(`alg`in i)||i.alg!==t))}catch{return!1}}let Pa=P(`$ZodJWT`,(e,t)=>{z.init(e,t),e._zod.check=n=>{Na(n.value,t.alg)||n.issues.push({code:`invalid_format`,format:`jwt`,input:n.value,inst:e,continue:!t.abort})}}),Fa=P(`$ZodNumber`,(e,t)=>{R.init(e,t),e._zod.pattern=e._zod.bag.pattern??zi,e._zod.parse=(n,r)=>{if(t.coerce)try{n.value=Number(n.value)}catch{}let i=n.value;if(typeof i==`number`&&!Number.isNaN(i)&&Number.isFinite(i))return n;let a=typeof i==`number`?Number.isNaN(i)?`NaN`:Number.isFinite(i)?void 0:`Infinity`:void 0;return n.issues.push({expected:`number`,code:`invalid_type`,input:i,inst:e,...a?{received:a}:{}}),n}}),Ia=P(`$ZodNumber`,(e,t)=>{Ji.init(e,t),Fa.init(e,t)}),La=P(`$ZodBoolean`,(e,t)=>{R.init(e,t),e._zod.pattern=Bi,e._zod.parse=(n,r)=>{if(t.coerce)try{n.value=!!n.value}catch{}let i=n.value;return typeof i==`boolean`||n.issues.push({expected:`boolean`,code:`invalid_type`,input:i,inst:e}),n}}),Ra=P(`$ZodNull`,(e,t)=>{R.init(e,t),e._zod.pattern=Vi,e._zod.values=new Set([null]),e._zod.parse=(t,n)=>{let r=t.value;return r===null||t.issues.push({expected:`null`,code:`invalid_type`,input:r,inst:e}),t}}),za=P(`$ZodUnknown`,(e,t)=>{R.init(e,t),e._zod.parse=e=>e}),Ba=P(`$ZodNever`,(e,t)=>{R.init(e,t),e._zod.parse=(t,n)=>(t.issues.push({expected:`never`,code:`invalid_type`,input:t.value,inst:e}),t)});function Va(e,t,n){e.issues.length&&t.issues.push(...Ur(n,e.issues)),t.value[n]=e.value}let Ha=P(`$ZodArray`,(e,t)=>{R.init(e,t),e._zod.parse=(n,r)=>{let i=n.value;if(!Array.isArray(i))return n.issues.push({expected:`array`,code:`invalid_type`,input:i,inst:e}),n;n.value=Array(i.length);let a=[];for(let e=0;e<i.length;e++){let o=i[e],s=t.element._zod.run({value:o,issues:[]},r);s instanceof Promise?a.push(s.then(t=>Va(t,n,e))):Va(s,n,e)}return a.length?Promise.all(a).then(()=>n):n}});function Ua(e,t,n,r){e.issues.length&&t.issues.push(...Ur(n,e.issues)),e.value===void 0?n in r&&(t.value[n]=void 0):t.value[n]=e.value}function Wa(e){let t=Object.keys(e.shape);for(let n of t)if(!e.shape?.[n]?._zod?.traits?.has(`$ZodType`))throw Error(`Invalid element at key "${n}": expected a Zod schema`);let n=Nr(e.shape);return{...e,keys:t,keySet:new Set(t),numKeys:t.length,optionalKeys:new Set(n)}}function Ga(e,t,n,r,i,a){let o=[],s=i.keySet,c=i.catchall._zod,l=c.def.type;for(let i of Object.keys(t)){if(s.has(i))continue;if(l===`never`){o.push(i);continue}let a=c.run({value:t[i],issues:[]},r);a instanceof Promise?e.push(a.then(e=>Ua(e,n,i,t))):Ua(a,n,i,t)}return o.length&&n.issues.push({code:`unrecognized_keys`,keys:o,input:t,inst:a}),e.length?Promise.all(e).then(()=>n):n}let Ka=P(`$ZodObject`,(e,t)=>{if(R.init(e,t),!Object.getOwnPropertyDescriptor(t,`shape`)?.get){let e=t.shape;Object.defineProperty(t,"shape",{get:()=>{let n={...e};return Object.defineProperty(t,"shape",{value:n}),n}})}let n=_r(()=>Wa(t));F(e._zod,`propValues`,()=>{let e=t.shape,n={};for(let t in e){let r=e[t]._zod;if(r.values){n[t]??(n[t]=new Set);for(let e of r.values)n[t].add(e)}}return n});let r=Er,i=t.catchall,a;e._zod.parse=(t,o)=>{a??=n.value;let s=t.value;if(!r(s))return t.issues.push({expected:`object`,code:`invalid_type`,input:s,inst:e}),t;t.value={};let c=[],l=a.shape;for(let e of a.keys){let n=l[e]._zod.run({value:s[e],issues:[]},o);n instanceof Promise?c.push(n.then(n=>Ua(n,t,e,s))):Ua(n,t,e,s)}return i?Ga(c,s,t,o,n.value,e):c.length?Promise.all(c).then(()=>t):t}}),qa=P(`$ZodObjectJIT`,(e,t)=>{Ka.init(e,t);let n=e._zod.parse,r=_r(()=>Wa(t)),i=e=>{let t=new oa([`shape`,`payload`,`ctx`]),n=r.value,i=e=>{let t=wr(e);return`shape[${t}]._zod.run({ value: input[${t}], issues: [] }, ctx)`};t.write(`const input = payload.value;`);let a=Object.create(null),o=0;for(let e of n.keys)a[e]=`key_${o++}`;t.write(`const newResult = {};`);for(let e of n.keys){let n=a[e],r=wr(e);t.write(`const ${n} = ${i(e)};`),t.write(`
        if (${n}.issues.length) {
          payload.issues = payload.issues.concat(${n}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${r}, ...iss.path] : [${r}]
          })));
        }
        
        
        if (${n}.value === undefined) {
          if (${r} in input) {
            newResult[${r}] = undefined;
          }
        } else {
          newResult[${r}] = ${n}.value;
        }
        
      `)}t.write(`payload.value = newResult;`),t.write(`return payload;`);let s=t.compile();return(t,n)=>s(e,t,n)},a,o=Er,s=!pr.jitless,c=s&&Dr.value,l=t.catchall,u;e._zod.parse=(d,f)=>{u??=r.value;let p=d.value;return o(p)?s&&c&&f?.async===!1&&f.jitless!==!0?(a||=i(t.shape),d=a(d,f),l?Ga([],p,d,f,u,e):d):n(d,f):(d.issues.push({expected:`object`,code:`invalid_type`,input:p,inst:e}),d)}});function Ja(e,t,n,r){for(let n of e)if(n.issues.length===0)return t.value=n.value,t;let i=e.filter(e=>!Hr(e));return i.length===1?(t.value=i[0].value,i[0]):(t.issues.push({code:`invalid_union`,input:t.value,inst:n,errors:e.map(e=>e.issues.map(e=>Gr(e,r,mr())))}),t)}let Ya=P(`$ZodUnion`,(e,t)=>{R.init(e,t),F(e._zod,`optin`,()=>t.options.some(e=>e._zod.optin===`optional`)?`optional`:void 0),F(e._zod,`optout`,()=>t.options.some(e=>e._zod.optout===`optional`)?`optional`:void 0),F(e._zod,`values`,()=>{if(t.options.every(e=>e._zod.values))return new Set(t.options.flatMap(e=>Array.from(e._zod.values)))}),F(e._zod,`pattern`,()=>{if(t.options.every(e=>e._zod.pattern)){let e=t.options.map(e=>e._zod.pattern);return RegExp(`^(${e.map(e=>yr(e.source)).join(`|`)})$`)}});let n=t.options.length===1,r=t.options[0]._zod.run;e._zod.parse=(i,a)=>{if(n)return r(i,a);let o=!1,s=[];for(let e of t.options){let t=e._zod.run({value:i.value,issues:[]},a);if(t instanceof Promise)s.push(t),o=!0;else{if(t.issues.length===0)return t;s.push(t)}}return o?Promise.all(s).then(t=>Ja(t,i,e,a)):Ja(s,i,e,a)}}),Xa=P(`$ZodDiscriminatedUnion`,(e,t)=>{Ya.init(e,t);let n=e._zod.parse;F(e._zod,`propValues`,()=>{let e={};for(let n of t.options){let r=n._zod.propValues;if(!r||Object.keys(r).length===0)throw Error(`Invalid discriminated union option at index "${t.options.indexOf(n)}"`);for(let[t,n]of Object.entries(r)){e[t]||(e[t]=new Set);for(let r of n)e[t].add(r)}}return e});let r=_r(()=>{let e=t.options,n=new Map;for(let r of e){let e=r._zod.propValues?.[t.discriminator];if(!e||e.size===0)throw Error(`Invalid discriminated union option at index "${t.options.indexOf(r)}"`);for(let t of e){if(n.has(t))throw Error(`Duplicate discriminator value "${String(t)}"`);n.set(t,r)}}return n});e._zod.parse=(i,a)=>{let o=i.value;if(!Er(o))return i.issues.push({code:`invalid_type`,expected:`object`,input:o,inst:e}),i;let s=r.value.get(o?.[t.discriminator]);return s?s._zod.run(i,a):t.unionFallback?n(i,a):(i.issues.push({code:`invalid_union`,errors:[],note:`No matching discriminator`,discriminator:t.discriminator,input:o,path:[t.discriminator],inst:e}),i)}}),Za=P(`$ZodIntersection`,(e,t)=>{R.init(e,t),e._zod.parse=(e,n)=>{let r=e.value,i=t.left._zod.run({value:r,issues:[]},n),a=t.right._zod.run({value:r,issues:[]},n);return i instanceof Promise||a instanceof Promise?Promise.all([i,a]).then(([t,n])=>$a(e,t,n)):$a(e,i,a)}});function Qa(e,t){if(e===t||e instanceof Date&&t instanceof Date&&+e==+t)return{valid:!0,data:e};if(Or(e)&&Or(t)){let n=Object.keys(t),r=Object.keys(e).filter(e=>n.indexOf(e)!==-1),i={...e,...t};for(let n of r){let r=Qa(e[n],t[n]);if(!r.valid)return{valid:!1,mergeErrorPath:[n,...r.mergeErrorPath]};i[n]=r.data}return{valid:!0,data:i}}if(Array.isArray(e)&&Array.isArray(t)){if(e.length!==t.length)return{valid:!1,mergeErrorPath:[]};let n=[];for(let r=0;r<e.length;r++){let i=e[r],a=t[r],o=Qa(i,a);if(!o.valid)return{valid:!1,mergeErrorPath:[r,...o.mergeErrorPath]};n.push(o.data)}return{valid:!0,data:n}}return{valid:!1,mergeErrorPath:[]}}function $a(e,t,n){if(t.issues.length&&e.issues.push(...t.issues),n.issues.length&&e.issues.push(...n.issues),Hr(e))return e;let r=Qa(t.value,n.value);if(!r.valid)throw Error(`Unmergable intersection. Error path: ${JSON.stringify(r.mergeErrorPath)}`);return e.value=r.data,e}let eo=P(`$ZodRecord`,(e,t)=>{R.init(e,t),e._zod.parse=(n,r)=>{let i=n.value;if(!Or(i))return n.issues.push({expected:`record`,code:`invalid_type`,input:i,inst:e}),n;let a=[];if(t.keyType._zod.values){let o=t.keyType._zod.values;n.value={};for(let e of o)if(typeof e==`string`||typeof e==`number`||typeof e==`symbol`){let o=t.valueType._zod.run({value:i[e],issues:[]},r);o instanceof Promise?a.push(o.then(t=>{t.issues.length&&n.issues.push(...Ur(e,t.issues)),n.value[e]=t.value})):(o.issues.length&&n.issues.push(...Ur(e,o.issues)),n.value[e]=o.value)}let s;for(let e in i)o.has(e)||(s??=[],s.push(e));s&&s.length>0&&n.issues.push({code:`unrecognized_keys`,input:i,inst:e,keys:s})}else{n.value={};for(let o of Reflect.ownKeys(i)){if(o===`__proto__`)continue;let s=t.keyType._zod.run({value:o,issues:[]},r);if(s instanceof Promise)throw Error(`Async schemas not supported in object keys currently`);if(s.issues.length){n.issues.push({code:`invalid_key`,origin:`record`,issues:s.issues.map(e=>Gr(e,r,mr())),input:o,path:[o],inst:e}),n.value[s.value]=s.value;continue}let c=t.valueType._zod.run({value:i[o],issues:[]},r);c instanceof Promise?a.push(c.then(e=>{e.issues.length&&n.issues.push(...Ur(o,e.issues)),n.value[s.value]=e.value})):(c.issues.length&&n.issues.push(...Ur(o,c.issues)),n.value[s.value]=c.value)}}return a.length?Promise.all(a).then(()=>n):n}}),to=P(`$ZodEnum`,(e,t)=>{R.init(e,t);let n=hr(t.entries),r=new Set(n);e._zod.values=r,e._zod.pattern=RegExp(`^(${n.filter(e=>Ar.has(typeof e)).map(e=>typeof e==`string`?jr(e):e.toString()).join(`|`)})$`),e._zod.parse=(t,i)=>{let a=t.value;return r.has(a)||t.issues.push({code:`invalid_value`,values:n,input:a,inst:e}),t}}),no=P(`$ZodLiteral`,(e,t)=>{if(R.init(e,t),t.values.length===0)throw Error(`Cannot create literal schema with no valid values`);e._zod.values=new Set(t.values),e._zod.pattern=RegExp(`^(${t.values.map(e=>typeof e==`string`?jr(e):e?jr(e.toString()):String(e)).join(`|`)})$`),e._zod.parse=(n,r)=>{let i=n.value;return e._zod.values.has(i)||n.issues.push({code:`invalid_value`,values:t.values,input:i,inst:e}),n}}),ro=P(`$ZodTransform`,(e,t)=>{R.init(e,t),e._zod.parse=(n,r)=>{if(r.direction===`backward`)throw new fr(e.constructor.name);let i=t.transform(n.value,n);if(r.async)return(i instanceof Promise?i:Promise.resolve(i)).then(e=>(n.value=e,n));if(i instanceof Promise)throw new dr;return n.value=i,n}});function io(e,t){return e.issues.length&&t===void 0?{issues:[],value:void 0}:e}let ao=P(`$ZodOptional`,(e,t)=>{R.init(e,t),e._zod.optin=`optional`,e._zod.optout=`optional`,F(e._zod,`values`,()=>t.innerType._zod.values?new Set([...t.innerType._zod.values,void 0]):void 0),F(e._zod,`pattern`,()=>{let e=t.innerType._zod.pattern;return e?RegExp(`^(${yr(e.source)})?$`):void 0}),e._zod.parse=(e,n)=>{if(t.innerType._zod.optin===`optional`){let r=t.innerType._zod.run(e,n);return r instanceof Promise?r.then(t=>io(t,e.value)):io(r,e.value)}return e.value===void 0?e:t.innerType._zod.run(e,n)}}),oo=P(`$ZodNullable`,(e,t)=>{R.init(e,t),F(e._zod,`optin`,()=>t.innerType._zod.optin),F(e._zod,`optout`,()=>t.innerType._zod.optout),F(e._zod,`pattern`,()=>{let e=t.innerType._zod.pattern;return e?RegExp(`^(${yr(e.source)}|null)$`):void 0}),F(e._zod,`values`,()=>t.innerType._zod.values?new Set([...t.innerType._zod.values,null]):void 0),e._zod.parse=(e,n)=>e.value===null?e:t.innerType._zod.run(e,n)}),so=P(`$ZodDefault`,(e,t)=>{R.init(e,t),e._zod.optin=`optional`,F(e._zod,`values`,()=>t.innerType._zod.values),e._zod.parse=(e,n)=>{if(n.direction===`backward`)return t.innerType._zod.run(e,n);if(e.value===void 0)return e.value=t.defaultValue,e;let r=t.innerType._zod.run(e,n);return r instanceof Promise?r.then(e=>co(e,t)):co(r,t)}});function co(e,t){return e.value===void 0&&(e.value=t.defaultValue),e}let lo=P(`$ZodPrefault`,(e,t)=>{R.init(e,t),e._zod.optin=`optional`,F(e._zod,`values`,()=>t.innerType._zod.values),e._zod.parse=(e,n)=>(n.direction===`backward`||e.value===void 0&&(e.value=t.defaultValue),t.innerType._zod.run(e,n))}),uo=P(`$ZodNonOptional`,(e,t)=>{R.init(e,t),F(e._zod,`values`,()=>{let e=t.innerType._zod.values;return e?new Set([...e].filter(e=>e!==void 0)):void 0}),e._zod.parse=(n,r)=>{let i=t.innerType._zod.run(n,r);return i instanceof Promise?i.then(t=>fo(t,e)):fo(i,e)}});function fo(e,t){return!e.issues.length&&e.value===void 0&&e.issues.push({code:`invalid_type`,expected:`nonoptional`,input:e.value,inst:t}),e}let po=P(`$ZodCatch`,(e,t)=>{R.init(e,t),F(e._zod,`optin`,()=>t.innerType._zod.optin),F(e._zod,`optout`,()=>t.innerType._zod.optout),F(e._zod,`values`,()=>t.innerType._zod.values),e._zod.parse=(e,n)=>{if(n.direction===`backward`)return t.innerType._zod.run(e,n);let r=t.innerType._zod.run(e,n);return r instanceof Promise?r.then(r=>(e.value=r.value,r.issues.length&&(e.value=t.catchValue({...e,error:{issues:r.issues.map(e=>Gr(e,n,mr()))},input:e.value}),e.issues=[]),e)):(e.value=r.value,r.issues.length&&(e.value=t.catchValue({...e,error:{issues:r.issues.map(e=>Gr(e,n,mr()))},input:e.value}),e.issues=[]),e)}}),mo=P(`$ZodPipe`,(e,t)=>{R.init(e,t),F(e._zod,`values`,()=>t.in._zod.values),F(e._zod,`optin`,()=>t.in._zod.optin),F(e._zod,`optout`,()=>t.out._zod.optout),F(e._zod,`propValues`,()=>t.in._zod.propValues),e._zod.parse=(e,n)=>{if(n.direction===`backward`){let r=t.out._zod.run(e,n);return r instanceof Promise?r.then(e=>ho(e,t.in,n)):ho(r,t.in,n)}let r=t.in._zod.run(e,n);return r instanceof Promise?r.then(e=>ho(e,t.out,n)):ho(r,t.out,n)}});function ho(e,t,n){return e.issues.length?(e.aborted=!0,e):t._zod.run({value:e.value,issues:e.issues},n)}let go=P(`$ZodReadonly`,(e,t)=>{R.init(e,t),F(e._zod,`propValues`,()=>t.innerType._zod.propValues),F(e._zod,`values`,()=>t.innerType._zod.values),F(e._zod,`optin`,()=>t.innerType._zod.optin),F(e._zod,`optout`,()=>t.innerType._zod.optout),e._zod.parse=(e,n)=>{if(n.direction===`backward`)return t.innerType._zod.run(e,n);let r=t.innerType._zod.run(e,n);return r instanceof Promise?r.then(_o):_o(r)}});function _o(e){return e.value=Object.freeze(e.value),e}let vo=P(`$ZodLazy`,(e,t)=>{R.init(e,t),F(e._zod,`innerType`,()=>t.getter()),F(e._zod,`pattern`,()=>e._zod.innerType._zod.pattern),F(e._zod,`propValues`,()=>e._zod.innerType._zod.propValues),F(e._zod,`optin`,()=>e._zod.innerType._zod.optin??void 0),F(e._zod,`optout`,()=>e._zod.innerType._zod.optout??void 0),e._zod.parse=(t,n)=>e._zod.innerType._zod.run(t,n)}),yo=P(`$ZodCustom`,(e,t)=>{L.init(e,t),R.init(e,t),e._zod.parse=(e,t)=>e,e._zod.check=n=>{let r=n.value,i=t.fn(r);if(i instanceof Promise)return i.then(t=>bo(t,n,r,e));bo(i,n,r,e)}});function bo(e,t,n,r){if(!e){let e={code:`custom`,input:n,inst:r,path:[...r._zod.def.path??[]],continue:!r._zod.def.abort};r._zod.def.params&&(e.params=r._zod.def.params),t.issues.push(qr(e))}}var xo=class{constructor(){this._map=new WeakMap,this._idmap=new Map}add(e,...t){let n=t[0];if(this._map.set(e,n),n&&typeof n==`object`&&`id`in n){if(this._idmap.has(n.id))throw Error(`ID ${n.id} already exists in the registry`);this._idmap.set(n.id,e)}return this}clear(){return this._map=new WeakMap,this._idmap=new Map,this}remove(e){let t=this._map.get(e);return t&&typeof t==`object`&&`id`in t&&this._idmap.delete(t.id),this._map.delete(e),this}get(e){let t=e._zod.parent;if(t){let n={...this.get(t)??{}};delete n.id;let r={...n,...this._map.get(e)};return Object.keys(r).length?r:void 0}return this._map.get(e)}has(e){return this._map.has(e)}};function So(){return new xo}let Co=So();function wo(e,t){return new e({type:`string`,...I(t)})}function To(e,t){return new e({type:`string`,format:`email`,check:`string_format`,abort:!1,...I(t)})}function Eo(e,t){return new e({type:`string`,format:`guid`,check:`string_format`,abort:!1,...I(t)})}function Do(e,t){return new e({type:`string`,format:`uuid`,check:`string_format`,abort:!1,...I(t)})}function Oo(e,t){return new e({type:`string`,format:`uuid`,check:`string_format`,abort:!1,version:`v4`,...I(t)})}function ko(e,t){return new e({type:`string`,format:`uuid`,check:`string_format`,abort:!1,version:`v6`,...I(t)})}function Ao(e,t){return new e({type:`string`,format:`uuid`,check:`string_format`,abort:!1,version:`v7`,...I(t)})}function jo(e,t){return new e({type:`string`,format:`url`,check:`string_format`,abort:!1,...I(t)})}function Mo(e,t){return new e({type:`string`,format:`emoji`,check:`string_format`,abort:!1,...I(t)})}function No(e,t){return new e({type:`string`,format:`nanoid`,check:`string_format`,abort:!1,...I(t)})}function Po(e,t){return new e({type:`string`,format:`cuid`,check:`string_format`,abort:!1,...I(t)})}function Fo(e,t){return new e({type:`string`,format:`cuid2`,check:`string_format`,abort:!1,...I(t)})}function Io(e,t){return new e({type:`string`,format:`ulid`,check:`string_format`,abort:!1,...I(t)})}function Lo(e,t){return new e({type:`string`,format:`xid`,check:`string_format`,abort:!1,...I(t)})}function Ro(e,t){return new e({type:`string`,format:`ksuid`,check:`string_format`,abort:!1,...I(t)})}function zo(e,t){return new e({type:`string`,format:`ipv4`,check:`string_format`,abort:!1,...I(t)})}function Bo(e,t){return new e({type:`string`,format:`ipv6`,check:`string_format`,abort:!1,...I(t)})}function Vo(e,t){return new e({type:`string`,format:`cidrv4`,check:`string_format`,abort:!1,...I(t)})}function Ho(e,t){return new e({type:`string`,format:`cidrv6`,check:`string_format`,abort:!1,...I(t)})}function Uo(e,t){return new e({type:`string`,format:`base64`,check:`string_format`,abort:!1,...I(t)})}function Wo(e,t){return new e({type:`string`,format:`base64url`,check:`string_format`,abort:!1,...I(t)})}function Go(e,t){return new e({type:`string`,format:`e164`,check:`string_format`,abort:!1,...I(t)})}function Ko(e,t){return new e({type:`string`,format:`jwt`,check:`string_format`,abort:!1,...I(t)})}function qo(e,t){return new e({type:`string`,format:`datetime`,check:`string_format`,offset:!1,local:!1,precision:null,...I(t)})}function Jo(e,t){return new e({type:`string`,format:`date`,check:`string_format`,...I(t)})}function Yo(e,t){return new e({type:`string`,format:`time`,check:`string_format`,precision:null,...I(t)})}function Xo(e,t){return new e({type:`string`,format:`duration`,check:`string_format`,...I(t)})}function Zo(e,t){return new e({type:`number`,checks:[],...I(t)})}function Qo(e,t){return new e({type:`number`,check:`number_format`,abort:!1,format:`safeint`,...I(t)})}function $o(e,t){return new e({type:`boolean`,...I(t)})}function es(e,t){return new e({type:`null`,...I(t)})}function ts(e){return new e({type:`unknown`})}function ns(e,t){return new e({type:`never`,...I(t)})}function rs(e,t){return new Gi({check:`less_than`,...I(t),value:e,inclusive:!1})}function is(e,t){return new Gi({check:`less_than`,...I(t),value:e,inclusive:!0})}function as(e,t){return new Ki({check:`greater_than`,...I(t),value:e,inclusive:!1})}function os(e,t){return new Ki({check:`greater_than`,...I(t),value:e,inclusive:!0})}function ss(e,t){return new qi({check:`multiple_of`,...I(t),value:e})}function cs(e,t){return new Yi({check:`max_length`,...I(t),maximum:e})}function ls(e,t){return new Xi({check:`min_length`,...I(t),minimum:e})}function us(e,t){return new Zi({check:`length_equals`,...I(t),length:e})}function ds(e,t){return new $i({check:`string_format`,format:`regex`,...I(t),pattern:e})}function fs(e){return new ea({check:`string_format`,format:`lowercase`,...I(e)})}function ps(e){return new ta({check:`string_format`,format:`uppercase`,...I(e)})}function ms(e,t){return new na({check:`string_format`,format:`includes`,...I(t),includes:e})}function hs(e,t){return new ra({check:`string_format`,format:`starts_with`,...I(t),prefix:e})}function gs(e,t){return new ia({check:`string_format`,format:`ends_with`,...I(t),suffix:e})}function _s(e){return new aa({check:`overwrite`,tx:e})}function vs(e){return _s(t=>t.normalize(e))}function ys(){return _s(e=>e.trim())}function bs(){return _s(e=>e.toLowerCase())}function xs(){return _s(e=>e.toUpperCase())}function Ss(e,t,n){return new e({type:`array`,element:t,...I(n)})}function Cs(e,t,n){return new e({type:`custom`,check:`custom`,fn:t,...I(n)})}function ws(e){let t=Ts(n=>(n.addIssue=e=>{if(typeof e==`string`)n.issues.push(qr(e,n.value,t._zod.def));else{let r=e;r.fatal&&(r.continue=!1),r.code??=`custom`,r.input??=n.value,r.inst??=t,r.continue??=!t._zod.def.abort,n.issues.push(qr(r))}},e(n.value,n)));return t}function Ts(e,t){let n=new L({check:`custom`,...I(t)});return n._zod.check=e,n}let Es=P(`ZodISODateTime`,(e,t)=>{ba.init(e,t),U.init(e,t)});function Ds(e){return qo(Es,e)}let Os=P(`ZodISODate`,(e,t)=>{xa.init(e,t),U.init(e,t)});function ks(e){return Jo(Os,e)}let As=P(`ZodISOTime`,(e,t)=>{Sa.init(e,t),U.init(e,t)});function js(e){return Yo(As,e)}let Ms=P(`ZodISODuration`,(e,t)=>{Ca.init(e,t),U.init(e,t)});function Ns(e){return Xo(Ms,e)}let Ps=(e,t)=>{Yr.init(e,t),e.name=`ZodError`,Object.defineProperties(e,{format:{value:t=>Qr(e,t)},flatten:{value:t=>Zr(e,t)},addIssue:{value:t=>{e.issues.push(t),e.message=JSON.stringify(e.issues,gr,2)}},addIssues:{value:t=>{e.issues.push(...t),e.message=JSON.stringify(e.issues,gr,2)}},isEmpty:{get(){return e.issues.length===0}}})};P(`ZodError`,Ps);let B=P(`ZodError`,Ps,{Parent:Error}),Fs=$r(B),Is=ei(B),Ls=ti(B),Rs=ri(B),zs=ai(B),Bs=oi(B),Vs=si(B),Hs=ci(B),Us=li(B),Ws=ui(B),Gs=di(B),Ks=fi(B),V=P(`ZodType`,(e,t)=>(R.init(e,t),e.def=t,e.type=t.type,Object.defineProperty(e,"_def",{value:t}),e.check=(...n)=>e.clone(Cr(t,{checks:[...t.checks??[],...n.map(e=>typeof e==`function`?{_zod:{check:e,def:{check:`custom`},onattach:[]}}:e)]})),e.clone=(t,n)=>Mr(e,t,n),e.brand=()=>e,e.register=((t,n)=>(t.add(e,n),e)),e.parse=(t,n)=>Fs(e,t,n,{callee:e.parse}),e.safeParse=(t,n)=>Ls(e,t,n),e.parseAsync=async(t,n)=>Is(e,t,n,{callee:e.parseAsync}),e.safeParseAsync=async(t,n)=>Rs(e,t,n),e.spa=e.safeParseAsync,e.encode=(t,n)=>zs(e,t,n),e.decode=(t,n)=>Bs(e,t,n),e.encodeAsync=async(t,n)=>Vs(e,t,n),e.decodeAsync=async(t,n)=>Hs(e,t,n),e.safeEncode=(t,n)=>Us(e,t,n),e.safeDecode=(t,n)=>Ws(e,t,n),e.safeEncodeAsync=async(t,n)=>Gs(e,t,n),e.safeDecodeAsync=async(t,n)=>Ks(e,t,n),e.refine=(t,n)=>e.check(il(t,n)),e.superRefine=t=>e.check(al(t)),e.overwrite=t=>e.check(_s(t)),e.optional=()=>Bc(e),e.nullable=()=>Hc(e),e.nullish=()=>Bc(Hc(e)),e.nonoptional=t=>Jc(e,t),e.array=()=>G(e),e.or=t=>Oc([e,t]),e.and=t=>Mc(e,t),e.transform=t=>Qc(e,Rc(t)),e.default=t=>Wc(e,t),e.prefault=t=>Kc(e,t),e.catch=t=>Xc(e,t),e.pipe=t=>Qc(e,t),e.readonly=()=>el(e),e.describe=t=>{let n=e.clone();return Co.add(n,{description:t}),n},Object.defineProperty(e,"description",{get(){return Co.get(e)?.description},configurable:!0}),e.meta=(...t)=>{if(t.length===0)return Co.get(e);let n=e.clone();return Co.add(n,t[0]),n},e.isOptional=()=>e.safeParse(void 0).success,e.isNullable=()=>e.safeParse(null).success,e)),qs=P(`_ZodString`,(e,t)=>{ca.init(e,t),V.init(e,t);let n=e._zod.bag;e.format=n.format??null,e.minLength=n.minimum??null,e.maxLength=n.maximum??null,e.regex=(...t)=>e.check(ds(...t)),e.includes=(...t)=>e.check(ms(...t)),e.startsWith=(...t)=>e.check(hs(...t)),e.endsWith=(...t)=>e.check(gs(...t)),e.min=(...t)=>e.check(ls(...t)),e.max=(...t)=>e.check(cs(...t)),e.length=(...t)=>e.check(us(...t)),e.nonempty=(...t)=>e.check(ls(1,...t)),e.lowercase=t=>e.check(fs(t)),e.uppercase=t=>e.check(ps(t)),e.trim=()=>e.check(ys()),e.normalize=(...t)=>e.check(vs(...t)),e.toLowerCase=()=>e.check(bs()),e.toUpperCase=()=>e.check(xs())}),Js=P(`ZodString`,(e,t)=>{ca.init(e,t),qs.init(e,t),e.email=t=>e.check(To(Ys,t)),e.url=t=>e.check(jo(Qs,t)),e.jwt=t=>e.check(Ko(pc,t)),e.emoji=t=>e.check(Mo($s,t)),e.guid=t=>e.check(Eo(Xs,t)),e.uuid=t=>e.check(Do(Zs,t)),e.uuidv4=t=>e.check(Oo(Zs,t)),e.uuidv6=t=>e.check(ko(Zs,t)),e.uuidv7=t=>e.check(Ao(Zs,t)),e.nanoid=t=>e.check(No(ec,t)),e.guid=t=>e.check(Eo(Xs,t)),e.cuid=t=>e.check(Po(tc,t)),e.cuid2=t=>e.check(Fo(nc,t)),e.ulid=t=>e.check(Io(rc,t)),e.base64=t=>e.check(Uo(uc,t)),e.base64url=t=>e.check(Wo(dc,t)),e.xid=t=>e.check(Lo(ic,t)),e.ksuid=t=>e.check(Ro(ac,t)),e.ipv4=t=>e.check(zo(oc,t)),e.ipv6=t=>e.check(Bo(sc,t)),e.cidrv4=t=>e.check(Vo(cc,t)),e.cidrv6=t=>e.check(Ho(lc,t)),e.e164=t=>e.check(Go(fc,t)),e.datetime=t=>e.check(Ds(t)),e.date=t=>e.check(ks(t)),e.time=t=>e.check(js(t)),e.duration=t=>e.check(Ns(t))});function H(e){return wo(Js,e)}let U=P(`ZodStringFormat`,(e,t)=>{z.init(e,t),qs.init(e,t)}),Ys=P(`ZodEmail`,(e,t)=>{da.init(e,t),U.init(e,t)}),Xs=P(`ZodGUID`,(e,t)=>{la.init(e,t),U.init(e,t)}),Zs=P(`ZodUUID`,(e,t)=>{ua.init(e,t),U.init(e,t)}),Qs=P(`ZodURL`,(e,t)=>{fa.init(e,t),U.init(e,t)}),$s=P(`ZodEmoji`,(e,t)=>{pa.init(e,t),U.init(e,t)}),ec=P(`ZodNanoID`,(e,t)=>{ma.init(e,t),U.init(e,t)}),tc=P(`ZodCUID`,(e,t)=>{ha.init(e,t),U.init(e,t)}),nc=P(`ZodCUID2`,(e,t)=>{ga.init(e,t),U.init(e,t)}),rc=P(`ZodULID`,(e,t)=>{_a.init(e,t),U.init(e,t)}),ic=P(`ZodXID`,(e,t)=>{va.init(e,t),U.init(e,t)}),ac=P(`ZodKSUID`,(e,t)=>{ya.init(e,t),U.init(e,t)}),oc=P(`ZodIPv4`,(e,t)=>{wa.init(e,t),U.init(e,t)}),sc=P(`ZodIPv6`,(e,t)=>{Ta.init(e,t),U.init(e,t)}),cc=P(`ZodCIDRv4`,(e,t)=>{Ea.init(e,t),U.init(e,t)}),lc=P(`ZodCIDRv6`,(e,t)=>{Da.init(e,t),U.init(e,t)}),uc=P(`ZodBase64`,(e,t)=>{ka.init(e,t),U.init(e,t)}),dc=P(`ZodBase64URL`,(e,t)=>{ja.init(e,t),U.init(e,t)}),fc=P(`ZodE164`,(e,t)=>{Ma.init(e,t),U.init(e,t)}),pc=P(`ZodJWT`,(e,t)=>{Pa.init(e,t),U.init(e,t)}),mc=P(`ZodNumber`,(e,t)=>{Fa.init(e,t),V.init(e,t),e.gt=(t,n)=>e.check(as(t,n)),e.gte=(t,n)=>e.check(os(t,n)),e.min=(t,n)=>e.check(os(t,n)),e.lt=(t,n)=>e.check(rs(t,n)),e.lte=(t,n)=>e.check(is(t,n)),e.max=(t,n)=>e.check(is(t,n)),e.int=t=>e.check(gc(t)),e.safe=t=>e.check(gc(t)),e.positive=t=>e.check(as(0,t)),e.nonnegative=t=>e.check(os(0,t)),e.negative=t=>e.check(rs(0,t)),e.nonpositive=t=>e.check(is(0,t)),e.multipleOf=(t,n)=>e.check(ss(t,n)),e.step=(t,n)=>e.check(ss(t,n)),e.finite=()=>e;let n=e._zod.bag;e.minValue=Math.max(n.minimum??-1/0,n.exclusiveMinimum??-1/0)??null,e.maxValue=Math.min(n.maximum??1/0,n.exclusiveMaximum??1/0)??null,e.isInt=(n.format??``).includes(`int`)||Number.isSafeInteger(n.multipleOf??.5),e.isFinite=!0,e.format=n.format??null});function W(e){return Zo(mc,e)}let hc=P(`ZodNumberFormat`,(e,t)=>{Ia.init(e,t),mc.init(e,t)});function gc(e){return Qo(hc,e)}let _c=P(`ZodBoolean`,(e,t)=>{La.init(e,t),V.init(e,t)});function vc(e){return $o(_c,e)}let yc=P(`ZodNull`,(e,t)=>{Ra.init(e,t),V.init(e,t)});function bc(e){return es(yc,e)}let xc=P(`ZodUnknown`,(e,t)=>{za.init(e,t),V.init(e,t)});function Sc(){return ts(xc)}let Cc=P(`ZodNever`,(e,t)=>{Ba.init(e,t),V.init(e,t)});function wc(e){return ns(Cc,e)}let Tc=P(`ZodArray`,(e,t)=>{Ha.init(e,t),V.init(e,t),e.element=t.element,e.min=(t,n)=>e.check(ls(t,n)),e.nonempty=t=>e.check(ls(1,t)),e.max=(t,n)=>e.check(cs(t,n)),e.length=(t,n)=>e.check(us(t,n)),e.unwrap=()=>e.element});function G(e,t){return Ss(Tc,e,t)}let Ec=P(`ZodObject`,(e,t)=>{qa.init(e,t),V.init(e,t),F(e,`shape`,()=>t.shape),e.keyof=()=>q(Object.keys(e._zod.def.shape)),e.catchall=t=>e.clone({...e._zod.def,catchall:t}),e.passthrough=()=>e.clone({...e._zod.def,catchall:Sc()}),e.loose=()=>e.clone({...e._zod.def,catchall:Sc()}),e.strict=()=>e.clone({...e._zod.def,catchall:wc()}),e.strip=()=>e.clone({...e._zod.def,catchall:void 0}),e.extend=t=>Lr(e,t),e.safeExtend=t=>Rr(e,t),e.merge=t=>zr(e,t),e.pick=t=>Fr(e,t),e.omit=t=>Ir(e,t),e.partial=(...t)=>Br(zc,e,t[0]),e.required=(...t)=>Vr(qc,e,t[0])});function K(e,t){let n={type:`object`,shape:e??{},...I(t)};return new Ec(n)}let Dc=P(`ZodUnion`,(e,t)=>{Ya.init(e,t),V.init(e,t),e.options=t.options});function Oc(e,t){return new Dc({type:`union`,options:e,...I(t)})}let kc=P(`ZodDiscriminatedUnion`,(e,t)=>{Dc.init(e,t),Xa.init(e,t)});function Ac(e,t,n){return new kc({type:`union`,options:t,discriminator:e,...I(n)})}let jc=P(`ZodIntersection`,(e,t)=>{Za.init(e,t),V.init(e,t)});function Mc(e,t){return new jc({type:`intersection`,left:e,right:t})}let Nc=P(`ZodRecord`,(e,t)=>{eo.init(e,t),V.init(e,t),e.keyType=t.keyType,e.valueType=t.valueType});function Pc(e,t,n){return new Nc({type:`record`,keyType:e,valueType:t,...I(n)})}let Fc=P(`ZodEnum`,(e,t)=>{to.init(e,t),V.init(e,t),e.enum=t.entries,e.options=Object.values(t.entries);let n=new Set(Object.keys(t.entries));e.extract=(e,r)=>{let i={};for(let r of e)if(n.has(r))i[r]=t.entries[r];else throw Error(`Key ${r} not found in enum`);return new Fc({...t,checks:[],...I(r),entries:i})},e.exclude=(e,r)=>{let i={...t.entries};for(let t of e)if(n.has(t))delete i[t];else throw Error(`Key ${t} not found in enum`);return new Fc({...t,checks:[],...I(r),entries:i})}});function q(e,t){let n=Array.isArray(e)?Object.fromEntries(e.map(e=>[e,e])):e;return new Fc({type:`enum`,entries:n,...I(t)})}let Ic=P(`ZodLiteral`,(e,t)=>{no.init(e,t),V.init(e,t),e.values=new Set(t.values),Object.defineProperty(e,"value",{get(){if(t.values.length>1)throw Error("This schema contains multiple valid literal values. Use `.values` instead.");return t.values[0]}})});function J(e,t){return new Ic({type:`literal`,values:Array.isArray(e)?e:[e],...I(t)})}let Lc=P(`ZodTransform`,(e,t)=>{ro.init(e,t),V.init(e,t),e._zod.parse=(n,r)=>{if(r.direction===`backward`)throw new fr(e.constructor.name);n.addIssue=r=>{if(typeof r==`string`)n.issues.push(qr(r,n.value,t));else{let t=r;t.fatal&&(t.continue=!1),t.code??=`custom`,t.input??=n.value,t.inst??=e,n.issues.push(qr(t))}};let i=t.transform(n.value,n);return i instanceof Promise?i.then(e=>(n.value=e,n)):(n.value=i,n)}});function Rc(e){return new Lc({type:`transform`,transform:e})}let zc=P(`ZodOptional`,(e,t)=>{ao.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType});function Bc(e){return new zc({type:`optional`,innerType:e})}let Vc=P(`ZodNullable`,(e,t)=>{oo.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType});function Hc(e){return new Vc({type:`nullable`,innerType:e})}let Uc=P(`ZodDefault`,(e,t)=>{so.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType,e.removeDefault=e.unwrap});function Wc(e,t){return new Uc({type:`default`,innerType:e,get defaultValue(){return typeof t==`function`?t():kr(t)}})}let Gc=P(`ZodPrefault`,(e,t)=>{lo.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType});function Kc(e,t){return new Gc({type:`prefault`,innerType:e,get defaultValue(){return typeof t==`function`?t():kr(t)}})}let qc=P(`ZodNonOptional`,(e,t)=>{uo.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType});function Jc(e,t){return new qc({type:`nonoptional`,innerType:e,...I(t)})}let Yc=P(`ZodCatch`,(e,t)=>{po.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType,e.removeCatch=e.unwrap});function Xc(e,t){return new Yc({type:`catch`,innerType:e,catchValue:typeof t==`function`?t:()=>t})}let Zc=P(`ZodPipe`,(e,t)=>{mo.init(e,t),V.init(e,t),e.in=t.in,e.out=t.out});function Qc(e,t){return new Zc({type:`pipe`,in:e,out:t})}let $c=P(`ZodReadonly`,(e,t)=>{go.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.innerType});function el(e){return new $c({type:`readonly`,innerType:e})}let tl=P(`ZodLazy`,(e,t)=>{vo.init(e,t),V.init(e,t),e.unwrap=()=>e._zod.def.getter()});function nl(e){return new tl({type:`lazy`,getter:e})}let rl=P(`ZodCustom`,(e,t)=>{yo.init(e,t),V.init(e,t)});function il(e,t={}){return Cs(rl,e,t)}function al(e){return ws(e)}let ol=nl(()=>Oc([H(),W().finite(),vc(),bc(),G(ol),Pc(H(),ol)])),sl=Pc(H(),ol),cl=K({id:H().min(1).max(128),kind:H().min(1).max(128),config:sl}).strict(),ll=K({from:H().min(1).max(128),to:H().min(1).max(128),on:H().min(1).max(128),priority:W().int().nonnegative()}).strict(),ul=K({id:H().min(1).max(128),expression:sl}).strict(),dl=K({id:H().min(1).max(128),entry_node:H().min(1).max(128),nodes:G(cl).max(512),edges:G(ll).max(2048),guards:G(ul).max(256).optional()}).strict(),fl=K({schema_version:J(`ascension.workflow/v1`),workflow_id:H().min(1).max(128),version:H().min(1).max(64),mode:q([`strict`,`dynamic`]),game_profile:H().min(1).max(128),policy_ref:H().min(1).max(128),capabilities:K({required:G(H().min(1).max(128)).max(128),optional:G(H().min(1).max(128)).max(128)}).strict(),limits:K({max_steps:W().int().positive(),max_subworkflow_depth:W().int().nonnegative(),max_provider_calls:W().int().nonnegative(),max_parallel_analyses:W().int().positive(),max_output_tokens:W().int().positive()}).strict(),entry_graph:H().min(1).max(128),graphs:G(dl).min(1).max(128),annotations:sl.optional()}).strict(),pl=q([`created`,`validated`,`running`,`waiting_for_provider`,`waiting_for_game`,`pausing`,`paused`,`cancelling`,`reconciling`,`completed`,`failed`,`cancelled`,`needs_operator`]),ml=Ac(`kind`,[K({kind:J(`no_pending_effects`)}).strict(),K({kind:J(`reconciling`)}).strict(),K({kind:J(`safely_resumable`),capability:H()}).strict(),K({kind:J(`needs_operator`)}).strict(),K({kind:J(`terminal_verified_cleanup`)}).strict()]),hl=K({schema_version:H(),workflow_run_id:H(),definition_digest:H(),run_revision:W().int().nonnegative(),status:pl,game_outcome:q([`not_terminal`,`victory`,`defeat`,`unknown`]),cursor:K({graph_id:H(),node_id:H(),node_execution_id:H()}).strict(),pending_operation:K({operation_id:H(),state:q([`intent`,`accepted`,`unknown`]),instance_id:H(),original_generation:W().int().nonnegative(),payload_digest:H()}).strict().nullable(),budget:K({provider_calls_consumed:W().int().nonnegative(),provider_calls_reserved:W().int().nonnegative(),node_steps_consumed:W().int().nonnegative(),replans_consumed:W().int().nonnegative()}).strict(),cleanup:q([`not_started`,`pending`,`complete`,`failed`,`needs_operator`])}).strict(),gl=K({schema_version:H(),workflow_run_id:H(),sequence:W().int().positive(),run_revision:W().int().nonnegative(),event_type:q([`run_started`,`node_entered`,`node_completed`,`plan_accepted`,`plan_rejected`,`operation_intent`,`operation_unknown`,`operation_settled`,`command_requested`,`command_applied`,`run_terminal`]),definition_digest:H(),node_execution_id:H(),payload:K({operation_id:H().nullable(),classification:q([`accepted`,`unknown`,`settled`,`rejected`,`cancelled`]).nullable(),reason_code:H()}).strict(),integrity_digest:H().nullable().optional()}).strict();K({schema_version:H(),workflow_run_id:H(),after_sequence:W().int().nonnegative(),oldest_sequence:W().int().positive().nullable(),newest_sequence:W().int().positive().nullable(),next_after_sequence:W().int().nonnegative(),gap:K({requested_after_sequence:W().int().nonnegative(),oldest_sequence:W().int().positive(),newest_sequence:W().int().positive()}).strict().nullable(),events:G(gl)}).strict(),K({schema_version:H(),status:H()}).strict(),K({schema_version:H(),capabilities:ol}).strict(),K({schema_version:H(),valid:vc(),definition_digest:H(),diagnostics:G(K({code:H(),severity:q([`error`,`warning`,`info`]),path:H(),message:H()}).strict())}).strict(),K({schema_version:H(),definition_digest:H(),workflow_id:H().nullable(),workflow_version:H().nullable(),required_capabilities:G(H()),graph_count:W().int().nonnegative(),node_count:W().int().nonnegative()}).strict(),K({schema_version:H(),old_definition_digest:H(),new_definition_digest:H(),semantic_change:vc(),changed_paths:G(H())}).strict(),K({schema_version:H(),workflow_run_id:H(),run_revision:W().int().nonnegative(),status:pl}).strict(),K({schema_version:H(),run:hl,accepted_plan_revision:W().int().nonnegative().nullable(),waiting_reason:H().nullable(),authority:K({state:H(),recovery:H()}).strict(),recovery_admission:ml,last_progress_sequence:W().int().nonnegative()}).strict(),K({schema_version:H(),command_id:H(),workflow_run_id:H(),outcome:q([`accepted`,`applied`,`pending`,`duplicate`]),run_revision:W().int().nonnegative(),sequence:W().int().positive().nullable()}).strict(),K({schema_version:H(),workflow_run_id:H(),matched:vc(),compared_events:W().int().nonnegative(),first_divergence:K({path:H(),code:H()}).strict().nullable()}).strict(),K({schema_version:H(),workflow_run_id:H(),redacted:vc(),run:hl,events:G(gl)}).strict(),K({schema_version:H(),error:K({class:H(),code:H(),message:H()}).strict()}).strict(),K({id:H(),title:H(),description:H(),source:q([`catalog`,`draft`,`published`]),updatedAt:H(),definition:fl,capabilities:G(H())}).strict(),K({draftId:H(),definitionId:H(),revision:W().int().nonnegative(),etag:H(),document:fl,layout:sl,updatedAt:H(),conflict:K({serverRevision:W().int().nonnegative(),serverDocument:fl,serverLayout:sl}).strict().nullable()}).strict();let _l=K({schema_version:J(`ascension.studio-authoring/v1`),id:H(),title:H(),description:H(),source:J(`published`),version:H(),definition_digest:H(),definition:fl,published_revision:W().int().nonnegative()}).strict();K({schema_version:J(`ascension.studio-authoring/v1`),definitions:G(_l)}).strict();let vl=K({server_revision:W().int().nonnegative(),server_etag:H(),server_document:ol,server_layout:sl}).strict(),yl=K({schema_version:J(`ascension.studio-authoring/v1`),draft_id:H(),definition_id:H(),revision:W().int().nonnegative(),etag:H(),document:ol,layout:sl,updated_at:H(),conflict:vl.nullable()}).strict();K({schema_version:J(`ascension.studio-authoring/v1`),draft_id:H(),definition_id:H(),document:ol,layout:sl,client_mutation_id:H()}).strict(),K({schema_version:J(`ascension.studio-authoring/v1`),expected_revision:W().int().nonnegative(),etag:H(),client_mutation_id:H(),document:ol,layout:sl}).strict(),K({schema_version:J(`ascension.studio-authoring/v1`),outcome:q([`published`,`already_published`,`conflict`]),definition:_l.nullable(),draft:yl.nullable()}).strict(),K({schemaVersion:J(`ascension.studio-layout/v1`),semanticDigest:H(),positions:Pc(H(),K({x:W().finite(),y:W().finite()}).strict())}).strict();let bl={maxBytes:2097152,maxDepth:32,maxNodes:2e4,maxStringBytes:65536};function xl(e,t={}){let n={...bl,...t};if(new TextEncoder().encode(e).byteLength>n.maxBytes)throw Error(`JSON input exceeds the ${n.maxBytes}-byte limit`);return new Sl(e,n).parse()}var Sl=class{source;limits;index=0;nodes=0;constructor(e,t){this.source=e,this.limits=t}parse(){if(this.skipWhitespace(),this.index>=this.source.length)throw Error(`JSON input is empty`);let e=this.parseValue(0);if(this.skipWhitespace(),this.index!==this.source.length)throw Error(`JSON input has trailing data at offset ${this.index}`);return e}parseValue(e){if(this.nodes+=1,this.nodes>this.limits.maxNodes)throw Error(`JSON input exceeds the ${this.limits.maxNodes}-node limit`);if(e>this.limits.maxDepth)throw Error(`JSON input exceeds the ${this.limits.maxDepth}-level nesting limit`);this.skipWhitespace();let t=this.source[this.index];return t===`"`?this.parseString():t===`{`?this.parseObject(e):t===`[`?this.parseArray(e):this.source.startsWith(`true`,this.index)?(this.index+=4,!0):this.source.startsWith(`false`,this.index)?(this.index+=5,!1):this.source.startsWith(`null`,this.index)?(this.index+=4,null):this.parseNumber()}parseString(){let e=this.index;this.index+=1;let t=!1;for(;this.index<this.source.length;){let n=this.source[this.index];if(n===`
`||n===`\r`)throw Error(`JSON string contains an unescaped line break at offset ${this.index}`);if(t){t=!1,this.index+=1;continue}if(n===`\\`){t=!0,this.index+=1;continue}if(n===`"`){this.index+=1;let t=this.source.slice(e,this.index);if(new TextEncoder().encode(t).byteLength>this.limits.maxStringBytes)throw Error(`JSON string exceeds the ${this.limits.maxStringBytes}-byte limit`);let n=JSON.parse(t);if(typeof n!=`string`)throw Error(`JSON string is invalid at offset ${e}`);return n}this.index+=1}throw Error(`JSON string is unterminated at offset ${e}`)}parseObject(e){this.index+=1;let t=Object.create(null),n=new Set;if(this.skipWhitespace(),this.source[this.index]===`}`)return this.index+=1,t;for(;this.index<this.source.length;){if(this.skipWhitespace(),this.source[this.index]!==`"`)throw Error(`JSON object key expected at offset ${this.index}`);let r=this.parseString();if(n.has(r))throw Error(`JSON object contains a duplicate key: ${r}`);if(n.add(r),this.skipWhitespace(),this.source[this.index]!==`:`)throw Error(`JSON object colon expected at offset ${this.index}`);if(this.index+=1,t[r]=this.parseValue(e+1),this.skipWhitespace(),this.source[this.index]===`}`)return this.index+=1,t;if(this.source[this.index]!==`,`)throw Error(`JSON object separator expected at offset ${this.index}`);this.index+=1}throw Error(`JSON object is unterminated`)}parseArray(e){this.index+=1;let t=[];if(this.skipWhitespace(),this.source[this.index]===`]`)return this.index+=1,t;for(;this.index<this.source.length;){if(t.push(this.parseValue(e+1)),this.skipWhitespace(),this.source[this.index]===`]`)return this.index+=1,t;if(this.source[this.index]!==`,`)throw Error(`JSON array separator expected at offset ${this.index}`);if(this.index+=1,this.skipWhitespace(),this.source[this.index]===`]`)throw Error(`JSON array has a trailing comma at offset ${this.index}`)}throw Error(`JSON array is unterminated`)}parseNumber(){let e=this.source.slice(this.index).match(/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/);if(!e)throw Error(`JSON value is invalid at offset ${this.index}`);let t=e[0],n=Number(t);if(!Number.isFinite(n))throw Error(`JSON number is not finite at offset ${this.index}`);if(/^-?\d+$/.test(t)&&!Number.isSafeInteger(n))throw Error(`JSON integer is outside the safe range at offset ${this.index}`);return this.index+=t.length,n}skipWhitespace(){for(;/\s/.test(this.source[this.index]??``);)this.index+=1}};let Y={archive:16777216,extracted:33554432,entry:16777216,manifest:262144,report:1048576,entries:32,records:25e3,line:65536};var Cl=class extends Error{code;constructor(e,t){super(t),this.code=e}};function X(e,t,n){if(!e)throw new Cl(t,n)}let wl=e=>$n(ur(e)),Tl=e=>new TextEncoder().encode(e);function El(e){try{return X(e[0]!==239||e[1]!==187||e[2]!==191,`invalid_json`,`UTF-8 BOM is not supported.`),new TextDecoder(`utf-8`,{fatal:!0}).decode(e)}catch{throw new Cl(`invalid_json`,`Input must be valid UTF-8 without a BOM.`)}}function Dl(e){for(let t=0;t<e.length;t++){let n=e.charCodeAt(t);if(n>=55296&&n<=56319){let n=e.charCodeAt(++t);X(n>=56320&&n<=57343,`invalid_json`,`Unpaired Unicode surrogate.`)}else X(n<56320||n>57343,`invalid_json`,`Unpaired Unicode surrogate.`)}return JSON.stringify(e)}function Ol(e){return typeof e==`string`?Dl(e):typeof e==`number`?(X(Number.isFinite(e),`invalid_json`,`Non-finite JSON number.`),JSON.stringify(e)):e===null||typeof e==`boolean`?JSON.stringify(e):Array.isArray(e)?`[${e.map(Ol).join(`,`)}]`:`{${Object.keys(e).sort().map(t=>`${Dl(t)}:${Ol(e[t])}`).join(`,`)}}`}function kl(e,t){X(e.byteLength<=t,`resource_limit`,`JSON document exceeds the supported byte limit.`);let n=El(e),r=0,i=!1,a=!1;for(let e of n)i?a?a=!1:e===`\\`?a=!0:e===`"`&&(i=!1):e===`"`?i=!0:e===`[`||e===`{`?X(++r<=32,`resource_limit`,`JSON exceeds 32 nested containers.`):(e===`]`||e===`}`)&&r--;let o;try{o=xl(n,{maxBytes:t,maxDepth:32,maxNodes:1e5,maxStringBytes:t})}catch{throw new Cl(`invalid_json`,`JSON is malformed, contains duplicate keys, or exceeds structural limits.`)}return X(Ol(o)===n,`noncanonical_json`,`JSON bytes do not match canonical JCS serialization.`),o}function Al(e){let t=4294967295;for(let n of e){t^=n;for(let e=0;e<8;e++)t=t>>>1^(t&1?3988292384:0)}return(t^4294967295)>>>0}function jl(e){return e.length<=128&&/^(?:[a-z0-9][a-z0-9_-]{0,31}\/)*[a-z0-9][a-z0-9_.-]{0,63}$/.test(e)}function Ml(e){X(e.byteLength<=Y.archive,`resource_limit`,`Archive exceeds the 16 MiB browser limit.`),X(e.byteLength>=22,`invalid_zip`,`Archive is truncated.`);let t=new DataView(e.buffer,e.byteOffset,e.byteLength),n=e.byteLength-22,r=e=>t.getUint16(e,!0),i=e=>t.getUint32(e,!0),a=e=>X(e,`invalid_zip`,`Archive structure is unsupported, inconsistent or unsafe.`);a(i(n)===101010256&&r(n+4)===0&&r(n+6)===0&&r(n+20)===0);let o=r(n+10),s=i(n+16);a(o>0&&o===r(n+8)),X(o<=Y.entries,`resource_limit`,`Archive contains too many entries.`),a(s<=n&&s+i(n+12)===n);let c=s,l=0,u=0,d=[],f=new Set,p=[];for(let t=0;t<o;t++){a(c+46<=n&&i(c)===33639248);let t=r(c+8),o=r(c+10),m=i(c+20),h=i(c+24),g=r(c+28),_=r(c+30),v=r(c+32),y=i(c+42),b=i(c+38),x=i(c+16);a((t===0||t===2048)&&(o===0||o===8)&&r(c+6)===20),a(_===0&&v===0&&r(c+34)===0&&r(c+36)===0);let S=r(c+4);a(S===20&&b===0||S===788&&b===2175008768),a(c+46+g<=n);let C=El(e.subarray(c+46,c+46+g));a(jl(C)&&!f.has(C)),f.add(C),l+=h,X(h<=Y.entry&&l<=Y.extracted,`resource_limit`,`Archive exceeds extracted byte limits.`),X(C!==`manifest.json`||h<=Y.manifest,`resource_limit`,`Manifest exceeds supported byte limit.`),X(C!==`reports/omissions.json`||h<=Y.report,`resource_limit`,`Omissions exceed supported byte limit.`),a(y===u),a(y+30<=s&&i(y)===67324752),a(r(y+4)===20&&r(y+6)===t&&r(y+8)===o&&i(y+10)===i(c+12)),a(i(y+14)===x&&i(y+18)===m&&i(y+22)===h),a(r(y+26)===g&&r(y+28)===0);let w=y+30+g;a(w<=s&&w+m<=s),a(El(e.subarray(y+30,w))===C),o===0&&a(m===h),d.push({path:C,bytes:h,compressed:m,method:o,crc:x,start:w}),p.push({start:y,end:w+m}),u=w+m,c+=46+g}a(c===n),p.sort((e,t)=>e.start-t.start);let m=0;for(let e of p)a(e.start===m),m=e.end;return a(m===s),d}async function Nl(e,t){let n=e.subarray(t.start,t.start+t.compressed),r;if(t.method===0)r=n;else{X(typeof DecompressionStream<`u`,`browser_unsupported`,`This browser does not support DEFLATE import.`);let e=new Blob([n]).stream().pipeThrough(new DecompressionStream(`deflate-raw`)).getReader(),i=[],a=0;try{for(;;){let n=await e.read();if(n.done)break;a+=n.value.byteLength,X(a<=t.bytes&&a<=Y.entry,`resource_limit`,`Inflated data exceeds declared or supported size.`),i.push(n.value)}}catch(t){throw await e.cancel().catch(()=>void 0),t instanceof Cl?t:new Cl(`invalid_zip`,`DEFLATE data is malformed or truncated.`)}r=new Uint8Array(a);let o=0;for(let e of i)r.set(e,o),o+=e.byteLength}return X(r.byteLength===t.bytes&&Al(r)===t.crc,`integrity_mismatch`,`Archive entry size or CRC does not match.`),r}let Z=e=>e,Pl=()=>({process_exit:`unknown`,request:`unknown`,action:`unknown`,outcome:`unknown`,gameplay:`unknown`}),Q=(e,t)=>X(e,`evidence_mismatch`,t);function Fl(e){for(let[t,n]of[[`action`,`ai-ascension.action.sha256`],[`provider_request`,`ai-ascension.provider-request.sha256`]])if(e[t]){let r=Z(e[t]);Q(r.namespace===n&&/^[a-f0-9]{64}$/.test(r.value),`Sensitive identity must use its admitted digest namespace.`)}}function Il(e,t){let n=Z(e.payload),r=Z(n.value),i=Z(e.identities),a=n.kind;Fl(i);let o=Pl();if(n.profile===`ai-ascension.recorded-run.common.v1`&&a===`gameplay_result`)Q(Z(t.producer).source_format!==`seed-readiness-controller-release-v2`,`Legacy seed-readiness recordings cannot claim completed gameplay.`),o.gameplay=`completed`,o.outcome=`observed`;else if(n.profile!==`ai-ascension.sts2.seed-readiness.v1`)Q(n.profile!==`ai-ascension.recorded-run.common.v1`&&t.optional_profiles.includes(n.profile)&&a===`opaque`,`Unknown profiles must be optional, inert opaque records.`);else{Q(a!==`opaque`,`Known STS2 payloads must use their admitted type.`);let t=Z(e.source).stream;if(a!==`diagnostic`&&Q({seed_start:[`trajectory`],observation_summary:[`trajectory`],decision_summary:[`trajectory`,`decisions`],action_outcome:[`trajectory`],accounting:[`provider-accounting`],process_result:[`result`]}[a]?.includes(t),`Known payload is not from its admitted source stream.`),a===`diagnostic`){let e=[`trajectory`,`decisions`,`mcp`,`provider-accounting`,`result`,`manifest`];Q({episode_failed:[`trajectory`],operation_wait_completed:[`trajectory`],unsupported_source_event:[`trajectory`],unsupported_source_status:[`trajectory`,`provider-accounting`],invalid_source_record:e,partial_final_record:e,unsupported_profile:e}[r.code]?.includes(t),`Diagnostic is not from its admitted source stream.`),[`unsupported_source_event`,`unsupported_source_status`].includes(r.code)&&Q(typeof r.value_digest==`string`&&/^[a-f0-9]{64}$/.test(r.value_digest),`Unsupported source diagnostics require a value digest.`)}if(a===`process_result`&&(o.process_exit=r.exit_code===0?`completed`:`failed`),a===`diagnostic`&&r.code===`episode_failed`&&(o.gameplay=`episode_failed`),a===`seed_start`&&(o.action=r.status,(r.status===`accepted`||r.status===`settled`)&&(o.request=`accepted`),r.status===`rejected`&&(o.request=`rejected`),r.status===`settled`?(Q(r.run_started&&r.host_ready&&r.effect_kind===`run_started`&&i.operation,`Settled seed start requires host observation, run-start witness and operation identity.`),o.outcome=`observed`):Q(r.effect_kind===`unknown`&&r.run_started===!1,`Unsettled seed start cannot assert a run-start witness.`),Q(r.seed_match===(r.requested_seed_digest===r.canonical_seed_digest),`Seed match contradicts seed digests.`)),a===`action_outcome`&&Q(r.status===`unknown`&&!r.observation&&!r.from_generation&&!r.to_generation&&!r.effect_digest,`Candidate legacy action receipts support only an unknown outcome.`),a===`accounting`){Q(Z(e.source).stream===`provider-accounting`,`Accounting must use its owning source stream.`);for(let e of Object.values(Z(r.usage))){let t=Z(e);Q([`unknown`,`not_applicable`].includes(t.value_status)===(t.value===null),`Unknown usage must be null; numeric usage requires a stated value status.`)}let t=Z(r.counts);t.completed_turn_count!==void 0&&t.turn_count!==void 0&&Q(BigInt(t.completed_turn_count)<=BigInt(t.turn_count),`Completed turn count exceeds total turns.`)}i.model_execution&&Q(Z(i.model_execution).namespace===(a===`accounting`?`seed-readiness.accounting.model-execution`:`seed-readiness.trajectory.model-execution`),`Model-execution identity is in the wrong source namespace.`)}Q(Ol(o)===Ol(e.evidence),`Record evidence contradicts its admitted payload.`)}function Ll(e,t,n){let r=Pl(),i=n.filter(e=>Z(e.payload).kind===`process_result`);Q(i.length<=1,`Recording contains duplicate process results.`),i.length&&(r.process_exit=Z(i[0].evidence).process_exit),n.some(e=>Z(e.payload).kind===`diagnostic`&&Z(Z(e.payload).value).code===`episode_failed`)&&(r.gameplay=`episode_failed`),n.some(e=>Z(e.payload).kind===`gameplay_result`)&&(Q(r.gameplay!==`episode_failed`,`Gameplay evidence conflicts.`),r.gameplay=`completed`,r.outcome=`observed`),Q(Ol(r)===Ol(e.evidence),`Recording summary contradicts the record evidence.`),Z(e.completeness).status===`complete`&&Q(Z(e.completeness).source_snapshot===`stable`&&t.streams.every(e=>![`unknown`,`interrupted`,`unsupported`].includes(e.state)&&e.rejected_rows===0&&e.unsupported_rows===0),`Complete recording claim lacks a stable, reconciled source snapshot.`)}let Rl=wl(Tl(Wn)),zl=JSON.parse(Wn),Bl=new Un.default({allErrors:!1,strict:!1});Bl.addSchema(zl);let Vl=Object.fromEntries([`manifest`,`record`,`omissions`].map(e=>[e,Bl.getSchema(`${zl.$id}#/$defs/${e}`)])),Hl=`ai-ascension.recorded-run.common.v1`,Ul=new Set([Hl,`ai-ascension.sts2.seed-readiness.v1`]),$=e=>e;function Wl(e,t){function n(e){typeof e==`string`?X(!/[\u0000-\u0020\u007f-\u009f]/u.test(e),`schema_mismatch`,`Recording tokens cannot contain whitespace or control characters.`):e&&typeof e==`object`&&Object.values(e).forEach(n)}return n(t),X(Vl[e](t),`schema_mismatch`,`The ${e} does not match the pinned recorded-run candidate schema.`),$(t)}async function Gl(e){X(e instanceof ArrayBuffer,`invalid_input`,`Recording input must be an ArrayBuffer.`),X(e.byteLength<=Y.archive,`resource_limit`,`Archive exceeds the 16 MiB browser limit.`);let t=new Uint8Array(e),n=Ml(t),r=n.find(e=>e.path===`manifest.json`);X(r&&r.bytes<=Y.manifest,`invalid_manifest`,`A bounded root manifest.json is required.`);let i=kl(await Nl(t,r),Y.manifest);X($(i)?.format_version===`1.0.0-candidate.2`,`unsupported_version`,`Only recorded-run 1.0.0-candidate.2 is supported.`);let a=Wl(`manifest`,i);Fl($($(a.recording).identities)),X(a.contract_schema_sha256===Rl,`contract_mismatch`,`Bundle requires different contract bytes from this Studio build.`);let o=a.required_profiles,s=a.optional_profiles,c=e=>e.every((t,n)=>n===0||e[n-1]<t);X(c(o)&&c(s),`invalid_manifest`,`Profiles must be sorted and unique.`),X(o.includes(Hl)&&o.every(e=>Ul.has(e)),`unsupported_profile`,`A required recording profile is unsupported.`),X(!o.some(e=>s.includes(e)),`invalid_manifest`,`Required and optional profiles overlap.`);let l=new Set([...o,...s]),u=$(a.integrity),d={...a,integrity:{...u}};delete d.integrity.bundle_semantic_digest;let f=wl(Tl(Ol(d)));X(f===u.bundle_semantic_digest,`integrity_mismatch`,`Manifest semantic digest does not match.`);let p=a.entries;X(c(p.map(e=>e.path)),`invalid_manifest`,`Manifest entries must be sorted and unique.`),X(a.bundle_id===wl(Tl(`ai-ascension.recorded-run.v1/bundle-id\0${Ol($(a.recording).identity)}`)),`integrity_mismatch`,`Bundle identity digest does not match the recording identity.`),X(new Set(p.map(e=>e.path)).size===p.length&&p.length+1===n.length,`invalid_manifest`,`Manifest entry paths must be unique and match the archive exactly.`),X(p.some(e=>e.path===`records/events.ndjson`)&&p.some(e=>e.path===`reports/omissions.json`),`invalid_manifest`,`Events and omissions entries are required.`);let m=[],h=[],g,_=new Set,v=[],y=new Map,b=Y.records;for(let e of p){let r=n.find(t=>t.path===e.path);X(r&&r.bytes===e.bytes,`integrity_mismatch`,`Declared entry is missing or has an incorrect size.`);let i=r.path===`reports/omissions.json`;X(e.media_type===(i?`application/json`:`application/x-ndjson`),`invalid_manifest`,`Entry media type does not match its role.`),X(!i||r.bytes<=Y.report,`resource_limit`,`Omissions report exceeds the 1 MiB limit.`);let a=await Nl(t,r);if(X(wl(a)===e.sha256,`integrity_mismatch`,`An entry SHA-256 does not match the manifest.`),i){g=Wl(`omissions`,kl(a,Y.report));continue}X(a.length===0||a.at(-1)===10,`truncated_records`,`Every NDJSON record must end with LF.`);let o=0;for(let e=0;e<a.length;e++)X(e-o<=Y.line,`resource_limit`,`A record exceeds the 64 KiB limit.`),a[e]===10&&(X(b>0,`resource_limit`,`Recording exceeds the 25,000-record limit.`),b--,o=e+1);y.set(r.path,a)}for(let[e,t]of y){let n=0,r,i=new Map;for(let o=0;o<t.length;o++){if(X(o-n<=Y.line,`resource_limit`,`A record exceeds the 64 KiB limit.`),t[o]!==10)continue;X(m.length+h.length<Y.records,`resource_limit`,`Recording exceeds the 25,000-record limit.`);let s=Wl(`record`,kl(t.subarray(n,o),Y.line));n=o+1;let c=$(s.source),u=$(s.payload);Il(s,a);let d=[c.stream,c.record_ordinal,c.subrecord_ordinal],f=`${d[0]}:${d[1]}`;X(d[2]===(i.get(f)??0),`record_order`,`Subrecord ordinals must start at zero and be contiguous.`),i.set(f,d[2]+1),X(!r||d[0]>r[0]||d[0]===r[0]&&(d[1]>r[1]||d[1]===r[1]&&d[2]>r[2]),`record_order`,`Records must be ordered by source stream, ordinal and subrecord ordinal.`),r=d,X(l.has(u.profile),`unsupported_profile`,`Record payload profile is undeclared.`);let p=`${c.stream}:${c.record_ordinal}:${c.subrecord_ordinal}`;X(!_.has(p),`duplicate_record`,`Source stream, ordinal and subrecord identity is duplicated.`),_.add(p);let g=e===`records/accounting.ndjson`;X(g===(u.kind===`accounting`),`invalid_accounting`,`Accounting must appear only in the dedicated accounting entry.`);let y={key:p,kind:u.kind,stream:c.stream,ordinal:c.record_ordinal,sequence:c.stream_sequence,timestamp:s.time?$(s.time).unix_ns:void 0,unsupported:!Ul.has(u.profile)||u.kind===`opaque`,identities:$(s.identities),evidence:$(s.evidence),payload:u};(g?h:m).push(y),v.push(s)}}X(g,`invalid_manifest`,`An omissions report is required.`),Kl(g,[...m,...h]),Ll(a,g,v);let x=(e,t)=>e.stream<t.stream?-1:e.stream>t.stream?1:e.ordinal-t.ordinal||Number(e.key.split(`:`).at(-1))-Number(t.key.split(`:`).at(-1));m.sort(x),h.sort(x);let S=$(a.recording),C=$(S.identity);return{digest:f,bundleIdentity:`${C.namespace}:${C.value}`,identities:$(S.identities),provenance:{producer:a.producer,adapter:a.adapter,versions:a.versions,bundle_id:a.bundle_id,contract_schema_sha256:Rl,format_version:a.format_version,fixture_provenance:g.fixture_provenance},completeness:{...$(a.completeness),streams:g.streams},evidence:$(a.evidence),omissions:g,records:m,accounting:h,diagnostics:s.filter(e=>!Ul.has(e)).map(e=>`Unsupported optional profile: ${e}`)}}function Kl(e,t){let n=e.streams,r=new Set;X(n.every((e,t)=>t===0||n[t-1].stream<e.stream),`invalid_reconciliation`,`Stream declarations must be sorted and unique.`),X([`trajectory`,`decisions`,`mcp`,`provider-accounting`,`result`,`manifest`].every(e=>n.some(t=>t.stream===e)),`invalid_reconciliation`,`Required source stream dispositions are missing.`);for(let e of n){let n=e.stream;X(!r.has(n),`invalid_reconciliation`,`Omissions stream is duplicated.`),r.add(n);let i=t.filter(e=>e.stream===n),a=new Set(i.map(e=>e.ordinal));if(X(i.length===e.output_records&&a.size===e.emitted_rows,`invalid_reconciliation`,`Emitted source rows or output counts do not reconcile.`),[`absent`,`unknown`].includes(e.state)){X(e.input_records===null&&[`emitted_rows`,`filtered_rows`,`unsupported_rows`,`rejected_rows`,`output_records`].every(t=>e[t]===0)&&e.dispositions.length===0&&e.field_omissions.length===0,`invalid_reconciliation`,`Absent or unknown streams cannot contain source or output counts.`);continue}X(e.input_records!==null,`invalid_reconciliation`,`Present stream requires an input count.`);let o={filtered:0,unsupported:0,rejected:0},s=new Set(a),c=-1;for(let t of e.dispositions){X({raw_mcp_disallowed:`filtered`,private_source_metadata:`filtered`,unsupported_source_event:`unsupported`,unsupported_source_status:`unsupported`,invalid_source_record:`rejected`,partial_final_record:`rejected`}[t.reason]===t.disposition,`invalid_reconciliation`,`Source disposition reason and class disagree.`),t.reason===`raw_mcp_disallowed`&&X(n===`mcp`,`invalid_reconciliation`,`Raw MCP disposition belongs only to the MCP stream.`),t.reason===`private_source_metadata`&&X(n===`manifest`,`invalid_reconciliation`,`Private source metadata disposition belongs only to the manifest stream.`),t.reason===`unsupported_source_event`&&X(n===`trajectory`,`invalid_reconciliation`,`Unsupported source events belong only to the trajectory stream.`),t.reason===`unsupported_source_status`&&X([`trajectory`,`provider-accounting`].includes(n),`invalid_reconciliation`,`Unsupported source status belongs only to trajectory or accounting.`);let r=t.first,i=t.last;t.reason===`partial_final_record`&&X(e.state===`interrupted`&&r===i&&i===e.input_records-1,`invalid_reconciliation`,`Partial source tail must be the interrupted stream's final singleton row.`),X(r<=i&&r>c&&i<e.input_records,`invalid_reconciliation`,`Invalid source disposition range.`),c=i;for(let e=r;e<=i;e++)X(!s.has(e),`invalid_reconciliation`,`Source dispositions overlap emitted rows or other dispositions.`),s.add(e),o[t.disposition]++}X([...s].every(t=>t<e.input_records)&&s.size===e.input_records&&o.filtered===e.filtered_rows&&o.unsupported===e.unsupported_rows&&o.rejected===e.rejected_rows,`invalid_reconciliation`,`Source disposition counts do not reconcile.`);let l=e.field_omissions;X(l.every(t=>t.affected_rows<=e.input_records)&&new Set(l.map(e=>e.rule)).size===l.length,`invalid_reconciliation`,`Field omission counts or rules are inconsistent.`),e.state===`omitted`&&X(e.filtered_rows===e.input_records,`invalid_reconciliation`,`Omitted stream contains unfiltered rows.`),e.state===`unsupported`&&X(e.unsupported_rows===e.input_records,`invalid_reconciliation`,`Unsupported stream counts disagree.`),e.state===`interrupted`&&X(e.dispositions.some(t=>t.reason===`partial_final_record`&&t.disposition===`rejected`&&t.first===t.last&&t.last===e.input_records-1),`invalid_reconciliation`,`Interrupted stream must identify its rejected final tail.`),n===`mcp`&&X(e.emitted_rows===0&&e.filtered_rows===e.input_records&&e.dispositions.every(e=>e.reason===`raw_mcp_disallowed`),`invalid_reconciliation`,`Raw MCP records are not admitted by this profile.`)}X(t.every(e=>r.has(e.stream)),`invalid_reconciliation`,`A record stream has no omissions declaration.`)}async function ql(e){X(Number.isSafeInteger(e.size)&&e.size>=0&&e.size<=Y.archive,`resource_limit`,`Archive exceeds the 16 MiB browser limit.`);let t=await e.arrayBuffer();return X(t.byteLength===e.size,`invalid_input`,`File size changed while reading.`),Gl(t)}self.onmessage=async e=>{try{let t=await ql(e.data);self.postMessage({recording:t})}catch(e){self.postMessage({diagnostic:e instanceof Cl?{code:e.code,message:e.message}:{code:`import_failed`,message:`Recording could not be validated. No new records were admitted.`}})}}})();